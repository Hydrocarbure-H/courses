#include <iostream>
#include "isbn.h"

/*
   L'International Standard Book Number (ISBN) ou Numéro international normalisé du livre (NINL) est un numéro international qui permet d'identifier, de manière unique, chaque édition de chaque livre publié, que son support soit numérique ou sur papier. Il est destiné à simplifier la gestion informatique pour tous les intervenants de la chaîne du livre (imprimeur, éditeur, libraire, bibliothèque, etc.).
*/

int main()
{
   ISBN isbn10("2-266-11156-6");
   ISBN isbn13("978-2-86889-006-1");

   std::cout << isbn10.getISBN() << " : " << isbn10.estValide() << std::endl;
   std::cout << isbn13.getISBN() << " : " << isbn13.estValide() << std::endl;

   std::cout << "2-206-11156-6" << " : " << isbn10.estValide("2-206-11156-6") << std::endl;
   std::cout << "978-2-80889-006-1" << " : " << isbn13.estValide("978-2-80889-006-1") << std::endl;

   return 0;
}

