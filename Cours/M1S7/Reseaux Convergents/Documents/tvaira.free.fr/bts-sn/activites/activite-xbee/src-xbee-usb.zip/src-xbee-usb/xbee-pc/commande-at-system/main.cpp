#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <iostream>
#include <string.h>

int main (int argc, char** argv)
{
    int xbeefd = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY);
    if (xbeefd == -1)
    {
        std::cerr << "Erreur ouverture port !" << std::endl;
        return -1;
    }

    unsigned char buffer[128];
    
    // met le buffer à 0
    memset(buffer, 0, 128);
    
    // Commande ATID
    // voir protocole page 60 (xbee.pdf)
    buffer[0] = 0x7e;  // frame start
    buffer[1] = 0x00;  // MSB frame size
    buffer[2] = 0x04;  // LSB frame size
    buffer[3] = 0x08;  // Frame type (0x08 = Local AT)
    buffer[4] = 0x52;  // Frame ID (used for ACK)
    buffer[5] = 'M';   // First char of command
    buffer[6] = 'Y';   // Second char of command
    
    // Calcul du checksum (page 59)
    unsigned char checksum = 0;
    for (int i = 3; i < 7; i++)
        checksum += buffer[i];
    
    buffer[7] = 0xFF - checksum;

    printf("Trame envoyée : ");
    for (int i = 0; i < 8; i++)
        printf("0x%02X ", buffer[i]);
    printf("\n");

    write(xbeefd, buffer, 8);

    sleep(1);
    
    // remet le buffer à 0
    memset(buffer, 0, 128);
    
    int n = read(xbeefd, buffer, 128);
    
    printf("Octets lus : %d\n", n);
    fflush(stdout);

    printf("Trame reçue : ");
    for (int i = 0; i < n; i++)
        printf("0x%02X ", buffer[i]);
    printf("\n");
    
    close(xbeefd);
    
    return 0;
}
