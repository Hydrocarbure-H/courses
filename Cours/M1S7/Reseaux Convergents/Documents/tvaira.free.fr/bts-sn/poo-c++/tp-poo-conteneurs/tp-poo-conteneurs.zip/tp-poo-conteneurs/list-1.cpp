#include <iostream>
#include <list>

using namespace std;

int main() 
{
  list<int> lst; // une liste vide
    
  lst.push_back( 5 );
  lst.push_back( 6 );
  lst.push_back( 1 );
  lst.push_back( 10 );
  lst.push_back( 7 );
  lst.push_back( 8 );
  lst.push_back( 4 );
  lst.push_back( 5 );
  lst.pop_back(); // enleve le dernier élément et supprime l'entier 5
  
  cout << "La liste lst contient " << lst.size() << " entiers : \n";
  
  // utilisation d'un itérateur pour parcourir la liste lst
  for (list<int>::iterator it = lst.begin(); it != lst.end(); ++it)
    cout << ' ' << *it;
  cout << '\n'; 
  
  // afficher le premier élément 
  cout << "Premier element : " << lst.front() << '\n'; 
  
  // afficher le dernier élément
  cout << "Dernier element : " << lst.back() << '\n'; 
  
  // parcours avec un itérateur en inverse 
  for ( list<int>::reverse_iterator rit = lst.rbegin(); rit != lst.rend(); ++rit ) 
  { 
      cout << ' ' << *rit;
  } 
  cout << '\n'; 
  
  return 0;
}

