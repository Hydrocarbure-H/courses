// threads.2d.c

//#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

void Init(sem_t *s, unsigned int value)
{
   sem_init(s, 0, value);
}

void P(sem_t *s)
{
   sem_wait(s);
}

void V(sem_t *s)
{
   sem_post(s);
}

int getValue(sem_t *s)
{
   int sval;
   
   sem_getvalue(s, &sval);

   return sval;
}

