#include "panneau.h"

PanneauLumineux::PanneauLumineux(QString adresseIP, int port, QObject* parent) : QObject(parent), adresseIP(adresseIP), port(port)
{
    this->host = QHostAddress(adresseIP);
    #ifdef DEBUG_PANNEAU_LUMINEUX
    qDebug() << QString::fromUtf8("<PanneauLumineux::PanneauLumineux()> adresse ip : %1").arg(adresseIP);
    qDebug() << QString::fromUtf8("<PanneauLumineux::PanneauLumineux()> port : %1").arg(port);
    #endif

    socket = new QTcpSocket(this);

    taillePolice = 0;
    initialiserTableTaillePolice();
    initialiserTableCaracteresSpeciaux();

    connect(socket, SIGNAL(connected()),this, SLOT(connected()));
    connect(socket, SIGNAL(disconnected()),this, SLOT(disconnected()));
    connect(socket, SIGNAL(bytesWritten(qint64)),this, SLOT(bytes_written(qint64)));
    connect(socket, SIGNAL(readyRead()),this, SLOT(ready_read()));
}

PanneauLumineux::~PanneauLumineux()
{
    deconnecter();
    #ifdef DEBUG_PANNEAU_LUMINEUX
    qDebug() << QString::fromUtf8("<PanneauLumineux::~PanneauLumineux()>");
    #endif
}

bool PanneauLumineux::connecter()
{
    if(estConnecte())
        return true;

    // TODO
}

bool PanneauLumineux::deconnecter()
{
    if(!estConnecte())
        return true;

    // TODO
}

bool PanneauLumineux::estConnecte() const
{
    if(socket->state() == QTcpSocket::ConnectedState)
    {
        return true;
    }
    else
    {
        return false;
    }
}

QString PanneauLumineux::getErreur() const
{
    return socket->errorString();
}

QHostAddress PanneauLumineux::getHost() const
{
    return host;
}

int PanneauLumineux::getPort() const
{
    return port;
}

QByteArray PanneauLumineux::getTrame() const
{
    return trame;
}

QByteArray PanneauLumineux::getMessage() const
{
    return message;
}

void PanneauLumineux::setMessage(QString message)
{
    this->message.clear();
    this->message += message;
}

QByteArray PanneauLumineux::creerTrameControle(int nb)
{
    QString nbMessages;

    if(nb < 10)
    {
        nbMessages = "0" + QString::number(nb);
    }
    else
    {
        nbMessages = QString::number(nb);
    }

    //cf. protocole Moving Sign
    trame += NUL;
    trame += NUL;
    trame += NUL;
    trame += NUL;
    trame += NUL;
    trame += SOH;

    // TODO : continuer à fabriquer la trame

    #ifdef DEBUG_PANNEAU_LUMINEUX
    qDebug() << "<PanneauLumineux::creerTrameControle()> taille trame initilisation : " << trame.size();
    for(int i = 0; i < trame.size(); i++)
    {
        qDebug("0x%02X", (unsigned char)trame[i]);
    }
    #endif

    return trame;
}

QByteArray PanneauLumineux::creerTrameTexte(QString message)
{
    this->message.clear();
    this->message += message;

    QByteArray trame;

    trame += NUL;
    trame += NUL;
    trame += NUL;
    trame += NUL;
    trame += NUL;
    trame += SOH;

    // TODO : continuer à fabriquer la trame

    #ifdef DEBUG_PANNEAU_LUMINEUX
    qDebug() << "<PanneauLumineux::creerTrameTexte()> taille trame texte : " << trame.size();
    for(int i = 0; i < trame.size(); i++)
    {
        qDebug("0x%02X", (unsigned char)trame[i]);
    }
    #endif

    return trame;
}

bool PanneauLumineux::envoyer(QByteArray frame)
{
    if(estConnecte())
    {
        socket->write(frame);

        #ifdef DEBUG_PANNEAU_LUMINEUX
        qDebug() << "<PanneauLumineux::envoyer()> octets à envoyer : " << socket->bytesToWrite();
        #endif

        // attente envoi
        if(socket->waitForBytesWritten(TIMEOUT_WRITE) == true)
        {
            //cf. protocole Moving Sign
            // TODO : acquitter les réponses du panneau
        }
        else
        {
            #ifdef DEBUG_PANNEAU_LUMINEUX
            qDebug() << "<PanneauLumineux::envoyer()> erreur : aucune donnée envoyée " << socket->errorString();
            #endif
            return false;
        }

        #ifdef DEBUG_PANNEAU_LUMINEUX
        qDebug() << "<PanneauLumineux::envoyer()> ok";
        #endif

        return true;
    }

    return false;
}

void PanneauLumineux::reinitialiser()
{
    QByteArray frame;

    setMessage("");

    frame = creerTrameControle(1);
    envoyer(frame);

    frame = creerTrameTexte(getMessage());
    envoyer(frame);
}

bool PanneauLumineux::acquitter(char acquittement)
{
    char reponse;
    int  octetsRecus;
    int  octetsLus;

    // données reçues ?
    if(socket->waitForReadyRead(TIMEOUT_READ) == true)
    {
        octetsRecus = socket->bytesAvailable();

        #ifdef DEBUG_PANNEAU_LUMINEUX
        qDebug() << "<PanneauLumineux::acquitter()> octets reçus : " << socket->bytesAvailable();
        #endif

        // attente de la réponse d'acquittement du panneau
        do
        {
            octetsLus = socket->read(&reponse, 1);
            octetsRecus -= octetsLus;

            #ifdef DEBUG_PANNEAU_LUMINEUX
            qDebug("<PanneauLumineux::acquitter()> réponse : 0x%02X", (unsigned char)reponse);
            #endif
        }
        while(reponse != acquittement);

        #ifdef DEBUG_PANNEAU_LUMINEUX
        qDebug("<PanneauLumineux::acquitter()> ok");
        #endif
        return true;
    }
    else
    {
        #ifdef DEBUG_PANNEAU_LUMINEUX
        qDebug() << "<PanneauLumineux::acquitter()> erreur : aucune donnée reçue " << socket->errorString();
        #endif
        return false;
    }

    return false;
}

void PanneauLumineux::changerTaillePolice(int choix)
{
    if((choix != -1) && (choix < tableTaillePolice.size()))
        taillePolice = choix;
}

void PanneauLumineux::connected() const
{
    #ifdef DEBUG_PANNEAU_LUMINEUX
    qDebug() << "<PanneauLumineux::connected()> connecté";
    #endif
}

void PanneauLumineux::disconnected() const
{
    #ifdef DEBUG_PANNEAU_LUMINEUX
    qDebug() << "<PanneauLumineux::disconnected()> déconnecté";
    #endif
}

void PanneauLumineux::bytes_written(qint64 bytes) const
{
    Q_UNUSED(bytes)

    #ifdef DEBUG_PANNEAU_LUMINEUX
    qDebug() << "<PanneauLumineux::bytes_written()> octets écrits : " << bytes;
    #endif
}

void PanneauLumineux::ready_read() const
{
    #ifdef DEBUG_PANNEAU_LUMINEUX
    qDebug() << "<PanneauLumineux::ready_read()> ok";
    #endif
}

void PanneauLumineux::initialiserTableTaillePolice()
{
    tableTaillePolice[0]  = FONT::SMALL;
    tableTaillePolice[1]  = FONT::SMALL_BOLD;
    tableTaillePolice[2]  = FONT::SMALL_WIDE;
    tableTaillePolice[3]  = FONT::SMALL_WIDE_BOLD;
    tableTaillePolice[4]  = FONT::SMALL_SHORT;
    tableTaillePolice[5]  = FONT::NORMAL;
    tableTaillePolice[6]  = FONT::NORMAL_BOLD;
    tableTaillePolice[7]  = FONT::NORMAL_WIDE;
    tableTaillePolice[8]  = FONT::NORMAL_WIDE_BOLD;
    tableTaillePolice[9]  = FONT::NORMAL_DISCARDED;
    tableTaillePolice[10] = FONT::NORMAL_DISCARDED_BOLD;
    tableTaillePolice[11] = FONT::NORMAL_MORE_DISCARDED_BOLD;
    tableTaillePolice[12] = FONT::NORMAL_DISCARDED_BOLDER;
    tableTaillePolice[13] = FONT::NORMAL_DISCARDED_WIDE;
    tableTaillePolice[14] = FONT::NORMAL_DISCARDED_WIDE_BOLD;
    tableTaillePolice[15] = FONT::BIG;
    tableTaillePolice[16] = FONT::BIG_BOLD;
    tableTaillePolice[17] = FONT::BIG_WIDE;
    tableTaillePolice[18] = FONT::BIG_WIDE_BOLD;
    tableTaillePolice[19] = FONT::BIGGER;
    tableTaillePolice[20] = FONT::BIGGER_BOLD;
    tableTaillePolice[21] = FONT::BIGGER_WIDE;
    tableTaillePolice[22] = FONT::BIGGER_WIDE_BOLD;

}

void PanneauLumineux::initialiserTableCaracteresSpeciaux()
{
    tableCaracteresSpeciaux[CARACTERE_RETOUR_A_LA_LIGNE]    = OCTET_RETOUR_A_LA_LIGNE;
    tableCaracteresSpeciaux[CARACTERE_TEMPERATURE]          = OCTET_TEMPERATURE;
    tableCaracteresSpeciaux[CARACTERE_DEGRE]                = OCTET_DEGRE;
    tableCaracteresSpeciaux[CARACTERE_E_ACCENT_AIGU]        = OCTET_E_ACCENT_AIGU;
    tableCaracteresSpeciaux[CARACTERE_E_ACCENT_GRAVE]       = OCTET_E_ACCENT_GRAVE;
    tableCaracteresSpeciaux[CARACTERE_A_ACCENT]             = OCTET_A_ACCENT;
    tableCaracteresSpeciaux[CARACTERE_C_CEDILLE]            = OCTET_C_CEDILLE;
}

QByteArray PanneauLumineux::formaterMessage()
{
    QMapIterator<char, char> i(tableCaracteresSpeciaux);

    while (i.hasNext())
    {
        i.next();
        message.replace(i.key(), i.value());
    }

    return message;
}
