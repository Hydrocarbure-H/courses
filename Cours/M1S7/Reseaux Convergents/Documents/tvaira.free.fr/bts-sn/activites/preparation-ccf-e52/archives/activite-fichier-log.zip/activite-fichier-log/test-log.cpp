#include <syslog.h>
#include <iostream>

using namespace std;

int main( int argc, char **argv )
{
    // Fixe les priorités qui seront journalisés
    // Les huit priorités sont LOG_EMERG, LOG_ALERT, LOG_CRIT, LOG_ERR, LOG_WARNING, LOG_NOTICE, LOG_INFO et LOG_DEBUG.
    // Certains systèmes fournissent aussi une macro LOG_UPTO(p) pour le masque de toutes les priorités jusqu'à p incluses.
    setlogmask (LOG_UPTO (LOG_NOTICE)); // ici seulement de LOG_EMERG à LOG_NOTICE

    //LOG_CONS       : écrire directement sur la console système s'il y a une erreur durant la transmission.
    //LOG_NDELAY     : ouvrir la connexion immédiatement (normalement, la connexion est ouverte quand le premier message est transmis).
    //LOG_PERROR     : (pas dans POSIX.1-2001) écrire sur stderr également.
    //LOG_PID        : inclure le PID dans chaque message.
    //LOG_LOCAL0 à 7 : réservé pour des utilisations locales.
    openlog("test-log", LOG_CONS | LOG_PID | LOG_NDELAY, LOG_LOCAL1);

    //LOG_NOTICE     : Événement normal méritant d'être signalé
    syslog(LOG_NOTICE, "demarrage par utilisateur %d", getuid ());
    // ce qui donne dans /var/log/syslog
    // Nov 24 21:20:14 alias test-log[31990]: demarrage par utilisateur 1026
    
    //LOG_INFO       : Message d'information simple
    syslog(LOG_INFO, "le soleil brille ce matin");
    // non journalisé

    cout << "un programme comme un autre\n";

    closelog();    
    
    return 0;
}
