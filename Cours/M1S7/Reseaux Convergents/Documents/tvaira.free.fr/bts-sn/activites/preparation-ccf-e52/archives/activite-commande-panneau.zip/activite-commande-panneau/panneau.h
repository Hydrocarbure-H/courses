#ifndef PANNEAU_LUMINEUX_H
#define PANNEAU_LUMINEUX_H

#include <QtNetwork>
#include <QMap>
#include "movingsign.h"

#define TIMEOUT_READ    2000
#define TIMEOUT_WRITE   100

#define DEBUG_PANNEAU_LUMINEUX

class PanneauLumineux : public QObject
{
    Q_OBJECT

    private:        
        QString      adresseIP;
        int          port;
        QHostAddress host;
        QTcpSocket*  socket;
        QByteArray   message;
        QByteArray   trame;
        int          taillePolice;

        QMap<int, char>  tableTaillePolice;
        QMap<char, char> tableCaracteresSpeciaux;

        void        initialiserTableTaillePolice();
        void        initialiserTableCaracteresSpeciaux();
        QByteArray  formaterMessage();

	public:
        PanneauLumineux(QString adresseIP, int port, QObject* parent = 0);
        ~PanneauLumineux();

        bool         connecter();
        bool         deconnecter();
        bool         estConnecte() const;
        QString      getErreur() const;
        QHostAddress getHost() const;
        int          getPort() const;

        QByteArray   getTrame() const;
        QByteArray   getMessage() const;
        void         setMessage(QString message);

        QByteArray   creerTrameControle(int nb = 1);
        QByteArray   creerTrameTexte(QString message = "");
        bool         envoyer(QByteArray frame);
        void         reinitialiser();
        bool         acquitter(char acquittement);
        void         changerTaillePolice(int choix);
        
    private slots:
        void connected() const;
        void disconnected() const;
        void bytes_written(qint64 bytes) const;
        void ready_read() const;
};

#endif 
