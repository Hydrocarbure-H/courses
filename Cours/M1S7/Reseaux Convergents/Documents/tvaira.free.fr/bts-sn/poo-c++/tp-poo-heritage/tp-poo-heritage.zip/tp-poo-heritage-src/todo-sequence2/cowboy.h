#ifndef COWBOY_H
#define COWBOY_H


#endif // COWBOY_H
