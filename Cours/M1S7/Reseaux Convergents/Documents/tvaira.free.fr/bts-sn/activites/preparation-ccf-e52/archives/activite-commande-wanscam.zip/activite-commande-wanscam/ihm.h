#ifndef IHM_H
#define IHM_H

#include <QtGui>
#include <QNetworkAccessManager>
#include <QNetworkReply>

#define DEBUG_IHM

class TAcquisition;

class IHM : public QWidget
{
    Q_OBJECT

public:
    IHM( QWidget *parent = 0 );
    ~IHM();

private:
    QNetworkAccessManager *manager;

    QString         adresseIP;
    int             port;
    QString         user;
    QString         pwd;

    // Widgets    
    QLabel          *labelAdresseIP;
    QLineEdit       *leAdresseIP;
    QLabel          *labelPort;
    QLineEdit       *lePort;
    QPushButton     *bInfos;
    QPushButton     *bRight;
    QTextEdit       *journal;
    
    void            lireParametres();

signals:
    void            quit();

public slots:    
    void            quitter();
    void            demanderInfos();

    void            right();

    void            replyFinished(QNetworkReply *reply);
};

#endif // IHM_H
