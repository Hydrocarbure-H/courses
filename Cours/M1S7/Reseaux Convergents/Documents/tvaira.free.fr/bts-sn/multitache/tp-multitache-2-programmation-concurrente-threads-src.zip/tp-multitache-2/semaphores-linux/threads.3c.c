// threads.3c.c

