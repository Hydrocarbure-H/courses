#include <iostream>
#include <ctime>
#include <clocale>
#include <unistd.h>

#include "historique.h"

#define NB_ROBOTS      3
#define NB_EVENEMEMTS 16 /* pour les essais : changer cette valeur ! Essayer avec LG_HISTORIQUE */

using namespace std;

int main()
{
   Historique historique;
   char typesOrdre[] = { 'I','A','P','S','R' };
   TOrdre ordreRobot;
   int i;
   time_t init;
   char horodatage[32];
   
   setlocale(LC_TIME, "fr_FR");   
   init = time(NULL);
   strftime(horodatage, 32, "%d/%m/%Y à %T", std::localtime(&init));
   //cout << "Démarrage du système de journalisation le " << ctime(&init) << "\n";
   cout << "Démarrage du système de journalisation le " << horodatage << "\n";
   
   /* fabrique un historique */
   for(i = 0; i < NB_EVENEMEMTS; i++)
   {
      ordreRobot.poste = i%NB_ROBOTS + 1; /* simule un des 3 robots */
      ordreRobot.ordre = typesOrdre[i%5]; /* simule un ordre */
      //historique.ajouterOrdreSolution1(ordreRobot);
      //historique.ajouterOrdreSolution2(ordreRobot);
      //historique.ajouterOrdreSolution3(ordreRobot);
      //historique.ajouterOrdreSolution4(ordreRobot);
      
      cout << "L'information TOrdre {" << ordreRobot.ordre << "," << (int)ordreRobot.poste << "} a été ajoutée à l'historique\n";
      sleep(1); /* simulons une attente avant le prochain événement à enregistrer */
   }
   
   //cout << "\n-> " << i << " informations TOrdre ont été consignées dans l'historique\n";
   cout << "\n-> " << historique.getNbEvenements() << " informations TOrdre ont été consignées dans l'historique\n\n";

   historique.afficherDernierOrdre();
   
   return 0;
}
