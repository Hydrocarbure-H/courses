#include <iostream> // Inclusion des déclarations de cout, endl, etc.

using namespace std; 

//-------------------------------------------------------------//
//  somme1_100.cpp                                             //
//                                                             //
//  Calcul de la somme des entiers de 1 à 100                  //
//-------------------------------------------------------------//
int main ()
{
 unsigned int i = 0U; // variable de contrôle, valeur initiale : zéro.
 unsigned int accumulateur = 0U; // la somme des entiers, initialement zéro.

 // calcul : utilise un traitement itératif : la boucle
 // while est l'une des instructions possibles en C/C++
 while (i <= 100U)
 {
    accumulateur = accumulateur + i;
    i = i + 1; // Avec un peu d'habitude, on écrira plutot ++i
 }

 // affichage du résultat
 cout << "La somme des entiers de 1 a 100 est " << accumulateur << endl;

 return 0;
} // fin du main()

