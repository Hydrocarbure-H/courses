#ifndef ServeurBLE_H
#define ServeurBLE_H

#include <QtBluetooth>
#include <QLowEnergyController>
#include <QLowEnergyCharacteristic>
#include <QLowEnergyCharacteristicData>
#include <QLowEnergyDescriptorData>
#include <QLowEnergyAdvertisingData>
#include <QLowEnergyAdvertisingParameters>
#include <QLowEnergyService>
#include <QLowEnergyServiceData>
#include <QTimer>

#define SERVICE_UUID                "{67d1fdb0-219a-4cc9-82dc-ad6ef0ee12f5}"
#define CHAR_UUID_USER1             "{114dcc56-941e-434e-b254-ee6b61485336}"
#define CHAR_UUID_TEMPERATURE       0x2a1f // type sint16 cf. https://www.bluetooth.com/specifications/gatt/viewer?attributeXmlFile=org.bluetooth.characteristic.temperature_celsius.xml

class ServeurBLE : public QObject
{
    Q_OBJECT
public:
    ServeurBLE();
    ~ServeurBLE();

public:
    void demarrer();

protected slots:
    void controllerStateChanged(QLowEnergyController::ControllerState state);
    void characteristicChanged(QLowEnergyCharacteristic c, QByteArray data);
    void updateTemperature();
    void onDeviceConnected();
    void onDeviceDisconnected();
    void onError(QLowEnergyController::Error);

protected:
    QLowEnergyCharacteristicData createCharacteristic(QBluetoothUuid uuid,  QLowEnergyCharacteristic::PropertyTypes type);
    void setValue(QBluetoothUuid uuid, quint32 value);

private:
    QLowEnergyAdvertisingData   advertisingData;
    QLowEnergyAdvertisingData   responseData;
    QLowEnergyService           *service;
    QLowEnergyController        *controleurBLE;
    QTimer                      *timerTemperature;
    
    QByteArray readValueFromFile(QString filePath);
};

#endif // ServeurBLE_H
