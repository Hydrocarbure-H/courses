#include <iostream>
#include <string.h>
#include <unistd.h>

#include <xbeep.h>
#include "xbee-pi.h"

using namespace std;
using namespace libxbee;

void listerModes()
{
    try 
    {
		std::list<std::string> modes = getModes();
		std::list<std::string>::iterator i;
		
		cout << "Modes xbee disponibles : ";
		for (i = modes.begin(); i != modes.end(); i++) 
        {
			cout << "  " << *i;
		}
		cout << "\n";
	} 
    catch (xbee_err ret) 
    {
		cerr << "Erreur récupération modes xbee !\n";
	}
}

void listerConnexions(XBee &xbee)
{
    try 
    {
        std::list<std::string> types = xbee.getConTypes();
        std::list<std::string>::iterator i;
        
        cout << "Connexions disponibles : ";
        for (i = types.begin(); i != types.end(); i++) 
        {
            cout << "  " << *i;
        }
        cout << "\n";
    } 
    catch (xbee_err ret) 
    {
        cerr << "Erreur récupération connexions xbee !\n";
    }
}

int main(int argc, char *argv[]) 
{
	int i;

    setbuf(stdout, NULL);
    
	//listerModes();

    try 
    {
		XBee xbee("xbee1", "/dev/ttyUSB0", 9600);
		cout << "Mode sélectionné : " << xbee.mode() << "\n";
		
        //listerConnexions(xbee);
        
        struct xbee_conAddress adresse;
        memset(&adresse, 0, sizeof(adresse));
        
        /*adresse.addr64_enabled = 1;
        adresse.addr64[0] = 0x00;
        adresse.addr64[1] = 0x13;
        adresse.addr64[2] = 0xA2;
        adresse.addr64[3] = 0x00;
        adresse.addr64[4] = 0x40;
        adresse.addr64[5] = 0xC1;
        adresse.addr64[6] = 0x72;
        adresse.addr64[7] = 0x5A;
        ConnexionXbee connexionXbee(xbee, "64-bit Data", &adresse);*/
        
        adresse.addr16_enabled = 1;
        adresse.addr16[0] = 0x50;
        adresse.addr16[1] = 0x01;
        ConnexionXbee connexionXbee(xbee, "16-bit Data", &adresse);
        
        for (i = 0; i < 500; i++) 
        {
            printf(".");
            
            /* XBee Series 1 modules don't use meshing, so you can broadcast much faster than Series 2 */
            usleep(100000); /* 100ms */
        }
    }
    catch (xbee_err err) 
    {
		cerr << "Erreur " << err << " !\n";
	}
    
    return 0;
}
