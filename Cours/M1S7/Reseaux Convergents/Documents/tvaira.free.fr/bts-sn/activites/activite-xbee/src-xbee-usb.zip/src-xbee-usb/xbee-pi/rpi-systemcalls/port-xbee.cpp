#include "port-xbee.h"

PortXbee::PortXbee()
{
    ouvert = false;
    xbeefd = -1;
}

PortXbee::~PortXbee()
{
    if(ouvert == true)
        fermer();
}

bool PortXbee::ouvrir(const char *nomPort)
{
    if(ouvert == true)
        return ouvert;
    
    #ifdef DEBUG_PORTXBEE
    fprintf(stderr, "Ouverture du port %s ...\n", nomPort);
    #endif

    // cf. man 2 open
    // mode non bloquant : O_NONBLOCK ou O_NDELAY
    // mode écriture synchronisé : O_SYNC (chaque appel à write bloquera le processus jusqu'à ce que les données aient été écrites physiquement sur le support matériel
    //if (( xbeefd=open(nomPort, O_RDWR )) == -1 )
    if (( xbeefd=open(nomPort, O_RDWR | O_NOCTTY | O_SYNC )) == -1 )
    //if (( xbeefd=open(nomPort, O_RDWR | O_NOCTTY | O_NDELAY | O_SYNC )) == -1 )
    // ou :
	//if (( xbeefd=open(nomPort, O_RDWR | O_NOCTTY | O_NONBLOCK | O_SYNC)) == -1 )
	{
			perror("open");
			return false;
	}

    // cf. man tcgetattr
    tcgetattr(xbeefd, &termios_p);

    // configuration du port série : 9600 bits/s, 8 bits, pas de parité
    // remarque : les caractères BREAK et ceux qui comportent une erreur de parité sont ignorés
    termios_p.c_iflag = IGNBRK | IGNPAR;
    // rien de particulier à faire pour l'envoi des caractères
    termios_p.c_oflag = 0;
    // 9600 bits/s, 8 bits, pas de parité
    termios_p.c_cflag = B9600 | CS8;
    termios_p.c_cflag &= ~PARENB;

    // pas d'écho des caractères reçus
    termios_p.c_lflag = ~ECHO;
    // spécifie le nombre de caractéres que doit contenir le tampon pour être accessible à la lecture
    // En général, on fixe cette valeur à 1
    termios_p.c_cc[VMIN] = 1;
    // spécifie en dixièmes de seconde le temps au bout duquel un caractère devient accessible, 
    // même si le tampon ne contient pas [VMIN] caractères
    // Une valeur de 0 représente un temps infini.
    termios_p.c_cc[VTIME] = 0;

    // cf. man tcsetattr
    tcsetattr(xbeefd, TCSANOW, &termios_p);
    
    // cf. man 2 fcntl
    // mode bloquant ?
    //fcntl(xbeefd, F_SETFL, fcntl(fd,F_GETFL)&~O_NONBLOCK);
    
    ouvert = true;
    #ifdef DEBUG_PORTXBEE
    fprintf(stderr, "Ouverture du port %s réussie (%d)\n", nomPort, xbeefd);
    #endif
    
    return ouvert;
}

void PortXbee::fermer()
{
   // cf. man 2 close
   close(xbeefd);
   ouvert = false;
   xbeefd = -1;
}

int PortXbee::envoyer(char myid[2], char *donnees, int nb)
{
	int retour = -1;
    unsigned char checksum = 0;
    int i, pos, n;

	if(ouvert == true)
	{
        memset(trame, 0, LG_MAX_TRAME);

        // page 63
        trame[0] = 0x7E;
        trame[1] = ((nb+5) >> 8) & 0xFF;
        trame[2] = ((nb+5)     ) & 0xFF;
        trame[3] = 0x01;
        trame[4] = 0x08; // ACK
        trame[5] = myid[0];
        trame[6] = myid[1];
        trame[7] = 0x00; // no options
        for (i = 0; i < nb; i++) 
        {
            trame[8+i] = donnees[i];
        }        
        n = 8+i;
        // page 59
        checksum = 0;
        for (pos = 3; pos < n; pos++) 
        {
            checksum += trame[pos];
        }
        trame[n++] = 0xFF - checksum;
        
        // cf. man 2 write
		retour = write(xbeefd, trame, n);
		
        #ifdef DEBUG_PORTXBEE        
        //debug : affichage
        fprintf(stderr, "-> envoyer (%d/%d) : ", n, retour);
        fprintf(stderr, "trame : ");
        int i; 
        for(i=0;i<n;i++)
        {
            fprintf(stderr, "0x%02X ", *(trame+i));
        }
        fprintf(stderr, "\n");
        //fprintf(stderr, "%s\n", trame);
        #endif
        if (retour == -1)
        {
			perror("write");
        }
    }
    else 
    {
        #ifdef DEBUG_PORTXBEE
        //debug : affichage
        fprintf(stderr, "-> envoyer (%d) : ERREUR port !\n", nb);
        fprintf(stderr, "trame : ");
        /*int i; 
        for(i=0;i<nb;i++)
        {
            fprintf(stderr, "0x%02X ", *(trame+i));
        }
        fprintf(stderr, "\n");*/
        fprintf(stderr, "%s\n", trame);
        #endif
        retour = nb;
    }

	return retour;
}

int PortXbee::recevoir(char *donnees, int nb)
{
	int retour = -1;
	char donnee = 0;
	int lus = 0;

    if(ouvert == false)
        return retour;
    
	if(xbeefd > 0 && donnees != (char *)NULL)
	{
		if(nb > 0)
		{
			for(lus=0;lus<nb;lus++)
			{
                // cf. man 2 read
				retour = read(xbeefd, &donnee, 1);
				if(retour > 0)
						*(donnees+lus) = donnee;
				else	
                {
                    /*if (retour == -1)
                    {
                        perror("read");
                    }*/
                    break;
                }
			}
			if(nb == lus && nb > 1)
				*(donnees+lus) = 0x00; //fin de chaine
			retour = lus;
            #ifdef DEBUG_PORTXBEE
            int i;
            fprintf(stderr, "<- recevoir (%d/%d) : ", nb, lus);
            //fprintf(stderr, "trame : ");
            for(i=0;i<lus;i++)
                fprintf(stderr, "0x%02X ", *(donnees+i)); 
            fprintf(stderr, "\n"); 
            #endif
		}
		else
		{
			
		}
	}
	else retour = 0;
	
	return retour;
}

unsigned char PortXbee::calculerChecksum(char *trame)
{
   unsigned char checksum = 0;
   unsigned int i = 0;
   
   #ifdef DEBUG_PORTXBEE
   printf("trame :\t");
   for(i=0;i<strlen(trame);i++)
      printf("0x%02X ", trame[i]);
   printf("\n");
   #endif
   
   for(i=0;i<strlen(trame);i++)
      checksum ^= trame[i];

   #ifdef DEBUG_PORTXBEE 
   printf("checksum :\t0x%02X\n", checksum);
   #endif
   
   return checksum;
}

bool PortXbee::estOuvert()
{
    return ouvert;
}
