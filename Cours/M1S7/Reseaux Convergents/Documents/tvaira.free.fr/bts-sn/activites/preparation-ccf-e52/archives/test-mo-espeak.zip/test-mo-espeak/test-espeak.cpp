#include <iostream>
#include <string>
#include <cstring>
#include <unistd.h>

using namespace std;

#include "espeak/speak_lib.h"

/* $ sudo apt-get install libespeak-dev */

/* g++ -o test-espeak test-espeak.cpp -lespeak */

void liste()
{
   const espeak_VOICE **voices = NULL;
   espeak_VOICE voice_select;
   const espeak_VOICE *v;
   
   voices = espeak_ListVoices(NULL);
   
   for(int ix=0; (v = voices[ix]) != NULL; ix++)
   {
      cout << "Language shortsign : " << v->languages << endl;
      cout << "Identifier : " << v->identifier << endl;
      cout << "Age : " << v->age << endl;
      cout << "Gender : " << v->gender << endl;
      cout << "Name : " << v->name << endl;
      cout << "Variant : " << v->variant << endl;
      cout << endl;
   }
}

void version()
{
    const char *eSpeakVersionInfo = NULL;
    
    eSpeakVersionInfo = espeak_Info(NULL);
    cout << "SyntheseVocale version : " << eSpeakVersionInfo << endl;
}


int main()
{   
    string texte = "alarme température";
    string voice("mb-fr1"); // ("fr") ou ("fr+f3")
    int speed = 130; // espeakRATE
    int volume = 80; // espeakVOLUME
    int pitch = 40; // espakPITCH
    int range = 60; // espeakRANGE
    int punctuation = 0; // espeakPUNCTUATION
    int gender = 2;
    int samplerate = 22050;
    const char *data_path = NULL; // use default path for espeak-data
    
    version();
   
    samplerate = espeak_Initialize(AUDIO_OUTPUT_PLAYBACK, 0, data_path, 0);
    //samplerate = espeak_Initialize(AUDIO_OUTPUT_SYNCH_PLAYBACK, 0, data_path, 0);
    cout << "Samplerate : " << samplerate << endl;

    if(espeak_SetVoiceByName(voice.c_str()) != EE_OK)
        cerr << "espeak_SetVoiceByName error !" << endl;
    else
    {
        cout << "Selected language : " << voice << endl;
    }

    cout << "Gender : " << gender << endl;
    if(gender >= 0 && gender <= 2)
    {
        espeak_VOICE *voice_spec = espeak_GetCurrentVoice();
        //memset(voice_spec, 0, sizeof(espeak_VOICE)); // Zero out the voice first
        //voice_spec->languages = "fr";
        //voice_spec->identifier = "mb-fr1";
        voice_spec->gender = gender;
        //voice_spec->age = 25;
        //voice_spec->variant = 1;
        int status = espeak_SetVoiceByProperties(voice_spec);
        //cout << "Status : " << status << endl;
        voice_spec = espeak_GetCurrentVoice();
        //cout << "Language shortsign : " << voice_spec->languages << endl;
        //cout << "Identifier : " << voice_spec->identifier << endl;
        //cout << "Age : " << (int)voice_spec->age << endl;
        //cout << "Gender : " << (int)voice_spec->gender << endl;
        //cout << "Name : " << voice_spec->name << endl;
        //cout << "Variant : " << (int)voice_spec->variant << endl;
        //cout << endl;
    }
      
    cout << "Speed : " << speed << endl;
    if(speed >= 80 && speed <= 450)
    {
      espeak_SetParameter(espeakRATE, speed, 0);
    }
    cout << "Volume : " << volume << endl;
    // volume in range 0-100 (0=silence)
    if(volume >= 0 && volume <= 100)
    {
      espeak_SetParameter(espeakVOLUME, volume, 0);
    }
    cout << "Pitch : " << pitch << endl;
    // base pitch in range 0-100 (50=normal)
    if(pitch >= 0 && pitch <= 100)
    {
      espeak_SetParameter(espeakPITCH, pitch, 0);
    }
    cout << "Range : " << range << endl;
    // pitch range in range 0-100 (0=monotone, 50=normal)
    if(range >= 0 && range <= 100)
    {
      espeak_SetParameter(espeakRANGE, range, 0);
    }
    cout << "Punctuation : " << punctuation << endl;
    // 0 no punctuation, 1 say punctuation
    if(punctuation >= 0 && punctuation <= 1)
    {
      espeak_SetParameter(espeakPUNCTUATION, punctuation, 0);
    }    

    cout << "-- " << texte << endl;
    espeak_Synth((char *)texte.c_str(), texte.length()+1, 0, POS_CHARACTER, 0, espeakCHARS_AUTO, NULL, NULL);
    espeak_Synchronize(); // appel bloquant
   
    return 0;
}
