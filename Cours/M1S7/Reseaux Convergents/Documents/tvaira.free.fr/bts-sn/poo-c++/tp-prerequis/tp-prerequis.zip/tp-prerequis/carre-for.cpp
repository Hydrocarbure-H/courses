// Calcule et affiche le carré d'un nombre (for)

#include <iostream>
#include <cmath>

using namespace std;

int main()
{
   // exécute le bloc d'instructions de la boucle :
   // avec i commençant à 0 (initialisation)
   // tant que i est inférieur strict à 100 (condition)
   // en incrémentant i après chaque exécution du bloc d'instruction (opération d'incrémentation)
   for (int i = 0; i < 100; i++)
      cout << i << '\t' << pow(i, 2) << '\n'; // affiche i et son carré séparés par une tabulation
      
   return 0;
}
