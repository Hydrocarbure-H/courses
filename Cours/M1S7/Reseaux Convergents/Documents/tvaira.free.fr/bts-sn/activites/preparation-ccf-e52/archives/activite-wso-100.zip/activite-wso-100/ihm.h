#ifndef IHM_H
#define IHM_H

#include <QtGui>

#define DEBUG_IHM

class StationMeteo;
class QwtCompass;
class QwtThermo;

class IHM : public QWidget
{
    Q_OBJECT

public:
    IHM( QWidget *parent = 0 );
    ~IHM();

private:
    QString         lieu;
    int             periode;
    int             pgnWindData;
    int             pgnEnvironmentalParameters;
    QTimer          *timerStationMeteo;
    StationMeteo    *stationMeteo;

    // Widgets    
    QLabel          *labelLieu;
    QLineEdit       *leLieu;
    QLabel          *labelPeriode;
    QLineEdit       *lePeriode;
    QPushButton     *bDemarrer;
    QPushButton     *bArreter;
    QTextEdit       *message;
    QwtCompass      *compassDirectionVent;
    QwtThermo       *thermoTemperature;
    
    void            lireParametres();

signals:
    void            quit();

public slots:    
    void            quitter();
    void            demarrer();
    void            arreter();
    void            acquerir();
    void            majLieu();
    void            majPeriode();
};

#endif // IHM_H
