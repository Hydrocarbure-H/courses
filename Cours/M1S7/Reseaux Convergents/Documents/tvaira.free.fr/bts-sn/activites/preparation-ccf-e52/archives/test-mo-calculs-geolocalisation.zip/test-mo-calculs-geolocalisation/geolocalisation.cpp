#include <iostream>
#include <sstream> // stringstream !
#include <string>
#include <cmath>

using namespace std;

#include "geolocalisation.h"

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*  Latitude/longitude spherical geodesy formulae & scripts (c) Chris Veness 2002-2012            */
/*   - www.movable-type.co.uk/scripts/latlong.html                                                */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*  Sample usage:                                                                                 */
/*    double p1 = new Geolocalisation(51.5136, -0.0983);                                                      */
/*    double p2 = new Geolocalisation(51.4778, -0.0015);                                                      */
/*    double dist = p1.distanceTo(p2);          // in km                                             */
/*    double brng = p1.bearingTo(p2);           // in degres clockwise from north                   */
/*    ... etc                                                                                     */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */


/**
 * Creates a point on the earth's surface at the supplied latitude / longitude
 *
 * @constructor
 * @param {double} latitude : latitude in numeric degres
 * @param {double} longitude : longitude in numeric degres
 * @param {double} [rayonTerre=6371] : radius of earth if different value is required from standard 6,371km
 */
Geolocalisation::Geolocalisation(double latitude, double longitude, double rayonTerre/*=6371*/):latitude(latitude),longitude(longitude),rayonTerre(rayonTerre)
{
}

/**
 * Returns the distance from this point to the supplied point, in km 
 * (using Haversine formula)
 *
 * from: Haversine formula - R. W. Sinnott, "Virtues of the Haversine",
 *       Sky and Telescope, vol 68, no 2, 1984
 *
 * @param   {Geolocalisation} point : Latitude/longitude of destination point
 * @param   {int} [precision=4]: no of significant digits to use for returned value (default 4 sig figs reflects typical 0.3% accuracy of spherical model)
 * @returns {double} Distance in km between this point and destination point
 */
double Geolocalisation::distance(const Geolocalisation & point, int precision/*=4*/) 
{
  double R = this->rayonTerre;
  double lat1 = radians(this->latitude), lon1 = radians(this->longitude);
  double lat2 = radians(point.latitude), lon2 = radians(point.longitude);
  double dLat = lat2 - lat1;
  double dLon = lon2 - lon1;

  double a = sin(dLat/2) * sin(dLat/2) + cos(lat1) * cos(lat2) * sin(dLon/2) * sin(dLon/2);
  double c = 2 * atan2(sqrt(a), sqrt(1-a));
  double d = R * c;
  return d;//toPrecisionFixed(precision);
}


/**
 * Returns the (initial) bearing from this point to the supplied point, in degres
 *   see http://williams.best.vwh.net/avform.htm#Crs
 *
 * @param   {Geolocalisation} point : Latitude/longitude of destination point
 * @returns {double} Initial bearing in degres from North
 */
double Geolocalisation::orientation(const Geolocalisation & point)
{
  double lat1 = radians(this->latitude), lat2 = radians(point.latitude);
  double dLon = radians(point.longitude - this->longitude);

  double y = sin(dLon) * cos(lat2);
  double x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon);
  double brng = atan2(y, x);
  
  //return (degres(brng) + 360) % 360;
  return fmod((degres(brng) + 360), 360);
}


/**
 * Returns final bearing arriving at supplied destination point from this point; the final bearing 
 * will differ from the initial bearing by varying degres according to distance and latitude
 *
 * @param   {Geolocalisation} point: Latitude/longitude of destination point
 * @returns {double} Final bearing in degres from North
 */
double Geolocalisation::orientationFinale(const Geolocalisation & point)
{
  double lat1 = radians(point.latitude), lat2 = radians(this->latitude);
  double dLon = radians(this->longitude - point.longitude);

  double y = sin(dLon) * cos(lat2);
  double x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon);
  double brng = atan2(y, x);
  
  // ... & reverse it by adding 180°
  //return (degres(brng) + 180) % 360;
  return fmod((degres(brng) + 180), 360);
}

/**
 * Returns the midpoint between this point and the supplied point.
 *   see http://mathforum.org/library/drmath/view/51822.html for derivation
 *
 * @param   {Geolocalisation} point: Latitude/longitude of destination point
 * @returns {Geolocalisation} Midpoint between this point and the supplied point
 */
Geolocalisation* Geolocalisation::milieu(const Geolocalisation & point)
{
  double lat1 = radians(this->latitude), lon1 = radians(this->longitude);    
  double lat2 = radians(point.latitude);
  double dLon = radians(point.longitude - this->longitude);

  double Bx = cos(lat2) * cos(dLon);
  double By = cos(lat2) * sin(dLon);

  double lat3 = atan2(sin(lat1) + sin(lat2), sqrt( (cos(lat1) + Bx) * (cos(lat1) + Bx) + By * By) );
  double lon3 = lon1 + atan2(By, cos(lat1) + Bx);
  //lon3 = (lon3 + 3*PI) % (2*PI) - PI;  // normalise to -180..+180º
  lon3 = fmod((lon3 + 3*PI), (2*PI) - PI);  // normalise to -180..+180º
  
  return new Geolocalisation(degres(lat3), degres(lon3));
}


/**
 * Returns the destination point from this point having travelled the given distance (in km) on the 
 * given initial bearing (bearing may vary before destination is reached)
 *
 *   see http://williams.best.vwh.net/avform.htm#LL
 *
 * @param   {double} brng: Initial bearing in degres
 * @param   {double} dist: Distance in km
 * @returns {Geolocalisation} Destination point
 */
Geolocalisation* Geolocalisation::destination(double brng, double dist) 
{
  dist = dist/this->rayonTerre;  // convert dist to angular distance in radians
  brng = radians(brng);  // 
  double lat1 = radians(this->latitude), lon1 = radians(this->longitude);

  double lat2 = asin( sin(lat1)*cos(dist) + cos(lat1)*sin(dist)*cos(brng) );
  double lon2 = lon1 + atan2(sin(brng)*sin(dist)*cos(lat1), cos(dist)-sin(lat1)*sin(lat2));
  //lon2 = (lon2+3*PI) % (2*PI) - PI;  // normalise to -180..+180º
  lon2 = fmod((lon2+3*PI), (2*PI) - PI);  // normalise to -180..+180º

  return new Geolocalisation(degres(lat2), degres(lon2));
}


/**
 * Returns the point of intersection of two paths defined by point and bearing
 *
 *   see http://williams.best.vwh.net/avform.htm#Intersection
 *
 * @param   {Geolocalisation} p1: First point
 * @param   {double} brng1: Initial bearing from first point
 * @param   {Geolocalisation} p2: Second point
 * @param   {double} brng2: Initial bearing from second point
 * @returns {Geolocalisation} Destination point (NULL if no unique intersection defined)
 */
Geolocalisation* Geolocalisation::intersection(const Geolocalisation & p1, double brng1, const Geolocalisation & p2, double brng2) 
{
  double lat1 = radians(p1.latitude), lon1 = radians(p1.longitude);
  double lat2 = radians(p2.latitude), lon2 = radians(p2.longitude);
  double brng13 = radians(brng1), brng23 = radians(brng2);
  double dLat = lat2-lat1, dLon = lon2-lon1;
  
  double dist12 = 2*asin( sqrt( sin(dLat/2)*sin(dLat/2) + cos(lat1)*cos(lat2)*sin(dLon/2)*sin(dLon/2) ) );
  if (dist12 == 0) return NULL;
  
  // initial/final bearings between points
  double brngA = acos( ( sin(lat2) - sin(lat1)*cos(dist12) ) / ( sin(dist12)*cos(lat1) ) );
  if (isnan(brngA)) brngA = 0;  // protect against rounding
  double brngB = acos( ( sin(lat1) - sin(lat2)*cos(dist12) ) / ( sin(dist12)*cos(lat2) ) );
  
  double brng12, brng21;
  if (sin(lon2-lon1) > 0) 
  {
    brng12 = brngA;
    brng21 = 2*PI - brngB;
  } 
  else 
  {
    brng12 = 2*PI - brngA;
    brng21 = brngB;
  }
  
  //double alpha1 = (brng13 - brng12 + PI) % (2*PI) - PI;  // angle 2-1-3
  double alpha1 = fmod((brng13 - brng12 + PI), (2*PI) - PI);  // angle 2-1-3
  //double alpha2 = (brng21 - brng23 + PI) % (2*PI) - PI;  // angle 1-2-3
  double alpha2 = fmod((brng21 - brng23 + PI), (2*PI) - PI);  // angle 1-2-3
  
  if (sin(alpha1)==0 && sin(alpha2)==0) return NULL;  // infinite intersections
  if (sin(alpha1)*sin(alpha2) < 0) return NULL;       // ambiguous intersection
  
  //alpha1 = abs(alpha1);
  //alpha2 = abs(alpha2);
  // ... Ed Williams takes abs of alpha1/alpha2, but seems to break calculation?
  
  double alpha3 = acos( -cos(alpha1)*cos(alpha2) + sin(alpha1)*sin(alpha2)*cos(dist12) );
  double dist13 = atan2( sin(dist12)*sin(alpha1)*sin(alpha2), cos(alpha2)+cos(alpha1)*cos(alpha3) );
  double lat3 = asin( sin(lat1)*cos(dist13) + cos(lat1)*sin(dist13)*cos(brng13) );
  double dLon13 = atan2( sin(brng13)*sin(dist13)*cos(lat1), cos(dist13)-sin(lat1)*sin(lat3) );
  double lon3 = lon1+dLon13;
  //lon3 = (lon3+3*PI) % (2*PI) - PI;  // normalise to -180..+180º
  lon3 = fmod((lon3+3*PI), (2*PI) - PI);  // normalise to -180..+180º
  
  return new Geolocalisation(degres(lat3), degres(lon3));
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */

/**
 * Returns the distance from this point to the supplied point, in km, travelling along a rhumb line
 *
 *   see http://williams.best.vwh.net/avform.htm#Rhumb
 *
 * @param   {Geolocalisation} point: Latitude/longitude of destination point
 * @returns {double} Distance in km between this point and destination point
 */
double Geolocalisation::rhumbDistanceTo(const Geolocalisation & point) 
{
  double R = this->rayonTerre;
  double lat1 = radians(this->latitude), lat2 = radians(point.latitude);
  double dLat = radians(point.latitude-this->latitude);
  double dLon = abs(radians(point.longitude-this->longitude));
  
  double dPhi = log(tan(lat2/2+PI/4)/tan(lat1/2+PI/4));
  double q = (isfinite(dLat/dPhi)) ? dLat/dPhi : cos(lat1);  // E-W line gives dPhi=0
  
  // if dLon over 180° take shorter rhumb across anti-meridian:
  if (abs(dLon) > PI) 
  {
    dLon = dLon>0 ? -(2*PI-dLon) : (2*PI+dLon);
  }
  
  double dist = sqrt(dLat*dLat + q*q*dLon*dLon) * R; 
  
  return dist;//.toPrecisionFixed(4);  // 4 sig figs reflects typical 0.3% accuracy of spherical model
}

/**
 * Returns the bearing from this point to the supplied point along a rhumb line, in degres
 *
 * @param   {Geolocalisation} point: Latitude/longitude of destination point
 * @returns {double} Bearing in degres from North
 */
double Geolocalisation::rhumbBearingTo(const Geolocalisation & point) 
{
  double lat1 = radians(this->latitude), lat2 = radians(point.latitude);
  double dLon = radians(point.longitude-this->longitude);
  
  double dPhi = log(tan(lat2/2+PI/4)/tan(lat1/2+PI/4));
  if (abs(dLon) > PI) dLon = dLon>0 ? -(2*PI-dLon) : (2*PI+dLon);
  double brng = atan2(dLon, dPhi);
  
  //return (degres(brng)+360) % 360;
  return fmod((degres(brng)+360), 360);
}

/**
 * Returns the destination point from this point having travelled the given distance (in km) on the 
 * given bearing along a rhumb line
 *
 * @param   {double} brng: Bearing in degres from North
 * @param   {double} dist: Distance in km
 * @returns {Geolocalisation} Destination point
 */
Geolocalisation* Geolocalisation::rhumbDestinationPoint(double brng, double dist) 
{
  double R = this->rayonTerre;
  double d = dist/R;  // d = angular distance covered on earth’s surface
  double lat1 = radians(this->latitude), lon1 = radians(this->longitude);
  brng = radians(brng);

  double dLat = d*cos(brng);
  // nasty kludge to overcome ill-conditioned results around parallels of latitude:
  if (abs(dLat) < 1e-10) dLat = 0; // dLat < 1 mm
  
  double lat2 = lat1 + dLat;
  double dPhi = log(tan(lat2/2+PI/4)/tan(lat1/2+PI/4));
  double q = (isfinite(dLat/dPhi)) ? dLat/dPhi : cos(lat1);  // E-W line gives dPhi=0
  double dLon = d*sin(brng)/q;
  
  // check for some daft bugger going past the pole, normalise latitude if so
  if (abs(lat2) > PI/2) lat2 = lat2>0 ? PI-lat2 : -PI-lat2;
  
  //double lon2 = (lon1+dLon+3*PI)%(2*PI) - PI;
  double lon2 = fmod((lon1+dLon+3*PI), (2*PI) - PI);
 
  return new Geolocalisation(degres(lat2), degres(lon2));
}

/**
 * Returns the loxodromic midpoint (along a rhumb line) between this point and the supplied point.
 *   see http://mathforum.org/kb/message.jspa?messageID=148837
 *
 * @param   {Geolocalisation} point: Latitude/longitude of destination point
 * @returns {Geolocalisation} Midpoint between this point and the supplied point
 */
Geolocalisation* Geolocalisation::rhumbMidpointTo(const Geolocalisation & point) 
{
  double lat1 = radians(this->latitude), lon1 = radians(this->longitude);
  double lat2 = radians(point.latitude), lon2 = radians(point.longitude);
  
  if (abs(lon2-lon1) > PI) lon1 += 2*PI; // crossing anti-meridian
  
  double lat3 = (lat1+lat2)/2;
  double f1 = tan(PI/4 + lat1/2);
  double f2 = tan(PI/4 + lat2/2);
  double f3 = tan(PI/4 + lat3/2);
  double lon3 = ( (lon2-lon1)*log(f3) + lon1*log(f2) - lon2*log(f1) ) / log(f2/f1);
  
  if (!isfinite(lon3)) lon3 = (lon1+lon2)/2; // parallel of latitude
  
  //lon3 = (lon3+3*PI) % (2*PI) - PI;  // normalise to -180..+180º
  lon3 = fmod((lon3+3*PI), (2*PI) - PI);  // normalise to -180..+180º
  
  return new Geolocalisation(degres(lat3), degres(lon3));
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */


/**
 * Returns the latitude of this point; signed numeric degres if no format, otherwise format & dp 
 * as per Geo.toLat()
 *
 * @param   {string} [format]: Return value as 'd', 'dm', 'dms'
 * @param   {int} [dp=0|2|4]: No of decimal places to display
 * @returns {double|string} Numeric degres if no format specified, otherwise deg/min/sec
 */
double Geolocalisation::getLatitude() 
{
  return this->latitude;
}

string Geolocalisation::getLatitude(string format, int dp) 
{
  return toString(this->latitude, format, dp);
}

/**
 * Returns the longitude of this point; signed numeric degres if no format, otherwise format & dp 
 * as per Geo.toLon()
 *
 * @param   {string} [format]: Return value as 'd', 'dm', 'dms'
 * @param   {int} [dp=0|2|4]: No of decimal places to display
 * @returns {double|string} Numeric degres if no format specified, otherwise deg/min/sec
 */
double Geolocalisation::getLongitude() 
{
  return this->longitude;
}

string Geolocalisation::getLongitude(string format, int dp) 
{
  return toString(this->longitude, format, dp);
}

/**
 * Returns a string representation of this point; format and dp as per lat()/lon()
 *
 * @param   {string} [format]: Return value as 'd', 'dm', 'dms'
 * @param   {int} [dp=0|2|4]: No of decimal places to display
 * @returns {string} Comma-separated latitude/longitude
 */
string Geolocalisation::toString(double x, string format, int dp)
{
  if (isnan(x)) return "-";  // give up here if we can't make a number from deg
  
  string dms; 
  double deg = abs(x);  // (unsigned result ready for appending compass dir'n)
  
//   switch (format) {
//     case 'd':
//       d = deg.toFixed(dp);     // round degres
//       if (d<100) d = '0' + d;  // pad with leading zeros
//       if (d<10) d = '0' + d;
//       dms = d + '\u00B0';      // add º symbol
//       break;
//     case 'dm':
//       double min = (deg*60).toFixed(dp);  // convert degres to minutes & round
//       double d = floor(min / 60);    // get component deg/min
//       double m = (min % 60).toFixed(dp);  // pad with trailing zeros
//       if (d<100) d = '0' + d;          // pad with leading zeros
//       if (d<10) d = '0' + d;
//       if (m<10) m = '0' + m;
//       dms = d + '\u00B0' + m + '\u2032';  // add º, ' symbols
//       break;
//     case 'dms':
//       double sec = (deg*3600).toFixed(dp);  // convert degres to seconds & round
//       double d = floor(sec / 3600);    // get component deg/min/sec
//       double m = floor(sec/60) % 60;
//       double s = (sec % 60).toFixed(dp);    // pad with trailing zeros
//       if (d<100) d = '0' + d;            // pad with leading zeros
//       if (d<10) d = '0' + d;
//       if (m<10) m = '0' + m;
//       if (s<10) s = '0' + s;
//       dms = d + '\u00B0' + m + '\u2032' + s + '\u2033';  // add º, ', " symbols
//       break;
//   }
   return dms;
}

string Geolocalisation::toString(string format, int dp) 
{
  string representation = "";//toString(this->latitude, format, dp) + ', ' + toString(this->longitude, format, dp);
  return representation;
}

string Geolocalisation::doubleToString(double n) 
{    
   std::ostringstream oss; 
   oss << n; 
   return oss.str(); 
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */

// ---- methods for converting degres/radians

/** Converts numeric degres to radians */
double Geolocalisation::radians(double x) 
{
    return x * PI / 180.0;
}

/** Converts radians to numeric (signed) degres */
double Geolocalisation::degres(double x) 
{
    return x * 180.0 / PI;
}


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*  Geodesy representation conversion functions (c) Chris Veness 2002-2012                        */
/*   - www.movable-type.co.uk/scripts/latlong.html                                                */
/*                                                                                                */
/*  Sample usage:                                                                                 */
/*    double lat = Geo.parseDMS('51° 28′ 40.12″ N');                                                 */
/*    double lon = Geo.parseDMS('000° 00′ 05.31″ W');                                                */
/*    double p1 = new Geolocalisation(lat, lon);                                                              */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */

/**
 * Parses string representing degres/minutes/seconds into numeric degres
 *
 * This is very flexible on formats, allowing signed decimal degres, or deg-min-sec optionally
 * suffixed by compass direction (NSEW). A variety of separators are accepted (eg 3º 37' 09"W) 
 * or fixed-width format without separators (eg 0033709W). Seconds and minutes may be omitted. 
 * (Note minimal validation is done).
 *
 * @param   {string} dmsStr: Degrees or deg/min/sec in variety of formats
 * @returns {double} Degrees as decimal number
 */
// double Geolocalisation::parseDMS(string dmsStr) 
// {
//   if (dms == '') return NAN;
//   
//   // and convert to decimal degres...
//   switch (dms.length) {
//     case 3:  // interpret 3-part result as d/m/s
//       double deg = dms[0]/1 + dms[1]/60 + dms[2]/3600; 
//       break;
//     case 2:  // interpret 2-part result as d/m
//       double deg = dms[0]/1 + dms[1]/60; 
//       break;
//     case 1:  // just d (possibly decimal) or non-separated dddmmss
//       double deg = dms[0];
//       // check for fixed-width unseparated format eg 0033709W
//       //if (/[NS]/i.test(dmsStr)) deg = '0' + deg;  // - normalise N/S to 3-digit degres
//       //if (/[0-9]{7}/.test(deg)) deg = deg.slice(0,3)/1 + deg.slice(3,5)/60 + deg.slice(5)/3600; 
//       break;
//     default:
//       return NAN;
//   }
//   //if (/^-|[WS]$/i.test(dmsStr.trim())) deg = -deg; // take '-', west and south as -ve
//   return deg;
// }


/**
 * Convert numeric degres to deg/min/sec latitude (suffixed with N/S)
 *
 * @param   {double} deg: Degrees
 * @param   {string} [format=dms]: Return value as 'd', 'dm', 'dms'
 * @param   {int} [dp=0|2|4]: No of decimal places to use - default 0 for dms, 2 for dm, 4 for d
 * @returns {string} Deg/min/seconds
 */
// Geo.toLat(double deg, string format, int dp) 
// {
//   double lat = Geo.toDMS(deg, format, dp);
//   return lat==NULL ? '–' : lat.slice(1) + (deg<0 ? 'S' : 'N');  // knock off initial '0' for lat!
// }


/**
 * Convert numeric degres to deg/min/sec longitude (suffixed with E/W)
 *
 * @param   {double} deg: Degrees
 * @param   {string} [format=dms]: Return value as 'd', 'dm', 'dms'
 * @param   {int} [dp=0|2|4]: No of decimal places to use - default 0 for dms, 2 for dm, 4 for d
 * @returns {string} Deg/min/seconds
 */
// Geo.toLon(double deg, string format, int dp) 
// {
//   double lon = Geo.toDMS(deg, format, dp);
//   return lon==NULL ? '–' : lon + (deg<0 ? 'W' : 'E');
// }


/**
 * Convert numeric degres to deg/min/sec as a bearing (0º..360º)
 *
 * @param   {double} deg: Degrees
 * @param   {string} [format=dms]: Return value as 'd', 'dm', 'dms'
 * @param   {int} [dp=0|2|4]: No of decimal places to use - default 0 for dms, 2 for dm, 4 for d
 * @returns {string} Deg/min/seconds
 */
// Geo.toBrng(double deg, string format, int dp) 
// {
//   deg = (Number(deg)+360) % 360;  // normalise -ve values to 180º..360º
//   double brng =  Geo.toDMS(deg, format, dp);
//   return brng==NULL ? '–' : brng.replace('360', '0');  // just in case rounding took us up to 360º!
// }
