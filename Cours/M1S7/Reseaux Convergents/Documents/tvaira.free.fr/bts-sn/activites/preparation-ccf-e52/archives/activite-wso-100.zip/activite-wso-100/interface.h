#ifndef INTERFACE_H
#define INTERFACE_H

#include <iostream>
#include <string>
#include <ctime>
#include <clocale>

//#define INTERFACE_SIMULATION

#ifndef INTERFACE_SIMULATION
#include <libpcan.h>
#else
#include <stdlib.h>
#include <sys/time.h>
#include <sys/timeb.h>
#include <math.h>
#include <linux/types.h>
#include <QTime>

#define DWORD  __u32
#define WORD   __u16
#define BYTE   __u8
// MSGTYPE bits of element MSGTYPE in structure TPCANMsg
#define MSGTYPE_STATUS        0x80     // used to mark a status TPCANMsg
#define MSGTYPE_EXTENDED      0x02     // declares a extended frame
#define MSGTYPE_RTR           0x01     // marks a remote frame
#define MSGTYPE_STANDARD      0x00     // marks a standard frame

typedef struct 
{
  DWORD ID;              // 11/29 bit code
  BYTE  MSGTYPE;         // bits of MSGTYPE_*
  BYTE  LEN;             // count of data bytes (0..8)
  BYTE  DATA[8];         // data bytes, up to 8
} TPCANMsg;              // for PCAN_WRITE_MSG

typedef struct
{
  TPCANMsg Msg;          // the above message
  DWORD    dwTime;       // a timestamp in msec, read only
  WORD     wUsec;        // remainder in micro-seconds
} TPCANRdMsg;            // for PCAN_READ_MSG
#endif
#include <cstdio>

#define INTERFACE_DEFAUT "/dev/pcan0"

//#define DEBUG_INTERFACE

using namespace std;

class InterfacePeakNMEA2000
{
	private:
    #ifndef INTERFACE_SIMULATION
    HANDLE   handle;
    bool     initialise;
    __u16    wBTR0BTR1;
    int      nExtended;
    string   interface;
    #else
    bool     initialise;
    string   interface;
      
    void  simuler(TPCANMsg &message);
    BYTE  genererData();
    void  genererDonneesVent(BYTE bData[8]);
    void  genererDonneesEnvironnement(BYTE bData[8]);
    float generer(long min, long max);
    #endif
		
	protected:
	
	public:
		InterfacePeakNMEA2000();
		~InterfacePeakNMEA2000();
      
    bool initialiser();
    void fermer();
    int  obtenirMessage(int pgn, TPCANMsg &message);
    int  obtenirMessage(int pgn, TPCANMsg &message, time_t &timestamp);
    void afficherMessage(TPCANMsg *m);
    void afficherInfos();
};

#endif
