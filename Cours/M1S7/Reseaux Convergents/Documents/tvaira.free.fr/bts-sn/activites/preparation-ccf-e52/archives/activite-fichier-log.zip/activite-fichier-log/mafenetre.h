#ifndef MAFENETRE_H
#define MAFENETRE_H

#include <QtGui>
#include <QMessageBox>
#include <QDebug>

#define NB_INTERFACES 4

#define JOURNALISATION

class Log;

class MaFenetre : public QWidget
{
    Q_OBJECT
public:
    explicit MaFenetre(QWidget *parent = 0);
    ~MaFenetre();
    
private:
    QLabel              *labelListe;
    QComboBox           *listeInterfaces;
    QPushButton         *boutonAjouter;
    QPushButton         *boutonSupprimer;
    Log                 *log; // pour la journalisation des messages

    void creerListe();

signals:
    
public slots:
    void ajouter();
    void supprimer();
    void selectionner(QString interface);
};

#endif // MAFENETRE_H
