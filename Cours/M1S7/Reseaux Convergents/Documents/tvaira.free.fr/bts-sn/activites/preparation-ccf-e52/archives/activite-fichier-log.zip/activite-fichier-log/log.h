#ifndef LOG_H
#define LOG_H

#include <QObject>
#include <QFile>
#include <QTextStream>
#include <QDateTime>
#include <QMutex>
#include <QCoreApplication>
#include <QDebug>

// Classe singleton

class Log : public QObject
{
    Q_OBJECT
public:
    static Log* getInstance();
    static void detruireInstance();
    void        journaliser(const QString &message);

private:
    static Log* _log;
    static int  nbAcces;
    QFile       *log;
    QMutex      mutex;

    explicit Log(QObject *parent = 0);

signals:
    
public slots:


};

#endif // LOG_H
