#include <stdio.h>
#include <stdlib.h> /* pour exit et atoi */
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h> /* pour memset */
#include <netinet/in.h> /* pour struct sockaddr_in */
#include <arpa/inet.h> /* pour htons et inet_aton */
#include <netdb.h> /* pour getaddrinfo */

#define LG_MESSAGE   256

int main(int argc, char *argv[])
{
   int descripteurSocket;
   char messageEnvoi[LG_MESSAGE]; /* le message de la couche Application ! */  
   char messageRecu[LG_MESSAGE]; /* le message de la couche Application ! */  
   int ecrits, lus; /* nb d'octets ecrits et lus */
   int retour;
   struct addrinfo hints;
   struct addrinfo *result, *rp;

   // Il faut 2 arguments à ce programme
   if (argc < 2)
   {
      fprintf(stderr, "Erreur : argument manquant !\n"); 
      fprintf(stderr, "Usage : %s adresse_ip numero_port\n", argv[0]); 
      exit(-5); // On sort en indiquant un code erreur
   }
   
   // Obtenir un point de communication distant correspondant au couple nom/port fourni en argument
   memset(&hints, 0, sizeof(struct addrinfo));
   hints.ai_family = PF_INET;    // sinon AF_UNSPEC pour IPv4 ou IPv6
   hints.ai_socktype = SOCK_STREAM; // mode connecté
   hints.ai_flags = 0; // options supplémentaires, ici aucune
   hints.ai_protocol = 0; // n'importe quel type

   retour = getaddrinfo(argv[1], argv[2], &hints, &result);
   if (retour != 0) 
   {
      fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(retour)); // Affiche le message d'erreur
      exit(-6); // On sort en indiquant un code erreur
   }
   
   // getaddrinfo() retourne une liste de structures d'adresses 
   // on cherche la première qui permettra un connect()
   for (rp = result; rp != NULL; rp = rp->ai_next) 
   {
      // Crée un socket de communication 
      descripteurSocket = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);

      // Échec ?
      if (descripteurSocket == -1)
         continue; // alors on essaye la suivante

      // Débute la connexion vers le processus serveur distant
      // Ok ?
      if((connect(descripteurSocket, rp->ai_addr, rp->ai_addrlen)) != -1)
         break; // on a trouvé une adresse valide !

      // On ferme cette ressource avant de passer à la suivante
      close(descripteurSocket);
   }

   if (rp == NULL) 
   {               
      // on a donc trouvé aucune adresse valide !
      fprintf(stderr, "Impossible de se connecter à cette adresse !\n");
      exit(-6); // On sort en indiquant un code erreur
   }

   freeaddrinfo(result); // on libère les résultats obtenus et on continue ...
   
   printf("Socket créée avec succès ! (%d)\n", descripteurSocket);
   printf("Connexion au serveur réussie avec succès !\n");
   
   // Initialise à 0 les messages
   memset(messageEnvoi, 0x00, LG_MESSAGE*sizeof(char));
   memset(messageRecu, 0x00, LG_MESSAGE*sizeof(char));
   
   // Envoie un message au serveur
   sprintf(messageEnvoi, "Hello world !\n");   
   ecrits = write(descripteurSocket, messageEnvoi, strlen(messageEnvoi)); // message à TAILLE variable
   switch(ecrits)
   {
      case -1 : /* une erreur ! */
         perror("write");
         close(descripteurSocket);
         exit(-3);
      case 0 : /* la socket est fermée */
         fprintf(stderr, "La socket a été fermée par le serveur !\n\n"); 
         close(descripteurSocket);
         return 0;
      default: /* envoi de n octets */
         // fin de l'étape n°4 !   
         printf("Message %s envoyé avec succès (%d octets)\n\n", messageEnvoi, ecrits); 
   }

   /* Reception des données du serveur */
   lus = read(descripteurSocket, messageRecu, LG_MESSAGE*sizeof(char)); /* attend un message de TAILLE fixe */
   switch(lus)
   {
      case -1 : /* une erreur ! */
         perror("read");
         close(descripteurSocket);
         exit(-4);
      case 0 : /* la socket est fermée */
         fprintf(stderr, "La socket a été fermée par le serveur !\n\n"); 
         close(descripteurSocket);
         return 0;
      default: /* réception de n octets */
         // fin de l'étape n°4 !   
         printf("Message reçu du serveur : %s (%d octets)\n\n", messageRecu, lus); 
   }
   
   // On ferme la ressource avant de quitter
   close(descripteurSocket);

   return 0;
}
