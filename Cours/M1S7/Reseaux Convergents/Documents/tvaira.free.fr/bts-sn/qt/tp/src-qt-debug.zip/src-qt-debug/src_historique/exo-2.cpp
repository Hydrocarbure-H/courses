#include <QtCore/QCoreApplication>
#include <QTextCodec>
#include <QTime>
#include <QDebug>

#include <iostream>
#include <ctime>
#include <clocale>
#include <unistd.h>

#include "historique.h"

#define NB_MESURES 200 /* pour les essais : changer cette valeur ! */

using namespace std;

Altitude mesurer(long min, long max)
{
    return static_cast<Altitude>(min + (static_cast<float>(qrand()) / RAND_MAX * (max - min + 1)));
}

int main(int argc, char **argv)
{
    QCoreApplication a(argc, argv);

    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));

    Historique historique;
    Altitude altitude;
    int i, nb = 0;
    time_t init;
    char horodatage[32];
   
    qsrand(QTime::currentTime().msec());
    setlocale(LC_TIME, "fr_FR");       
    init = time(NULL);
    strftime(horodatage, 32, "%d/%m/%Y à %T", std::localtime(&init));
    qDebug() << "Démarrage du système de journalisation le " << horodatage << "\n";
   
    /* fabrique un historique */
    for(i = 0; i < NB_MESURES; i++)
    {
        altitude = mesurer(31500, 40000); // simulation
        if(altitude >= SEUIL_ALTITUDE_ALARME)
        { 
          historique.ajouterAlarmeSolution1(altitude);
          //historique.ajouterAlarmeSolution2(altitude);
          //historique.ajouterAlarmeSolution3(altitude);
          //historique.ajouterAlarmeSolution4(altitude);
          
          qDebug() << "L'information TAlarme { " << altitude << " pieds } a été ajoutée à l'historique\n";
          ++nb;
        }
   }
   
   qDebug() << "Nombre d'alarmes : " << historique.getNbAlarmes() << " dans l'historique\n";
   qDebug() << "Nombre d'alarmes : " << nb << " au total\n\n";

   historique.afficherDerniereAlarme();
   
   historique.afficher();
   
   return 0;
}
