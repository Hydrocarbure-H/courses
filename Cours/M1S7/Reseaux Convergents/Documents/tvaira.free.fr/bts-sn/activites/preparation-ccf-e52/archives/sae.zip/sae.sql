SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `saeiv`
--
DROP DATABASE IF EXISTS sae;
CREATE DATABASE `sae` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `sae`;

-- --------------------------------------------------------
--
-- Structure de la table `organisme`
--

CREATE TABLE `organisme` (
  `idOrganisme` bigint(20) NOT NULL,
  `nomOrganisme` varchar(160) DEFAULT NULL,
  `telephone` varchar(10) DEFAULT NULL,
  `fuseauHoraire` varchar(160) DEFAULT NULL,
  `langue` varchar(160) DEFAULT NULL,
  `url` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`idOrganisme`)
);

--
-- Contenu de la table `organisme`
--

INSERT INTO `organisme` (`idOrganisme`, `nomOrganisme`, `telephone`, `fuseauHoraire`, `langue`, `url`) VALUES
(6192449487677451, 'Tisséo', '0561417070', 'Europe/Paris', 'fr', 'http://www.tisseo.fr');

-- --------------------------------------------------------
--
-- Structure de la table `conducteur`
--

CREATE TABLE `conducteur` (
  `codeConducteur` smallint(4) NOT NULL,
  `nomConducteur` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`codeConducteur`)
);

--
-- Contenu de la table `conducteur`
--

INSERT INTO `conducteur` (`codeConducteur`, `nomConducteur`) VALUES (1, 'denis darmon');
INSERT INTO `conducteur` (`codeConducteur`, `nomConducteur`) VALUES (195, 'richard boue');
INSERT INTO `conducteur` (`codeConducteur`, `nomConducteur`) VALUES (1234, 'fabrice allaire');
INSERT INTO `conducteur` (`codeConducteur`, `nomConducteur`) VALUES (1962, 'nicolas lepretre');
INSERT INTO `conducteur` (`codeConducteur`, `nomConducteur`) VALUES (1993, 'jean lapierre');
INSERT INTO `conducteur` (`codeConducteur`, `nomConducteur`) VALUES (2121, 'cyril salomon');
INSERT INTO `conducteur` (`codeConducteur`, `nomConducteur`) VALUES (3082, 'olivier piquet');
INSERT INTO `conducteur` (`codeConducteur`, `nomConducteur`) VALUES (3553, 'laurine thibault');
INSERT INTO `conducteur` (`codeConducteur`, `nomConducteur`) VALUES (6340, 'marc gross');
INSERT INTO `conducteur` (`codeConducteur`, `nomConducteur`) VALUES (7275, 'fanny delaunay');

-- --------------------------------------------------------
--
-- Structure de la table `vehicule`
--

CREATE TABLE `vehicule` (
  `idVehicule` smallint(3) NOT NULL,
  `typeVehicule` varchar(160) DEFAULT NULL,
  `capacite` smallint(3) DEFAULT NULL,
  PRIMARY KEY (`idVehicule`)
);

--
-- Contenu de la table `vehicule`
--

INSERT INTO `vehicule` (`idVehicule`, `typeVehicule`, `capacite`) VALUES (82, 'articulé', 148);
INSERT INTO `vehicule` (`idVehicule`, `typeVehicule`, `capacite`) VALUES (123, 'standard', 100);
INSERT INTO `vehicule` (`idVehicule`, `typeVehicule`, `capacite`) VALUES (155, 'standard', 100);
INSERT INTO `vehicule` (`idVehicule`, `typeVehicule`, `capacite`) VALUES (171, 'articulé', 148);
INSERT INTO `vehicule` (`idVehicule`, `typeVehicule`, `capacite`) VALUES (193, 'standard', 100);
INSERT INTO `vehicule` (`idVehicule`, `typeVehicule`, `capacite`) VALUES (204, 'articulé', 148);
INSERT INTO `vehicule` (`idVehicule`, `typeVehicule`, `capacite`) VALUES (287, 'midibus', 88);
INSERT INTO `vehicule` (`idVehicule`, `typeVehicule`, `capacite`) VALUES (345, 'midibus', 88);
INSERT INTO `vehicule` (`idVehicule`, `typeVehicule`, `capacite`) VALUES (615, 'articulé', 148);
INSERT INTO `vehicule` (`idVehicule`, `typeVehicule`, `capacite`) VALUES (679, 'midibus', 88);
INSERT INTO `vehicule` (`idVehicule`, `typeVehicule`, `capacite`) VALUES (766, 'midibus', 88);
INSERT INTO `vehicule` (`idVehicule`, `typeVehicule`, `capacite`) VALUES (986, 'articulé', 148);

-- --------------------------------------------------------
--
-- Structure de la table `ligne`
--

CREATE TABLE `ligne` (
  `idLigne` bigint(20) NOT NULL DEFAULT '0',
  `idOrganisme` bigint(20) NOT NULL,
  `nomLong` varchar(160) DEFAULT NULL,
  `nomCourt` int(11) DEFAULT NULL,
  `description` varchar(160) DEFAULT NULL,
  `type` varchar(160) DEFAULT NULL,
  `url` varchar(160) DEFAULT NULL,
  `couleurLigne` varchar(6) DEFAULT '000000',
  `couleurTexte` varchar(6) DEFAULT '000000',
  PRIMARY KEY (`idLigne`),
  CONSTRAINT fk_ligne_idOrganisme
  FOREIGN KEY (idOrganisme)
  REFERENCES organisme(idOrganisme)
);



-- --------------------------------------------------------
--
-- Structure de la table `calendrier`
--

CREATE TABLE `calendrier` (
  `idCalendrier` bigint(20) NOT NULL,
  `lundi` int(1) DEFAULT NULL,
  `mardi` int(1) DEFAULT NULL,
  `mercredi` int(1) DEFAULT NULL,
  `jeudi` int(1) DEFAULT NULL,
  `vendredi` int(1) DEFAULT NULL,
  `samedi` int(1) DEFAULT NULL,
  `dimanche` int(1) DEFAULT NULL,
  `dateDebut` date DEFAULT NULL,
  `dateFin` date DEFAULT NULL,
  PRIMARY KEY (`idCalendrier`)
);



-- --------------------------------------------------------
--
-- Structure de la table `itineraire`
--

CREATE TABLE `itineraire` (
  `idItineraire` bigint(20) NOT NULL,
  `idCalendrier` bigint(20) DEFAULT NULL,
  `idLigne` bigint(20) DEFAULT NULL,
  `destination` varchar(160) DEFAULT NULL,
  `direction` binary(1) DEFAULT NULL,
  `idTrace` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`idItineraire`),
  CONSTRAINT fk_itineraire_idCalendrier
  FOREIGN KEY (idCalendrier)
  REFERENCES calendrier(idCalendrier),
  CONSTRAINT fk_itineraire_idLigne
  FOREIGN KEY (idLigne)
  REFERENCES ligne(idLigne)
);


-- --------------------------------------------------------
--
-- Structure de la table `arret`
--

CREATE TABLE `arret` (  
  `idItineraire` bigint(20) NOT NULL DEFAULT '0',
  `idArret` bigint(20) NOT NULL DEFAULT '0',
  `numeroSequence` int(11) DEFAULT NULL,
  `heureArrivee` time DEFAULT NULL,
  `heureDepart` time DEFAULT NULL,
  `stop_headsign` varchar(16) DEFAULT NULL,
  `pickup_type` int(1) DEFAULT NULL,
  `drop_off_type` int(1) DEFAULT NULL,
  `shape_dist_traveled` varchar(16) DEFAULT NULL 
--  ,PRIMARY KEY (`idArret`,`idItineraire`),
--  CONSTRAINT fk_arret_idItineraire
--  FOREIGN KEY (idItineraire)
--  REFERENCES itineraire(idItineraire)
);

-- --------------------------------------------------------
--
-- Structure de la table `lieu`
--

CREATE TABLE `lieu` (
  `idArret` bigint(20) NOT NULL,
  `codeArret` int(11) NOT NULL,
  `nomLieu` varchar(160) DEFAULT NULL,
  `latitude` varchar(160) DEFAULT NULL,
  `longitude` varchar(160) DEFAULT NULL,
  `typeLieu` binary(1) DEFAULT NULL,
  `stationParente` bigint(20) NOT NULL,
  PRIMARY KEY (`idArret`)
);

-- --------------------------------------------------------
--
-- Structure de la table `service`
--

CREATE TABLE `service` (
  `idService` bigint(20) NOT NULL,
  `codeConducteur` smallint(4) DEFAULT NULL,
  `idVehicule` smallint(3) DEFAULT NULL,
  `dateDebut` date DEFAULT NULL,
  `heureDebut` time DEFAULT NULL,
  `dateFin` date DEFAULT NULL,  
  `heureFin` time DEFAULT NULL,
  `effectue` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`idService`),  
  CONSTRAINT fk_service_codeConducteur
  FOREIGN KEY (codeConducteur)
  REFERENCES conducteur(codeConducteur),
  CONSTRAINT fk_service_idVehicule
  FOREIGN KEY (idVehicule)
  REFERENCES vehicule(idVehicule)
);



-- --------------------------------------------------------
--
-- Structure de la table `course`
--

CREATE TABLE `course` (
  `idItineraire` bigint(20) NOT NULL,
  `idService` bigint(20) DEFAULT NULL,
  `effectue` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`idItineraire`, `idService`),
  CONSTRAINT fk_course_idItineraire
  FOREIGN KEY (idItineraire)
  REFERENCES itineraire(idItineraire),
  CONSTRAINT fk_course_idService
  FOREIGN KEY (idService)
  REFERENCES service(idService)
);


-- --------------------------------------------------------
--
-- Structure de la table `trace`
--

CREATE TABLE `trace` (
  `idTrace` bigint(20) NOT NULL,
  `pt_lat` real DEFAULT NULL,
  `pt_lon` real DEFAULT NULL,
  `pt_sequence` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`idTrace`, `pt_sequence`)
);


-- --------------------------------------------------------
--
-- Structure de la table `traces`
--

CREATE TABLE `traces` (
  `idItineraire` bigint(20) NOT NULL,
  `idTrace` bigint(20) NOT NULL,
  PRIMARY KEY (`idItineraire`, `idTrace`),
  CONSTRAINT fk_traces_idItineraire
  FOREIGN KEY (idItineraire)
  REFERENCES itineraire(idItineraire),
  CONSTRAINT fk_traces_idTrace
  FOREIGN KEY (idTrace)
  REFERENCES trace(idTrace)
);

