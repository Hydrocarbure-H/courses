#include <stdio.h>
#include <unistd.h>

int main() 
{
   if (! fork()) { printf("Fils 1 : je lance une calculatrice !\n");  }
   if (! fork()) { printf("Fils 2 : je lance éditeur de texte !\n");  }
   
   return 0;
}

