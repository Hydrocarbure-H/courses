#ifndef STATION_H
#define STATION_H

#include <QtCore>

#include "interface.h"
#include <string>
#include <fstream> /* pour ofstream */
#include <clocale>

// PGN des messages NMEA2000 de la station WSO100 (cf. doc)
#define ENVIRONMENTAL_PARAMETERS 130311 // (2 trames / s)
#define WIND_DATA                130306 // (10 trames / s)

#define DEBUG_STATION

typedef struct
{
    double                temperature;
    double                pressionAtmospherique;
    double                hygrometrie;
    time_t                timestamp;
} EnvironmentalParameters;

typedef struct
{
    double                vitesseVent;
    double                directionVent;
    time_t                timestamp;
} WindData;

class StationMeteo
{
   public:
      StationMeteo();
      StationMeteo(std::string lieu);
      ~StationMeteo();
       
      std::string   getLieu() const;
      double        getTemperature();
      double        getPressionAtmospherique();
      double        getHygrometrie();
      double        getVitesseVent();
      double        getDirectionVent();
      time_t        getTimestampEnvironmentalParameters();
      time_t        getTimestampWindData();
      string        getHorodatage(time_t timestamp);
      string        getDate(time_t timestamp);
      string        getHeure(time_t timestamp);
      void          setLieu(std::string lieu);

      void          acquerir(int pgn);
 
   private:
      std::string             lieu;
      InterfacePeakNMEA2000   interfacePeakNMEA2000;
      EnvironmentalParameters environmentalParameters;
      WindData                windData;

      TPCANMsg recuperer(int pgn);
      time_t   horodater();

      // Décode les PGN des messages NMEA2000 de la station WSO100 (cf. doc) :
      // 130311 (2 trames / s)
      // 130306 (10 trames / s)
      double extraireTemperature(const BYTE DATA[8]);
      double extrairePressionAtmospherique(const BYTE DATA[8]);
      double extraireHygrometrie(const BYTE DATA[8]);
      double extraireVitesseVent(const BYTE DATA[8]);
      double extraireDirectionVent(const BYTE DATA[8]);
};

#endif
