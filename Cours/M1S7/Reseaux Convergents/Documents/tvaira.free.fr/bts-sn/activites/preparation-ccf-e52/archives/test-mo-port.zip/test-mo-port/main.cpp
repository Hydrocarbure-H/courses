#include <QtGui/QApplication>
#include "ihm.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    a.setApplicationName("test-mo-port");

    IHM ihm;
    ihm.show();
    
    return a.exec();
}
