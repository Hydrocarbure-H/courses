<?php
require_once ('./include/config.inc.php');

define('MONITORING', true);
define('SQLITE', true);
define('MYSQL', false);
define('DEBUG', true);

if (!defined('LOAD')) 
{
    UpdateLog($config['nom'], $config['logfile']);
    UpdateLog("Période : " .$config['refresh']. " ms" , $config['logfile']);
}

if ($config["bd"] == "sqlite") 
{
    if(!class_exists('SQLite3'))
    {
        UpdateLog("SQLite 3 n'est pas supporté !", $config['logfile']);
        die("SQLite 3 n'est pas supporté !");
    }
    if (!defined('LOAD')) 
        UpdateLog("Base de données SQLite : " . $config['dbname'] , $config['logfile']);
    include ('./include/bd.inc.php');
}
else if ($config["bd"] == "mysql") 
{
    if(!class_exists('mysqli'))
    {
        if (!defined('LOAD')) 
            UpdateLog("MySQL n'est pas supporté !", $config['logfile']);
        die("MySQL n'est pas supporté !");
    }
    if (!defined('LOAD')) 
        UpdateLog("Base de données MySQL : " . $config['dbname'] , $config['logfile']);
    include ('./include/bd.inc.php');
}
else
{
    $config["bd"] = "array";    
}

function debug($var, $nom="")
{
    if (!defined('DEBUG')) 
        return;
    echo "<div class=\"ui-field-contain\"><pre style=\"padding: 10px 10px 10px 10px; color: #ff4000; border: 1px dashed red;overflow-x: auto;\"><code>";
    if(!Empty($nom))
        echo "<b>-> $".$nom." :</b>&nbsp;";
    var_dump($var);
    echo "</code></pre></div>";
}

function UpdateLog($string , $logfile)  
{
    $fh = @fopen($logfile, 'a');
    $message = "".$_SERVER['REMOTE_ADDR']." - ".strftime('[%F %T]')." ".$_SERVER['SCRIPT_FILENAME']." : ".$string."\n";
    @fwrite($fh , $message);
    @fclose($fh);
}

function toString($var)
{
    $v = print_r($var, true);
    $s = str_replace("\n", "", $v);
    $str = preg_replace('/\s\s+/', ' ', $s);
    return $str;
}

$host    = $_SERVER['HTTP_HOST'];
$uri     = rtrim(dirname($_SERVER['REQUEST_URI']), '/\\');
if (!defined('LOAD')) 
{
    UpdateLog("URI : ".$_SERVER['REQUEST_URI'], $config['logfile']);
}
define('LOAD', true);
?>
