// Lit une trame NMEA 183 sur le port série virtuel

// Attention : vérifiez le nom du fichier de périphérique et la configuration du port série

/*************************************************************
*	gcc -O2 -o nom_executable nom_source 
**************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>
#include <sys/fcntl.h>

// On fixe la taille maximum à 128 octets
#define MAX 128

//#define DEBUG

int main(void)
{
    int fd; // descripteur de fichier
    char nomPeripherique[16] = "/dev/ttyUSB0"; // nom du fichier special
    struct termios termios_p; // parametres du port
    char* buffer = (char *)NULL; // un buffer
    char c = 0; // un caractère
    int fini = 0; // fin de reception d'une trame
    int i = 0, n = 0;
    int debutTrame = 0; // debut de reception d'une trame
    
    /* Ouverture de la liaison serie */
    fd = open(nomPeripherique, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if ( fd == -1 )
    {
        perror("open"); // message d'erreur système
        //printf("Erreur d'ouverture du peripherique !\n"); // message d'erreur client
        exit(1);
    }
    fflush(NULL);
	  //printf("Peripherique ouvert avec succes !\n");

    /* Lecture des parametres courants  */
    tcgetattr(fd, &termios_p);
    /* On ignore les BREAK et les caracteres avec erreurs de parite */
    termios_p.c_iflag = IGNBRK | IGNPAR;
    /* Pas de mode de sortie particulier */
    termios_p.c_oflag = 0;
    /* Liaison a 9600 bps, 8 bits de donnees, pas de parite, lecture possible */
    termios_p.c_cflag = B9600 | CS8 | CREAD | CLOCAL;
    termios_p.c_cflag &= ~PARODD ;
    termios_p.c_cflag &= ~PARENB;
    /* Desactive le mode canonique */
    termios_p.c_lflag = 0;
    /* Caracteres immediatement disponibles */
    termios_p.c_cc[VMIN] = 1;
    termios_p.c_cc[VTIME] = 0;

    /* Sauvegarde des nouveaux parametres */
    if(tcsetattr(fd,TCSANOW,&termios_p)== -1)
    {
      perror("tcsetattr");
      close(fd);
      exit(1);
    }
    //printf("Sauvegarde de la nouvelle configuration avec succes !\n");

    /* Lecture de MAX octets */    
    buffer = (char *)malloc((MAX+1) * sizeof(char)); // on alloue un buffer
    i = 0;
    debutTrame = 0;
    do
    {
        n = read(fd, &c, 1);
        #ifdef DEBUG
        printf("read : %d -> 0x%02X ", n, (unsigned char)c);
        #endif
        // est-ce qu'on a lu 1 caractère ?
        if(n == 1) 
        {			
            // est-ce le début d'une trame ?		
            if(c == '$')
            {
              debutTrame = 1; 
            }	  		  
            // est-ce qu'on est entrain de lire une trame ?
            if(debutTrame == 1)	  
            {
              // on copie le caractère lu dans le buffer
              *(buffer + i) = c;
              i++;  	  
            }
            // est-ce que c'est la fin de la trame qu'on est entrain de lire ?
            if (debutTrame == 1 && c == '\n') 
            {
              fini = 1;
              debutTrame = 0;
            }
        }
        /*else
        {
            if(n == -1)
            {
                perror("read"); // message erreur système
                //printf("Erreur de lecture\n"); // message client
                //fini = 1;
            }
            else
            {
                printf("Aucune lecture !\n"); // message warning
            }
        }*/
    }
    while(i <= MAX && fini == 0);

    *(buffer + i) = 0x00; // fin de chaîne (attention à i > MAX !)
    
    printf("Trame lue :\n%s\n", buffer);

    /* Fermeture du port série */
    close (fd);
    //printf("Fermeture du peripherique avec succes !\n");
    
    free(buffer); // on libère la mémoire allouée
    
    return 0;
}

