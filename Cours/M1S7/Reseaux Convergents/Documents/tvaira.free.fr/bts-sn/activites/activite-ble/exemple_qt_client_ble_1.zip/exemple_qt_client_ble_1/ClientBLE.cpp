#include "ClientBLE.h"

#include <QDebug>
#include <QtEndian>

ClientBLE::ClientBLE() : m_controller(NULL), m_service(NULL), m_etatConnexion(false), m_compteur(0)
{
    qDebug() << Q_FUNC_INFO;
}

ClientBLE::~ClientBLE()
{
    if (m_controller)
        m_controller->disconnectFromDevice();
    delete m_controller;
    qDeleteAll(m_devices);
    qDebug() << Q_FUNC_INFO;
}

void ClientBLE::start()
{
    qDebug() << Q_FUNC_INFO << MON_WEMOS_LOLIN_ESP32_OLED;
    connecterAppareil(MON_WEMOS_LOLIN_ESP32_OLED);

    //qDebug() << Q_FUNC_INFO << MON_AZDELIVERY_ESP32;
    //connecterAppareil(MON_AZDELIVERY_ESP32);
}

void ClientBLE::stop()
{
    qDebug() << Q_FUNC_INFO << MON_WEMOS_LOLIN_ESP32_OLED;
    //qDebug() << Q_FUNC_INFO << MON_AZDELIVERY_ESP32;
    if (m_controller)
        m_controller->disconnectFromDevice();
}

void ClientBLE::read()
{
    if(m_service && m_characteristic.isValid())
    {
        m_service->readCharacteristic(m_characteristic);
        bool ok;
        m_compteur = m_characteristic.value().toHex().toInt(&ok, 16);
        qDebug() << Q_FUNC_INFO << m_characteristic.value() << m_compteur;
        //qDebug() << (int)qFromLittleEndian<quint8>(m_characteristic.value().constData());
        emit compteurChange();
    }
}

void ClientBLE::gererNotification(bool notification)
{
    if(m_service && m_characteristic.isValid())
    {
        QLowEnergyDescriptor descripteurNotification = m_characteristic.descriptor(QBluetoothUuid::ClientCharacteristicConfiguration);
        if (descripteurNotification.isValid())
        {
            // active la notification : 0100 ou désactive 0000
            qDebug() << Q_FUNC_INFO << "modification notification" << m_characteristic.uuid().toString() << notification;
            if(notification)
                m_service->writeDescriptor(descripteurNotification, QByteArray::fromHex("0100"));
            else
                m_service->writeDescriptor(descripteurNotification, QByteArray::fromHex("0000"));
        }
    }
}

void ClientBLE::connecterAppareil(const QString &adresseServeur)
{
    m_controller =  new QLowEnergyController(QBluetoothAddress(adresseServeur), this);

    // Slot pour la récupération des services
    connect(m_controller, SIGNAL(serviceDiscovered(QBluetoothUuid)), this, SLOT(ajouterService(QBluetoothUuid)));
    connect(m_controller, SIGNAL(connected()), this, SLOT(appareilConnecte()));
    connect(m_controller, SIGNAL(disconnected()), this, SLOT(appareilDeconnecte()));

    qDebug() << Q_FUNC_INFO << "demande de connexion";
    m_controller->setRemoteAddressType(QLowEnergyController::PublicAddress);
    m_controller->connectToDevice();
}

void ClientBLE::connecterService(QLowEnergyService *service)
{
    m_service = service;

    if (m_service->state() == QLowEnergyService::DiscoveryRequired)
    {
        // Slot pour le changement d'une caractéristique
        connect(m_service, SIGNAL(characteristicChanged(QLowEnergyCharacteristic,QByteArray)), this, SLOT(serviceCharacteristicChanged(QLowEnergyCharacteristic,QByteArray)));
        // Slot pour la récupération des caractéristiques
        connect(m_service, SIGNAL(stateChanged(QLowEnergyService::ServiceState)), this, SLOT(serviceDetailsDiscovered(QLowEnergyService::ServiceState)));

        qDebug() << Q_FUNC_INFO << "découverte des détails des services";
        m_service->discoverDetails();
    }
}

void ClientBLE::ajouterService(QBluetoothUuid serviceUuid)
{
    qDebug() << Q_FUNC_INFO << serviceUuid.toString();
    QLowEnergyService *service = m_controller->createServiceObject(serviceUuid);
    connecterService(service);
}

void ClientBLE::serviceCharacteristicChanged(const QLowEnergyCharacteristic &c, const QByteArray &value)
{
    if (c.uuid().toString() == CHARACTERISTIC_UUID)
    {
        bool ok;
        m_compteur = value.toHex().toInt(&ok, 16);
        qDebug() << Q_FUNC_INFO << value << m_compteur;
        //qDebug() << (int)qFromLittleEndian<quint8>(value.constData());
        emit compteurChange();
    }
}

void ClientBLE::serviceDetailsDiscovered(QLowEnergyService::ServiceState newState)
{
    Q_UNUSED(newState)

    // décourverte ?
    if (newState != QLowEnergyService::ServiceDiscovered)
    {
        return;
    }

    QLowEnergyService *service = qobject_cast<QLowEnergyService *>(sender());
    qDebug() << Q_FUNC_INFO << "service" << service->serviceUuid().toString();

    if (service->serviceUuid().toString() == SERVICE_UUID)
    {
        foreach (QLowEnergyCharacteristic c, service->characteristics())
        {
            qDebug() << Q_FUNC_INFO << "characteristic" << c.uuid().toString();
            if (c.uuid().toString() == CHARACTERISTIC_UUID)
            {
                qDebug() << Q_FUNC_INFO << "my characteristic" << c.uuid().toString() << c.value();
                if (c.properties() & QLowEnergyCharacteristic::Read)
                {
                    m_service = service;
                    m_characteristic = c;
                }

                QLowEnergyDescriptor descripteurNotification = c.descriptor(QBluetoothUuid::ClientCharacteristicConfiguration);
                if (descripteurNotification.isValid())
                {
                    // active la notification : 0100 ou désactive 0000
                    qDebug() << Q_FUNC_INFO << "modification notification" << c.uuid().toString();
                    service->writeDescriptor(descripteurNotification, QByteArray::fromHex("0000"));
                }
            }

            m_etatConnexion = true;
            emit connecte();
        }
    }
}

void ClientBLE::appareilConnecte()
{
    qDebug() << Q_FUNC_INFO;
    m_controller->discoverServices();
}

void ClientBLE::appareilDeconnecte()
{
    qDebug() << Q_FUNC_INFO;
    m_etatConnexion = false;
    emit connecte();
}
