#ifndef ClientBLE_H
#define ClientBLE_H

#include <QBluetoothDeviceDiscoveryAgent>
#include <QLowEnergyController>

#define SERVICE_UUID      "{0000ffe5-0000-1000-8000-00805f9b34fb}"
#define CHARACTERISTIC_UUID    "{0000ffe9-0000-1000-8000-00805f9b34fb}"
#define MAX_SIZE 20 // 20 octets de données max

class ClientBLE : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool appareilDetecte MEMBER m_appareilDetecte NOTIFY detecte)
    Q_PROPERTY(bool etatRecherche MEMBER m_etatRecherche NOTIFY recherche)
    Q_PROPERTY(bool etatConnexion MEMBER m_etatConnexion NOTIFY connecte)
    Q_PROPERTY(bool connexionErreur MEMBER m_connexionErreur NOTIFY erreur)
    Q_PROPERTY(QVariant listeAppareils READ getAppareils NOTIFY appareilsUpdated)

public:
    ClientBLE();
    ~ClientBLE();
    Q_INVOKABLE void rechercher();
    Q_INVOKABLE void arreter();
    Q_INVOKABLE void start(QString adresse);
    Q_INVOKABLE void stop();
    Q_INVOKABLE void read();
    Q_INVOKABLE void write(const QByteArray &data);
    Q_INVOKABLE void write(int rouge, int vert, int bleu, int white=0);
    Q_INVOKABLE void write(bool etat);
    Q_INVOKABLE void gererNotification(bool notification);
    QVariant getAppareils();

protected slots:
    void ajouterAppareil(const QBluetoothDeviceInfo&);
    void rechercheTerminee();
    void rechercheErreur(QBluetoothDeviceDiscoveryAgent::Error);
    void connecterAppareil(const QString &adresseServeur);
    void connecterService(QLowEnergyService *service);
    void ajouterService(QBluetoothUuid serviceUuid);
    void serviceDetailsDiscovered(QLowEnergyService::ServiceState newState);
    void serviceCharacteristicChanged(const QLowEnergyCharacteristic &c, const QByteArray &value);
    void appareilConnecte();
    void appareilDeconnecte();
    void connecteErreur(QLowEnergyController::Error);

private:
    QList<QObject*>                  m_devices;
    QBluetoothDeviceDiscoveryAgent  *m_discoveryAgent;
    QLowEnergyController            *m_controller;
    QLowEnergyService               *m_service;
    QLowEnergyCharacteristic         m_characteristic;
    bool                             m_etatConnexion;
    bool                             m_etatRecherche;
    bool                             m_connexionErreur;
    bool                             m_appareilDetecte;

signals:
    void connecte();
    void recherche();
    void erreur();
    void detecte();
    void appareilsUpdated();
};

#endif // ClientBLE_H
