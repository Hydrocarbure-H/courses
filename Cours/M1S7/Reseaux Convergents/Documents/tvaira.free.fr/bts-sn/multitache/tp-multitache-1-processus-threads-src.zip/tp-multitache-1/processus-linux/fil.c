#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// Fonctions :
void etoile(void);
void diese(void);

int main(void) 
{
  setbuf(stdout, NULL); // pas de tampon sur stdout

  printf("Je vais lancer les 2 fonctions\n");
  etoile();
  diese();

  return EXIT_SUCCESS;
}

void etoile(void) 
{
  int i;
  char c1 = '*';
   
  for(i=1;i<=200;i++)
  {
     write(1, &c1, 1);// écrit un caractère sur stdout (descripteur 1)
  }
  
  return;
}


void diese(void) 
{
  int i;
  char c1 = '#';
   
  for(i=1;i<=200;i++)
  {
      write(1, &c1, 1);
  }

  return;
}

