#ifndef CLIENT_H
#define CLIENT_H

#include <iostream>

using namespace std;

class Client
{
   private:
      

   public:
      Client(string nom="", int numero=0);

      

      void saisir();
};

#endif //CLIENT_H
