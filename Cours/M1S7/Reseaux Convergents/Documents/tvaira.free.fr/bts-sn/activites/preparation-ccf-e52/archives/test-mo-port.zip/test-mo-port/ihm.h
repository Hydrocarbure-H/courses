#ifndef IHM_H
#define IHM_H

#include <QtGui>

#define DEBUG_IHM

class Port;

class IHM : public QWidget
{
    Q_OBJECT

public:
    explicit IHM(QWidget *parent = 0);
    ~IHM();

private:
    QString     portPeripherique;
    int         periode;
    Port        *port;
    QTimer      *timerReception;

    QLabel      *labelPort;
    QLabel      *labelPeriode;
    QCheckBox   *cbPeriode;
    QLabel      *labelDonnees;
    QTextEdit   *donnees;

    QPushButton *bDemarrer;
    QPushButton *bArreter;
    QPushButton *bQuitter;

    void        lireConfiguration();

signals:
    void        quit();

private slots:    
    void        lire();
    void        effacer();
    void        quitter();
    void        actualiserTrame(const QString &trame);
    void        activerModePeriodique(int etat);
};

#endif // IHM_H
