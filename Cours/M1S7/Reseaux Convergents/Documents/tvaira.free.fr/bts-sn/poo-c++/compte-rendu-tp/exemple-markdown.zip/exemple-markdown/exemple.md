% TP POO C++
% Thierry Vaira <<tvaira@free.fr>>
% 18/06/2015

![Le format Mardown utilisé pour rédiger ce compte-rendu de TP](logo-markdown.png)

#  La classe Point

Lien : [Planche TP](http://tvaira.free.fr/)

## Question 1

Compléter les fichiers `Point.cpp` et `Point.h` fournis afin d'implémenter les accesseurs `getY()` et `setY()` de l'ordonnée d'un point.

* La __déclaration__ de la classe `Point` (_Point.h_) :

~~~ {.cpp}
class Point 
{
   private:
      double x;
      double y;
      
   public:
      Point(double x, double y);

      // Accesseurs
      double getX() const;
      void setX(double x);
      double getY() const;
      void setY(double y);
};
~~~

* La __définition__ des méthodes `getY()` et `setY()` de la classe ``Point`` (_Point.cpp_) :

~~~ {.cpp}
double Point::getY() const
{
   return this->y; // on retourne l'attribut y
}

void Point::setY(double y)
{
   this->y = y; // on affecte l'argument y à l'attribut y
}
~~~

[Retour au sommaire](#)

