#ifndef TEMPS_H
#define TEMPS_H

class Temps
{
    private:
        long valeur;
   
    public:
        Temps();
        Temps(long secondes);
        Temps(int heure, int minute, int seconde);
        
        int  getSeconde() const;
        int  getMinute() const;
        int  getHeure() const;
        long getValeur() const;
};

#endif //TEMPS_H
