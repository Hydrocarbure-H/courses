/****************************************************************************
**
** Copyright (C) 2011 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
** Contact: Nokia Corporation (qt-info@nokia.com)
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of Nokia Corporation and its Subsidiary(-ies) nor
**     the names of its contributors may be used to endorse or promote
**     products derived from this software without specific prior written
**     permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
** $QT_END_LICENSE$
**
****************************************************************************/

#include <QtGui>

#include "mainwindow.h"
#include "finddialog.h"

//! [0]
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setupFileMenu();
    setupEditMenu(); // définition à compléter
    setupHelpMenu();
    setupFind(); // définition à compléter
    setupEditor();

    setCentralWidget(editor);
    setWindowTitle(QString::fromUtf8("Éditeur"));
}
//! [0]

void MainWindow::about()
{
    QMessageBox::about(this, QString::fromUtf8("À propos d'Éditeur"), QString::fromUtf8("<p><b>Éditeur</b><br/>...</p>"));
}

void MainWindow::newFile()
{
    editor->clear();
}

void MainWindow::openFile(const QString &path)
{
    QString fileName = path;

    if (fileName.isNull())
        fileName = QFileDialog::getOpenFileName(this, tr("Ouvrir le fichier"), "", tr("Fichiers C++ (*.cpp *.h)"));

    if (!fileName.isEmpty()) 
    {
        QFile file(fileName);
        if (file.open(QFile::ReadOnly | QFile::Text))
            editor->setPlainText(file.readAll());
    }
}

// Définition à compléter
void MainWindow::setupFind()
{
   //TODO
   // instancier findDialog : la boite de dialogue "Rechercher ..."
   
   
   // connecter l'ensemble signal/slot
   
}

//! [1]
void MainWindow::setupEditor()
{
    QFont font;
    font.setFamily("Courier");
    font.setFixedPitch(true);
    font.setPointSize(10);

    editor = new QTextEdit;
    editor->setFont(font);    

    //editor->ensureCursorVisible();

    // chargement d'un fichier par défaut
    QFile file("traceroute.txt");
    if (file.open(QFile::ReadOnly | QFile::Text))
        editor->setPlainText(file.readAll());
}
//! [1]

void MainWindow::setupFileMenu()
{
    QMenu *fileMenu = new QMenu(tr("&Fichier"), this);
    menuBar()->addMenu(fileMenu);

    fileMenu->addAction(tr("&Nouveau"), this, SLOT(newFile()),
                        QKeySequence::New);

    fileMenu->addAction(tr("&Ouvrir..."), this, SLOT(openFile()),
                        QKeySequence::Open);
                        
    fileMenu->addAction(tr("&Quitter"), qApp, SLOT(quit()),
                        QKeySequence::Quit);
}

void MainWindow::setupHelpMenu()
{
    QMenu *helpMenu = new QMenu(tr("&Aide"), this);
    menuBar()->addMenu(helpMenu);

    helpMenu->addAction(QString::fromUtf8("À propos d'Éditeur"), this, SLOT(about()));
    helpMenu->addAction(QString::fromUtf8("À propos de Qt"), qApp, SLOT(aboutQt()));
}

// Définition à compléter
void MainWindow::setupEditMenu()
{
    //TODO
    // créer le menu "Édition"


    // créer une nouvelle action avec le texte "Rechercher" et un raccourci clavier "Ctrl+F". Le signal triggered() de l'action est connecté au slot membre rechercher. Cette fonction ajoute l'action nouvellement créée à la liste des actions du menu "Édition" de l'application
    
}

void MainWindow::rechercher()
{
   // à décommenter lorsque findDialog sera instancié :
   //findDialog->show();
   //findDialog->raise();
   //findDialog->activateWindow();
}

// Définition à compléter
void MainWindow::rechercherSuivant(const QString &str, Qt::CaseSensitivity cs)
{
    QTextDocument::FindFlag fcs = (cs == Qt::CaseSensitive) ? QTextDocument::FindCaseSensitively : (QTextDocument::FindFlag) 0;
    
    // TODO
}

// Définition à compléter
void MainWindow::rechercherPrecedent(const QString &str, Qt::CaseSensitivity cs)
{
    QTextDocument::FindFlag fcs = (cs == Qt::CaseSensitive) ? QTextDocument::FindCaseSensitively : (QTextDocument::FindFlag) 0;
    
    //TODO
}

void MainWindow::rechercherSuivant(const QRegExp &re, Qt::CaseSensitivity cs)
{
    QTextDocument::FindFlag fcs = (QTextDocument::FindFlag) 0;
    QTextCharFormat format;
    //format.setBackground(Qt::red);
    //format.setFontWeight(QFont::Bold);

    editor->document()->undo();
    cursor = editor->document()->find(re, cursor, fcs);
    if(cursor.position() >= 0)
    {
       //cursor.setCharFormat(format);
       editor->ensureCursorVisible();
       editor->setTextCursor(cursor);
    }
    else
    {
       //TODO
       // Recherche terminée !
    }
}

void MainWindow::rechercherPrecedent(const QRegExp &re, Qt::CaseSensitivity cs)
{
    QTextDocument::FindFlag fcs = (QTextDocument::FindFlag) 0;
    QTextCharFormat format;
    //format.setBackground(Qt::red);
    //format.setFontWeight(QFont::Bold);

    editor->document()->undo();
    cursor = editor->document()->find(re, cursor, QTextDocument::FindBackward | fcs);
    if(cursor.position() >= 0)
    {
       //cursor.setCharFormat ( format );
       editor->ensureCursorVisible();
       editor->setTextCursor(cursor);
    }
    else
    {
       //TODO
       // Recherche terminée !
    }
}
