#include "qtp.h"

// commandes QTP
static char cmds[][LG_CMD] = {
                              {0x1B, 0x59, 0x00, 0x00, 0x00, 4},    //pos_abs_cursor(r, c)
                              {0x1B, 0x4B, 0x00, 0x00, 0x00, 2},	//clear end of line
                              {0x1B, 0x6B, 0x00, 0x00, 0x00, 2},	//clear end of page
                              {0x1B, 0x50, 0x00, 0x00, 0x00, 2},	//cursor off
                              {0x1B, 0x4F, 0x00, 0x00, 0x00, 2},	//cursor on
                              {0x1B, 0x51, 0x00, 0x00, 0x00, 2},	//blink cursor on
                              {0x1B, 0x33, 0x00, 0x00, 0x00, 2},	//demande l'etat du QTP avant d'ecrire
                              {0x1B, 0x21, 0x4E, 0x00, 0x00, 4},	//write_of_life_byte(byte)
                              {0x1B, 0x21, 0x6E, 0x00, 0x00, 3},	//reading of life byte
                              {0x1B, 0x37, 0x00, 0x00, 0x00, 4},	//key_reconfiguration(numkey, code)
                              {0x1B, 0x35, 0x00, 0x00, 0x00, 2},	//keyclick on (beep)
                              {0x1B, 0x36, 0x00, 0x00, 0x00, 2},	//keyclick off (no beep)
                              {0x1B, 0x21, 0x35, 0x00, 0x00, 3},	//keyclick on save EEPROM
                              {0x1B, 0x21, 0x36, 0x00, 0x00, 3},	//keyclick off save EEPROM
                              {0x1B, 0x56, 0x00, 0x00, 0x00, 2},	//read version number
                              {0x1B, 0x6E, 0x00, 0x00, 0x00, 2},	//read storable message number
                              {0x1B, 0x21, 0x43, 0x00, 0x00, 4},	//message_storing(nummess, char0, char1, ..., char 19)
                              {0x1B, 0x21, 0x45, 0x00, 0x00, 4},	//message_reading(nummess)
                              {0x1B, 0x21, 0x44, 0x00, 0x00, 5},	//message_display(nummess, nbmess)
                              {0x1B, 0x21, 0x45, 0x00, 0x00, 5},	//message_scroll(nummess,nb_char)
                              {0x1B, 0x21, 0x49, 0x00, 0x00, 4},	//input_config(byte)
                              {0x1B, 0x49, 0x00, 0x00, 0x00, 2}	    //input_reading 				
                             };


QTP::QTP(QString port /*= "/dev/ttyUSB0"*/)
{
    //Ouverture du port
    //ouvrir et configurer le port série attaché au QTP

    _qtpid = -1;
    struct termios  termios_p;

	if (( _qtpid=open(port.toLocal8Bit().constData(), O_RDWR|O_NONBLOCK )) == -1 )
	{
			perror("open");
			return;
	}

	tcgetattr(_qtpid, &termios_p);

	termios_p.c_iflag = IGNBRK | IGNPAR;
	termios_p.c_oflag = 0;
	termios_p.c_cflag = B9600 | CS8;
    termios_p.c_cflag &= ~PARENB;

	termios_p.c_lflag = ~ECHO;
	termios_p.c_cc[VMIN] = 1;
	termios_p.c_cc[VTIME] = 0;

	tcsetattr(_qtpid, TCSANOW, &termios_p);
    fcntl(_qtpid,F_SETFL,fcntl(_qtpid,F_GETFL)&~O_NONBLOCK);
}

QTP::~QTP()
{
   //Fermeture du port
   close(_qtpid);
}

int QTP::afficher(char* message, int nbchar)
{
	int retour;
	
	retour = send(message, nbchar);
	return retour;
}

char QTP::lireTouche(char *touche, int nbchar, int mode)
{
	char key;
	int lus;

	for(lus=0;lus<nbchar;lus++)
	{
		recv(&key, 1); 
        if(mode == QTP_ECHO)
		{
			if(key != CR && key != ESC && key != CURSOR_UP && key != CURSOR_DOWN)
				send(&key, 1); 
		}
		*(touche+lus) = key;
	}

	#ifdef DEBUG_QTP
	if(nbchar == 1)
		fprintf(stderr, "QTP::lireTouche : %c (0x%02x) -> %d\n", key, key, key);
	else
	{
		int i;
		fprintf(stderr, "QTP::lireTouche (%d-%d)\n", nbchar, lus);
		for(i=0;i<lus;i++)
		{
			fprintf(stderr, "%c (0x%02x) -> %d\n", *(touche+i), *(touche+i), *(touche+i));
		}
	}
	#endif
	//conversion de key
	if (key == 48)
	{
		key = 0;
	}	
	if (key == 49)
	{
		key = 1;
	}
    if (key == 50)
	{
		key = 2;
	}
    if (key == 51)
	{
		key = 3;
	}
	if (key == 52)
	{
		key = 4;
	}
	if (key == 53)
	{
		key = 5;
	}
	if (key == 54)
	{
		key = 6;
	}
	if (key == 55)
	{
		key = 7;
	}
	if (key == 56)
	{
		key = 8;
	}
	if (key == 57)
	{
		key = 9;
	}

	return key;
}

void QTP::gotoxy(int ligne, int colonne)
{
	cmds[ABS][2] = (unsigned char)ligne+32;
	cmds[ABS][3] = (unsigned char)colonne+32;
	send(cmds[ABS], NB_CHAR(ABS));
}

void QTP::clearEndofline()
{
	send(cmds[CLEAR_ENDOFLINE], NB_CHAR(CLEAR_ENDOFLINE));
}

void QTP::clearEndofpage()
{
	send(cmds[CLEAR_PAGE], NB_CHAR(CLEAR_PAGE));  
}

void QTP::cursorOn()
{
	send(cmds[CURSOR_ON], NB_CHAR(CURSOR_ON));
}

void QTP::cursorOff()
{
	send(cmds[CURSOR_OFF], NB_CHAR(CURSOR_OFF));
}

void QTP::cursorBlink()
{
	send(cmds[BLINK], NB_CHAR(ABS));
}

int QTP::requestReady()
{
	char etat;
	
	send(cmds[REQUEST_READY], NB_CHAR(REQUEST_READY));
	recv(&etat, 1);
	
	return (int)etat;
}

int QTP::send(char *cmd, int nbchar)
{
	int retour = ERROR;

	if(_qtpid > 0)
	{
		retour = write(_qtpid, cmd, nbchar);
		
		usleep(0);
	
		#ifdef DEBUG_QTP
		int i;
		//debug : affichage
		fprintf(stderr, "-> QTP::_send (%d) : ", nbchar);
		for(i=0;i<nbchar;i++)
		{
			fprintf(stderr, "0x%02x ", *(cmd+i));
		}
		fprintf(stderr, "\n");
		#endif
	}
	else 
	{
		#ifdef DEBUG_QTP
		int i;
		//debug : affichage
		fprintf(stderr, "QTP::_send (%d) : ERREUR port !", nbchar);
		for(i=0;i<nbchar;i++)
		{
			fprintf(stderr, "0x%02x ", *(cmd+i));
		}
		fprintf(stderr, "\n");
		#endif
		retour = _qtpid;
	}

	return retour;
}

int QTP::recv(char *mess, int nbchar)
{
	int retour;
	char car;
	int lus = 0;
	int fin = FAUX;
	int MessagePresent = VRAI;

	if(_qtpid > 0 && mess != (char *)NULL)
	{
		if(nbchar > 0)
		{
			for(lus=0;lus<nbchar;lus++)
			{
				retour = read(_qtpid, &car, 1);
				if(retour > 0)
						*(mess+lus) = car;
				else	break;
			}
			if(nbchar == lus && nbchar > 1)
				*(mess+lus) = 0x00;//fin de chaine
			retour = lus;
			#ifdef DEBUG_QTP
			int i;
			fprintf(stderr, "QTP::_recv (%d-%d) : ", nbchar, lus);
			for(i=0;i<lus;i++)
				fprintf(stderr, "0x%02x ", *(mess+i)); 
			fprintf(stderr, "\n"); 
			#endif
		}
		else
		{
			for(lus=0;lus<(MAX_MESS_2048*MAX_LENGTH);lus++)
			{
				retour = read(_qtpid, &car, 1);
				if(car == CR)
					fin = VRAI;
				if(car == LF && fin == VRAI)
					break;
				if(car == (char)0xFF) 
					MessagePresent = FAUX;
				if(fin != VRAI)
					*(mess+lus) = car;
			}
			if(car == LF)	lus--;
			*(mess+lus) = 0x00;//fin de chaine
			retour = lus;
			#ifdef DEBUG_QTP
			int i;
			if(MessagePresent == VRAI) 
			{
				fprintf(stderr, "QTP::_recv (%d-%d) : ", nbchar, lus);
				for(i=0;i<lus;i++)
					fprintf(stderr, "0x%02x ", *(mess+i)); 
				fprintf(stderr, "\n"); 
			}
			else	fprintf(stderr, "QTP::_recv (%d-%d) : pas de message reçu !", nbchar, lus);
			#endif
			if(MessagePresent == FAUX) 
				retour = ERROR;
		}
	}
	else retour = _qtpid;
	
	return retour;
}

