#include <iostream>
#include "templateArray.h"
using namespace std;

int main() 
{
   Array<float> fa;
   
   fa[0] = 1.414;
   cout << fa[0] << endl;
}
