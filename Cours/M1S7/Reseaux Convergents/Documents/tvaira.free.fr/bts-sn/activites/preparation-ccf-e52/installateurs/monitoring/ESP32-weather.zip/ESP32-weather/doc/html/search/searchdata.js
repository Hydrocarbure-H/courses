var indexSectionsWithContent =
{
  0: "abcdeghilmnoprstv",
  1: "almrs",
  2: "almrs",
  3: "acdegilmrstv",
  4: "abcdehlmnprstv",
  5: "cl",
  6: "alnorv",
  7: "abdghlmnpt",
  8: "aelr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Énumérations",
  6: "Valeurs énumérées",
  7: "Macros",
  8: "Pages"
};

