// Camera IP Wanscam JW0008
// affiche en temps réel le flux vidéo de la caméra dans une fenêtre
// capture et sauvegarde des images JPG lorsqu’on appuie sur la barre Espace
// oriente la caméra avec les flèches du clavier

// tv 2015

#include "camera.h"

int main(int argc, char **argv)
{  
    Camera camera("192.168.52.14");
    
    camera.demarrer();
    
    return 0;
}
