/**
*
* @file lib/sonde/sonde.cpp
*
* @brief Définition de la classe Sonde
*
* @author Thierry Vaira
*
* @version 0.1
*
*/
#include <sonde.h>

/**
* @brief Constructeur de la classe Sonde
*
* @fn Sonde::Sonde
*
* @param brocheGPIODHT int numéro de broche 1Wire
*/
Sonde::Sonde(int brocheGPIODHT) : tsl(1234), dht(brocheGPIODHT, TYPE_DHT_DEFAUT), luminosite(0), humidite(-1.0), temperature(-273.0), ressentie(-273.), periode(PERIODE_ACQUISITION_DEFAUT), tempsPrecedent(0)
{
}

/**
* @brief Assure le démarrage du fonctionnement de la Sonde
*
* @fn Sonde::demarrer
*
*/
void Sonde::demarrer()
{
  initialiserCapteurs();
}

/**
* @brief Mutateur set pour le membre periode
*
* @fn Sonde::setPeriode
*
* @param periode unsigned long nouvelle période d'acquisition des mesures 
*/
void Sonde::setPeriode(unsigned long periode)
{
  this->periode = periode;
}

/**
* @brief Accesseur get pour le mebre periode
*
* @fn Sonde::getPeriode
*
* @return unsigned long la période d'acquisition des mesures
*/
unsigned long Sonde::getPeriode() const
{
  return periode;
}

/**
* @brief Retourne la luminosité pour son affichage
*
* @fn Sonde::getLuminosite
*
* @return String la luminosité sous la forme "LUMINOSITE : xxx lux"
*/
String Sonde::getLuminosite() const
{
  char strMessageDisplay[24];
  sprintf(strMessageDisplay, "LUMINOSITE : %u lux", luminosite);
  return String(strMessageDisplay);
}

/**
* @brief Retourne la température pour son affichage
*
* @fn Sonde::getTemperature
*
* @return String la température sous la forme "TEMPERATURE : xx. °C"
*/
String Sonde::getTemperature() const
{
  char strMessageDisplay[24];
  sprintf(strMessageDisplay, "TEMPERATURE : %.1f °C", temperature);
  return String(strMessageDisplay);
}

/**
* @brief Retourne la température ressentie pour son affichage
*
* @fn Sonde::getRessentie
*
* @return String la température ressentie sous la forme "RESSENTIE : xx.x °C"
*/
String Sonde::getRessentie() const
{
  char strMessageDisplay[24];
  sprintf(strMessageDisplay, "RESSENTIE : %.1f °C", ressentie);
  return String(strMessageDisplay);
}

/**
* @brief Retourne l'humidité pour son affichage
*
* @fn Sonde::getHumidite
*
* @return String l'humidité sous la forme "HUMIDITE : xx %"
*/
String Sonde::getHumidite() const
{
  char strMessageDisplay[24];
  sprintf(strMessageDisplay, "HUMIDITE : %u %%", (uint16_t)humidite);
  return String(strMessageDisplay);
}

/**
* @brief Retourne les données de la Sonde suivant le protocole
*
* @fn Sonde::getDonnees
*
* @return String les données formatées par le protocole
*/
String Sonde::getDonnees() const
{
  String donnees;
  //TEMPERATURE;C;RESSENTIE;C;HUMIDITE;%;LUMINOSITE;lux;\r\n
  donnees = "SONDE;" + String(temperature, 1) + ";" + "C" + ";" + String(ressentie, 1) + ";" + "C" + ";" + String(humidite, 0) + ";" + "%" + ";" + String(luminosite) + ";" + "lux" + ";" + "\r\n";
  return donnees;
}

/**
* @brief Réalise l'acquisition des mesures de la Sonde à l'échéance de la période
*
* @fn Sonde::acquerir
*
* @return bool true si l'acquisition a été réalisée sino false
*/
bool Sonde::acquerir()
{
  if(estEcheance(periode))
  {
    luminosite = tsl.getLuminosity(TSL2591_VISIBLE);
    //Serial.print(F("Luminosité : "));
    //Serial.println(luminosite, DEC);
    humidite = dht.readHumidity(false);
    temperature = dht.readTemperature(false);
    //Serial.print(F("Temperature : "));
    //Serial.println(temperature);
    //Serial.print(F("Humidité : "));
    //Serial.println(humidite);
    if (!isnan(temperature) && !isnan(humidite))
    {
      ressentie = dht.computeHeatIndex(temperature, humidite, false);
      //Serial.print(F("Temperature ressentie : "));
      //Serial.println(ressentie);
    }
    return true;
  }
  return false;
}

/**
* @brief Initialise les capteurs TSL 2591 et DHT22
*
* @fn Sonde::initialiserCapteurs
*
*/
void Sonde::initialiserCapteurs()
{
  //Serial.println("Initialiser capteurs");
  if (tsl.begin())
  {
    tsl.setGain(TSL2591_GAIN_MED);
    tsl.setTiming(TSL2591_INTEGRATIONTIME_300MS);
  }
  /*else
  {
    Serial.println(F("Aucun TSL2591 trouvé !"));
  }*/
  dht.begin();
}

/**
* @brief Retourne true si l'échéance de la période fixée a été atteinte
*
* @fn Sonde::estEcheance
*
* @param intervalle unsigned long
* @return bool true si l'intervalle entre deux périodes est arrivé à échéance
*/
bool Sonde::estEcheance(unsigned long intervalle)
{
    unsigned long temps = millis();
    if (temps - tempsPrecedent >= intervalle)
    {
        tempsPrecedent = temps;
        return true;
    }
    return false;
}
