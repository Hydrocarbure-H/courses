#include <QApplication>

#include "myslider.h"

int main(int argc, char* argv[])
{
    QApplication a(argc,argv);

    //MySlider s;
    MySlider s(10, 120); // canal, valeur

    s.show();

    return a.exec();
}

