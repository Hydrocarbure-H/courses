#include <QApplication>

#include "DialogueConsole.h"


int main(int argc, char *argv[]) 
{
   int ret = 0;
   DialogueConsole *dialogueConsole;
   QApplication app(argc, argv);


   dialogueConsole = new DialogueConsole();
   dialogueConsole->demarrer();


   ret = app.exec();  

   delete dialogueConsole;
   
   return ret;
}
