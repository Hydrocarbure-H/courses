#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <time.h>

#include <xbee.h>

int main(void) 
{
	int i;
	struct xbee *xbee;
	struct xbee_con *con;
	struct xbee_conAddress address;
	xbee_err ret;
    char trame[128];    
    time_t ts = time(NULL);
    struct tm *tmp;
    double temperatures[10] = { 25.1, 26.2, 22.3, 28.4, 25.5, 26.6, 24.7, 28.8, 24.9, 25.0 };
    int pressions[10] = { 1001, 1002, 1003, 1004, 1015, 1010, 1020, 1008, 1050, 1000 };
    double humidites[10] = { 30.1, 35.2, 33.3, 34.4, 37.5, 31.6, 32.7, 34.8, 35.9, 35.0 };
    int myid = 0x5001;

    srand(time(NULL));

	if ((ret = xbee_setup(&xbee, "xbee1", "/dev/ttyUSB0", 9600)) != XBEE_ENONE) 
    {
		printf("ret: %d (%s)\n", ret, xbee_errorToStr(ret));
		return ret;
	}

	memset(&address, 0, sizeof(address));
	address.addr16_enabled = 1;
	address.addr16[0] = 0x50;
    address.addr16[1] = 0x00;	
	if ((ret = xbee_conNew(xbee, &con, "16-bit Data", &address)) != XBEE_ENONE) 
    {
		xbee_log(xbee, -1, "xbee_conNew() returned: %d (%s)", ret, xbee_errorToStr(ret));
		return ret;
	}

	for (i = 0; i < 500; i++) 
    {
        memset(&trame, 0, sizeof(trame));
        
        ts = time(NULL);
        tmp = localtime(&ts);
        if (tmp == NULL) 
        {
            return 1;
        }

        if (strftime(trame, sizeof(trame), "%d/%m/%Y;%T", tmp) == 0) 
        {
            return 1;
        }
        printf("horodatage : %s\n", trame);
     
        sprintf(trame, "%s;%d;%.1f;%d;%.1f;", trame, myid, temperatures[rand() % 10], pressions[rand() % 10], humidites[rand() % 10]);
        
        printf("id: %02X%02X tx: [%s]\n", address.addr16[0], address.addr16[1], trame);
		xbee_conTx(con, NULL, "%s\r\n", trame);

		/* XBee Series 1 modules don't use meshing, so you can broadcast much faster than Series 2 */
		usleep(500000); // 500 ms
	}

	if ((ret = xbee_conEnd(con)) != XBEE_ENONE) 
    {
		xbee_log(xbee, -1, "xbee_conEnd() returned: %d", ret);
		return ret;
	}

	xbee_shutdown(xbee);

	return 0;
}

