#include "station.h"

StationMeteo::StationMeteo()
{
   this->lieu = "";
   interfacePeakNMEA2000.initialiser();

   environmentalParameters.temperature = 0.;
   environmentalParameters.pressionAtmospherique = 0.;
   environmentalParameters.hygrometrie = 0.;
   environmentalParameters.timestamp = -1;
   windData.vitesseVent = 0.;
   windData.directionVent = 0.;
   windData.timestamp = -1;

   setlocale(LC_ALL, "");   
}

StationMeteo::StationMeteo(std::string lieu)
{
   this->lieu = lieu;    
   interfacePeakNMEA2000.initialiser();

   environmentalParameters.temperature = 0.;
   environmentalParameters.pressionAtmospherique = 0.;
   environmentalParameters.hygrometrie = 0.;
   environmentalParameters.timestamp = -1;
   windData.vitesseVent = 0.;
   windData.directionVent = 0.;
   windData.timestamp = -1;

   setlocale(LC_ALL, "");   
}

StationMeteo::~StationMeteo()
{
   //interfacePeakNMEA2000.afficherInfos();
   interfacePeakNMEA2000.fermer();
}

std::string StationMeteo::getLieu() const
{
   return lieu;
}

void StationMeteo::setLieu(std::string lieu)
{
    this->lieu = lieu;
}

double StationMeteo::getTemperature()
{
   return environmentalParameters.temperature;
}

double StationMeteo::getPressionAtmospherique()
{
   return environmentalParameters.pressionAtmospherique;
}

double StationMeteo::getHygrometrie()
{
   return environmentalParameters.hygrometrie;
}

double StationMeteo::getVitesseVent()
{
   return windData.vitesseVent;
}

double StationMeteo::getDirectionVent()
{
   return windData.directionVent;
}

time_t StationMeteo::getTimestampEnvironmentalParameters()
{
   return environmentalParameters.timestamp;
}

time_t StationMeteo::getTimestampWindData()
{
   return windData.timestamp;
}

string StationMeteo::getHorodatage(time_t timestamp)
{
   string horodatage = "";
   time_t ts = timestamp;
   struct tm *tmp;
   char date[128];

   tmp = localtime(&ts);
   if (tmp == NULL) 
   {
      return horodatage;
   }
   /*if (strftime(date, sizeof(date), "%c", tmp) == 0) 
   {
      return horodatage;
   }*/
   if (strftime(date, sizeof(date), "%d/%m/%Y à %T", tmp) == 0) 
   {
      return horodatage;
   }
   horodatage = date;
   
   return horodatage;
}

string StationMeteo::getDate(time_t timestamp)
{
   string horodatage = "";
   time_t ts = timestamp;
   struct tm *tmp;
   char date[128];

   tmp = localtime(&ts);
   if (tmp == NULL) 
   {
      return horodatage;
   }
   if (strftime(date, sizeof(date), "%d/%m/%Y", tmp) == 0) 
   {
      return horodatage;
   }
   horodatage = date;
   
   return horodatage;
}

string StationMeteo::getHeure(time_t timestamp)
{
   string horodatage = "";
   time_t ts = timestamp;
   struct tm *tmp;
   char date[128];

   tmp = localtime(&ts);
   if (tmp == NULL) 
   {
      return horodatage;
   }   
   if (strftime(date, sizeof(date), "%T", tmp) == 0) 
   {
      return horodatage;
   }
   horodatage = date;
   
   return horodatage;
}

void StationMeteo::acquerir(int pgn)
{
   TPCANMsg message;

   message = recuperer(pgn);

   switch(pgn)
   {
      case ENVIRONMENTAL_PARAMETERS :
         environmentalParameters.temperature = extraireTemperature(message.DATA);
         environmentalParameters.timestamp = horodater();
         break;
      case WIND_DATA :
         windData.directionVent = extraireDirectionVent(message.DATA);
         windData.timestamp = horodater();
         break;
   }

}

TPCANMsg StationMeteo::recuperer(int pgn)
{
   TPCANMsg message;
   
   interfacePeakNMEA2000.obtenirMessage(pgn, message);
   
   return message;
}

time_t  StationMeteo::horodater()
{
   return time(NULL);
}

double StationMeteo::extraireTemperature(const BYTE DATA[8])
{
   int dataTemperature = 0;
   double temperature = 0.;

   // Attention : little endian ! sinon cf. doc
   dataTemperature = ( ((DATA[3] & 0x00FF) << 8) | (DATA[2] & 0x00FF)) & 0x0000FFFF;

   #ifdef DEBUG_STATION
   printf("message.DATA[2] = 0x%02x\n", DATA[2]);
   printf("message.DATA[3] = 0x%02x\n", DATA[3]);
   #endif

   // Temperature : cf. doc
   temperature = ( ( ((double)dataTemperature*0.01) ) - 273.15 );

   #ifdef DEBUG_STATION
   printf("dataTemperature = %d\n", dataTemperature);
   printf("temperature = %.2f °C\n", temperature);
   #endif

   return temperature;
}

double StationMeteo::extrairePressionAtmospherique(const BYTE DATA[8])
{
   int dataPressionAtmospherique = 0;
   double pressionAtmospherique = 0.;



   return pressionAtmospherique;
}

double StationMeteo::extraireHygrometrie(const BYTE DATA[8])
{
   int dataHygrometrie = 0;
   double hygrometrie = 0.;



   return hygrometrie;
}

double StationMeteo::extraireVitesseVent(const BYTE DATA[8])
{
   int dataVitesseVent = 0;
   double vitesseVent = 0.;


   return vitesseVent;
}

double StationMeteo::extraireDirectionVent(const BYTE DATA[8])
{
   int dataDirectionVent = 0;
   double directionVent = 0.;

   // Attention : little endian ! sinon cf. doc
   dataDirectionVent = ( ((DATA[4] & 0x00FF) << 8) | (DATA[3] & 0x00FF)) & 0x0000FFFF; //rad

   #ifdef DEBUG_STATION
   printf("message.DATA[3] = 0x%02x\n", DATA[3]);
   printf("message.DATA[4] = 0x%02x\n", DATA[4]);
   #endif

   if(dataDirectionVent == 0xFFFF)
       return 0.;

   // Direction du vent : cf. doc
   directionVent = ( ((double)dataDirectionVent * 0.0001)*360/(2*M_PI) );

   #ifdef DEBUG_STATION
   printf("dataDirectionVent = %d\n", dataDirectionVent);
   printf("directionVent = %.2f °C\n", directionVent);
   #endif

   return directionVent;
}
