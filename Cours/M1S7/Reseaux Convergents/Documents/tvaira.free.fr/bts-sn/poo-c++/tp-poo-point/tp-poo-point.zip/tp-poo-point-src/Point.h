#ifndef POINT_H
#define POINT_H

class Point 
{
   private:
      double x;
      double y;
      
   public:
      // Constructeurs
      
      
      // Destructeur  
      

      // Accesseurs et mutateurs
      
      
      // Services
      
};

#endif //POINT_H
