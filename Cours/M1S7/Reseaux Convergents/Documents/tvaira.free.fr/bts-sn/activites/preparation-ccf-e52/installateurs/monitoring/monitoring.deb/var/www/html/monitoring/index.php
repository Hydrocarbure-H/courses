<?php
require_once ('./include/monitoring.inc.php');
//require_once ('./include/salle.class.php');
UpdateLog("Chargement", $config['logfile']);
?>
<!DOCTYPE html>
<html lang="fr-FR">
 <head>
  <meta charset="<?= $config['charset'] ?>">  
  <title><?= $config['description'] ?></title>
  <link href="jquery-ui/jquery-ui.css" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link href="include/app.min.css" rel="stylesheet">
  <link href="include/industrial.css" rel="stylesheet">
  <link href="include/monitoring.css" rel="stylesheet">
 </head>
 <body>

    <div class="ui-widget">        
        <h1><?= $config['description'] ?></h1>
        <div>
            Salle : <input id="salle" type="text" title="Saisir un nom de salle">
        </div>
        <div id="busy"></div>
        <div id="description"><p>&nbsp;</p></div>        
    </div>    
    
    <div id="datas" style="background-color: #212629; display:block;">
        <div style="float: left; margin: 5px; padding: 5px;">
            <div id="affichage" class="industrial readout size one" style="margin-left: auto; margin-right: auto;">
                <div class="meter white" data-digits="5" style="text-align: center;"></div>
            </div>
            <div id="horodatage" style="text-align: center; color: white;">&nbsp;</div>
            <div class="industrial led size one" style="margin-left: auto; margin-right: auto; margin-top: 25px;">
                <div id="led" class="meter green"></div>                
            </div>
            <div>&nbsp;</div>
            <div style="text-align: center;"><div id="two-steps-switch" ></div></div>            
        </div>
        <div style="margin: 0px; padding: 0px;">    
            <div style="text-align: center; margin-left: auto; margin-right: auto;">
                <canvas id="temperature" style="margin: 0px;"></canvas>
                <canvas id="ressentie" style="margin: 0px;"></canvas>
                <canvas id="humidite" style="margin: 0px;"></canvas>
                <canvas id="luminosite" style="margin: 0px;"></canvas>            
                <div id="resultat"></div>
            </div>
        </div>        
    </div>
    <div>&nbsp;</div>
    <div><a href="maintenance.php">Maintenance</a></div>
    <div>&nbsp;</div>
    <p id="footer"><span><?= $config['signature'] ?></span></p>    
    <script src="jquery-ui/external/jquery/jquery.js"></script>
    <script src="jquery-ui/jquery-ui.min.js"></script>
    <script src="js/app.min.js"></script>
    <script src="js/gauge.min.js"></script>
    <script src="js/industrial.js"></script>
    <script src="js/jquery.theswitch.min.js"></script>
    <script>
        $(document).ready(function(){
            var saisie = false;
            
            $('#salle').focus();
            
            $('#salle').autocomplete({
                source : 'salles.php',
                minLength : 1,
                select : function(event, ui) {
                    saisie = true;
                    $('#description').html( ui.item.desc);
                    //$("#busy").busyLoad("show", {fontawesome: "fa fa-spinner fa-spin fa-3x fa-fw" });
                    dialoguer(ui.item.value);
                }
            });
            
            $("#salle").focus(function () {           
                if($('#salle').val().length == 0)
                {
                    saisie = false;
                }
            });
            
            $("#salle").change(function () {
                if($('#salle').val().length == 0)
                {
                    saisie = false;
                }
            });                
            
            $(".industrial").industrial({});
            $("#affichage").industrial("");
            
            $("#datas").tabs();
            $("#datas").hide();
                    
            $("#two-steps-switch").setTheSwitch({
                    steps: 3,
                    action: 'noset',
                    bgOn:"#4da154",bgNoSet:"#f1f1f1",bgOff:"#d82c2c",
                    //bgOff: '#f1f1f1',
                    onLabel: '', // "\u25cf"
                    offLabel: '', // "\u25cf"
                    width: 80, // 60
                    height: 15, // 14
                    hsize: 13, // 11
                    disabled:!1,
                    onSet: function(e) {
                    },                    
                    onClickOn: function(e) {
                        var element = $(e).attr('id');
                        console.log("led on "  + element);
                        //$('#led').attr('class','meter green');
                        $.ajax({
                            type: "POST",
                            url: "monitoring.php",
                            //data: $("#idForm").serialize(),
                            data: "nom=" + $('#salle').val() + "&send=VERTE",
                            dataType : 'json',
                            success: function(data)
                            {
                                console.log(data);
                                dialoguer();
                            },
                            error: function() {
                                $('#description').html("<p>Impossible de communiquer avec la salle " + $('#salle').val() + "</p>");
                                $("#datas").hide();
                            }
                        });
                    },
                    onClickNoSet: function(e) {
                        $.ajax({
                            type: "POST",
                            url: "monitoring.php",
                            //data: $("#idForm").serialize(),
                            data: "nom=" + $('#salle').val() + "&send=0",
                            dataType : 'json',
                            success: function(data)
                            {
                                console.log(data);
                                dialoguer();
                            },
                            error: function() {
                                $('#description').html("<p>Impossible de communiquer avec la salle " + $('#salle').val() + "</p>");
                                $("#datas").hide();
                            }
                        });
                    },
                    onClickOff: function(e) {
                        var element = $(e).attr('id');
                        console.log("led off "  + element);                    
                        //$('#led').attr('class','meter red');
                        $.ajax({
                            type: "POST",
                            url: "monitoring.php",
                            //data: $("#idForm").serialize(),
                            data: "nom=" + $('#salle').val() + "&send=ROUGE",
                            dataType : 'json',
                            success: function(data)
                            {
                                console.log(data);
                                dialoguer();
                            },
                            error: function() {
                                $('#description').html("<p>Impossible de communiquer avec la salle " + $('#salle').val() + "</p>");
                                $("#datas").hide();
                            }
                        });
                    }
                });
                    
            /*$.ajaxSetup({
                beforeSend:function(){
                    $("#busy").busyLoad("show", {fontawesome: "fa fa-spinner fa-spin fa-3x fa-fw" });
                },
                complete:function(){
                    $("#busy").busyLoad("hide", {fontawesome: "fa fa-spinner fa-spin fa-3x fa-fw" });
                }
            });*/
            
            $( document ).ajaxStart(function() {
                $("#busy").busyLoad("show", {fontawesome: "fa fa-spinner fa-spin fa-3x fa-fw" });
            }).ajaxStop(function() {
                $("#busy").busyLoad("hide", {fontawesome: "fa fa-spinner fa-spin fa-3x fa-fw" });
            });
            
            function dialoguer(salle) {
                var nomSalle = "";

                if(typeof salle === 'undefined')
                {
                    nomSalle = $('#salle').val();
                }
                else
                {
                    nomSalle = salle;
                }

                if((saisie) && (nomSalle.length > 0))
                {
                    $.ajax({
                        type: "POST",
                        url: "monitoring.php",
                        //data: $("#idForm").serialize(),
                        data: "nom=" + nomSalle,
                        //dataType : 'html',
                        dataType : 'json',
                        success: function(data)
                        {                            
                            //$('#resultat').html("Température : " + data["temperature"]);
                            console.log(data);
                            if(!data["erreur"])
                            {
								var date = new Date();
								var hours = "0" + date.getHours();
								var minutes = "0" + date.getMinutes();
								var seconds = "0" + date.getSeconds();
								var formattedTime = hours.substr(-2) + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
                                temperature.value = data["temperature"];
                                ressentie.value = data["ressentie"];
                                humidite.value = data["humidite"];
                                luminosite.value = data["luminosite"];
                                if(data["led"] == 1)
                                {
                                    $('#led').attr('class','meter red');
                                    $(".industrial.led").industrial(true);
                                    /*$("#two-steps-switch").setTheSwitch({
                                        action: 'off'
                                    });*/
                                }
                                else if(data["led"] == 2)
                                {
                                    $('#led').attr('class','meter green');
                                    $(".industrial.led").industrial(true);
                                    /*$("#two-steps-switch").setTheSwitch({
                                        action: 'on'
                                    });*/
                                }
                                else
                                {
                                    $('#led').attr('class','meter');
                                    $(".industrial.led").industrial(false);
                                    /*$("#two-steps-switch").setTheSwitch({
                                        action: 'noset'
                                    });*/
                                }
                                $('#description').html("<p>&nbsp;</p>");
                                $('#horodatage').html("<p>" + formattedTime + "</p>");
                                $("#datas").show();
                                $("#affichage").industrial($('#salle').val());
                            }
                            else
                            {
                                $('#description').html("<p>" + data["message"] + "</p>");
                                $("#datas").hide();
                                $("#affichage").industrial($('#salle').val());
                            }
                        },
                        error: function() {
                            //alert('Erreur ajax');
                            $('#description').html("<p>Impossible de communiquer avec la salle " + nomSalle + "</p>");
                            $("#datas").hide();
                        }
                    });
                }
                else
                {
                    $('#description').html("<p>&nbsp;</p>");
                    $("#datas").hide();
                }
            }
            
            setInterval(dialoguer, <?= $GLOBALS['config']['refresh'] ?> );
            
            var temperature = new LinearGauge({
                        renderTo: 'temperature',
                        width: 150,
                        height: 450,
                        title: "Température",
                        units: "°C",
                        minValue: -20,
                        maxValue: 50,
                        startAngle: 90,
                        ticksAngle: 180,
                        valueBox: true,
                        majorTicks: [
                            -20,
                            -10,
                            0,
                            10,
                            20,
                            30,
                            40,
                            50
                        ],
                        minorTicks: 5,
                        strokeTicks: true,
                        highlights: [
                            {
                                "from": -20,
                                "to": 0,
                                "color": "rgba(0,0, 255, .3)"
                            },
                            {
                                "from": 0,
                                "to": 30,
                                "color": "rgba(0, 255, 0, .3)"
                            },
                            {
                                "from": 30,
                                "to": 50,
                                "color": "rgba(255, 0, 0, .3)"
                            }
                        ],
                        colorMajorTicks: "#ddd",
                        colorMinorTicks: "#ddd",
                        colorTitle: "#eee",
                        colorUnits: "#eee",
                        colorNumbers: "#eee",
                        colorPlate: "#212629",
                        //colorPlateEnd: "#395467",
                        borderShadowWidth: 0,
                        borders: false,
                        needleType: "arrow",
                        needleWidth: 2,
                        needleCircleSize: 7,
                        needleCircleOuter: true,
                        needleCircleInner: false,
                        animationDuration: 500,
                        animationRule: "linear",
                        barWidth: 10,
                        valueInt: 2,
                        valueDec: 1,
                        //valueTextShadow: false,
                        value: 0
                }).draw();
            
            var ressentie = new LinearGauge({
                        renderTo: 'ressentie',
                        width: 150,
                        height: 450,
                        title: "Ressentie",
                        units: "°C",
                        minValue: -20,
                        maxValue: 50,
                        startAngle: 90,
                        ticksAngle: 180,
                        valueBox: true,
                        majorTicks: [
                            -20,
                            -10,
                            0,
                            10,
                            20,
                            30,
                            40,
                            50
                        ],
                        minorTicks: 5,
                        strokeTicks: true,
                        highlights: [
                            {
                                "from": -20,
                                "to": 0,
                                "color": "rgba(0,0, 255, .3)"
                            },
                            {
                                "from": 0,
                                "to": 30,
                                "color": "rgba(0, 255, 0, .3)"
                            },
                            {
                                "from": 30,
                                "to": 50,
                                "color": "rgba(255, 0, 0, .3)"
                            }
                        ],
                        colorMajorTicks: "#ddd",
                        colorMinorTicks: "#ddd",
                        colorTitle: "#eee",
                        colorUnits: "#eee",
                        colorNumbers: "#eee",
                        colorPlate: "#212629",
                        //colorPlateEnd: "#395467",
                        borderShadowWidth: 0,
                        borders: false,
                        needleType: "arrow",
                        needleWidth: 2,
                        needleCircleSize: 7,
                        needleCircleOuter: true,
                        needleCircleInner: false,
                        animationDuration: 500,
                        animationRule: "linear",
                        barWidth: 10,
                        valueInt: 2,
                        valueDec: 1,
                        value: 0
                }).draw();
            
            var humidite = new RadialGauge({
                        renderTo: 'humidite',
                        width: 300,
                        height: 300,
                        title: "Humidité",
                        units: "%",
                        minValue: 0,
                        maxValue: 100,
                        majorTicks: [
                            "0",
                            "10",
                            "20",
                            "30",
                            "40",
                            "50",
                            "60",
                            "70",
                            "80",
                            "90",
                            "100"
                        ],
                        minorTicks: 10,
                        strokeTicks: true,
                        highlights: [
                            {
                                "from": 0,
                                "to": 20,
                                "color": "rgba(0,0, 255, .3)"
                            },
                            {
                                "from": 20,
                                "to": 80,
                                "color": "rgba(0, 255, 0, .3)"
                            },
                            {
                                "from": 80,
                                "to": 100,
                                "color": "rgba(255, 0, 0, .3)"
                            }
                        ],
                        colorMajorTicks: "#ddd",
                        colorMinorTicks: "#ddd",
                        colorTitle: "#eee",
                        colorUnits: "#eee",
                        colorNumbers: "#eee",
                        colorPlate: "#212629",
                        //colorPlateEnd: "#395467",
                        borderShadowWidth: 0,
                        borders: false,
                        needleType: "arrow",
                        needleWidth: 2,
                        needleCircleSize: 7,
                        needleCircleOuter: true,
                        needleCircleInner: false,
                        animationDuration: 500,
                        animationRule: "linear",
                        valueDec: 0,
                        value: 50
                    }).draw();
            var luminosite = new LinearGauge({
                        renderTo: 'luminosite',
                        width: 150,
                        height: 450,
                        title: "Luminosité (lux)",
                        units: "lux",
                        minValue: 0,
                        maxValue: 1000,
                        majorTicks: [
                            "0",                            
                            "100",                            
                            "200",                            
                            "300",
                            "400",
                            "500",
                            "600",
                            "700",
                            "800",
                            "900",
                            "1000"
                        ],
                        minorTicks: 5,
                        strokeTicks: true,
                        highlights: [
                            {
                                "from": 0,
                                "to": 150,
                                "color": "rgba(255, 0, 0, .3)"                                    
                            },
                            {
                                "from": 150,
                                "to": 300,
                                "color": "rgba(0,0, 255, .3)"                                    
                            },
                            {
                                "from": 300,
                                "to": 1000,
                                "color": "rgba(0, 255, 0, .3)"
                            }
                        ],
                        colorMajorTicks: "#ddd",
                        colorMinorTicks: "#ddd",
                        colorTitle: "#eee",
                        colorUnits: "#eee",
                        colorNumbers: "#eee",
                        colorPlate: "#212629",
                        //colorPlateEnd: "#395467",
                        borderShadowWidth: 0,
                        borders: false,
                        barBeginCircle: false,                        
                        tickSide: "left",
                        numberSide: "left",
                        needleSide: "left",
                        needleType: "arrow",
                        needleWidth: 5,
                        colorNeedle: "#222",
                        colorNeedleEnd: "#222",
                        animationDuration: 250,
                        animationRule: "linear",
                        animationTarget: "plate",
                        barWidth: 15,
                        ticksWidth: 20,
                        ticksWidthMinor: 15,
                        valueDec: 0,
                        value: 250
                    }).draw();
        });
    </script>
 </body>
</html>
