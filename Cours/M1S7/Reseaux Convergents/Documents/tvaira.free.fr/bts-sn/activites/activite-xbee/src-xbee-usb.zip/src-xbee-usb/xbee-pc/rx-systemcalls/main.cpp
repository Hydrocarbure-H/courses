#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <iostream>
#include <string.h>

int main (int argc, char** argv)
{
    setbuf(stdout, NULL);
    
    int xbeefd = open("/dev/ttyUSB0", O_RDWR | O_NOCTTY | O_NDELAY);
    if (xbeefd == -1)
    {
        std::cerr << "Erreur ouverture port !" << std::endl;
        return -1;
    }

    unsigned char buffer[128];

    while(1)
    {
        usleep(100000); /* 100ms */
        
        // remet le buffer à 0
        memset(buffer, 0, 128);
        
        int n = read(xbeefd, buffer, 128);
    
        if( n > 0)
        {
            printf("Octets lus : %d\n", n);
            fflush(stdout);

            printf("Trame reçue : ");
            for (int i = 0; i < n; i++)
                printf("0x%02X ", buffer[i]);
            printf("\n");
        }
    }
    
    close(xbeefd);
    
    return 0;
}
