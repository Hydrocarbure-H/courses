#include <QCoreApplication>
#include "ServeurBLE.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    ServeurBLE *serveurBLE = new ServeurBLE();

    serveurBLE->demarrer();

    return a.exec();
}
