#ifndef BLE_UART_H
#define BLE_UART_H

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEServer.h>
#include <BLE2902.h>

#define DEBUG_BLE_UART
//DEBUG_BLE_UART_Characteristic

/**
 * @def PERIPHERIQUE_BLUETOOTH
 * @brief Définit le nom du périphérique Bluetooth (et son id)
 */
#define PERIPHERIQUE_BLUETOOTH_BLE "esp32-uart"

#define SERVICE_UART_UUID                                                      \
    "6E400001-B5A3-F393-E0A9-E50E24DCCA9E" // UART service UUID
#define CHARACTERISTIC_UUID_RX "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_TX "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"

#define BLE_UART_TAILLE_BUFFER_RECEPTION 64
#define BLE_UART_DELAI_ADVERTISING       500
#define BLE_UART_DELIMITEUR_FIN          '\n'

class CharacteristicUART;

class ServeurBLEUART : public BLEServerCallbacks
{
  private:
    String             nomPeripherique;
    BLEServer*         serveurBLE;
    BLECharacteristic* pTxCharacteristic;
    BLECharacteristic* pRxCharacteristic;
    BLEService*        pServiceUART;
    bool               connecte;
    uint8_t            buffer[BLE_UART_TAILLE_BUFFER_RECEPTION];
    uint8_t            tete;
    uint8_t            queue;
    uint32_t           delaiAdvertising;

    int  lireBuffer();
    void ecrireBuffer(char c);

  public:
    ServeurBLEUART(String nomPeripherique = PERIPHERIQUE_BLUETOOTH_BLE);
    void   initialiser(String nomPeripherique = PERIPHERIQUE_BLUETOOTH_BLE);
    void   demarrer();
    void   diffuser(uint32_t ms=BLE_UART_DELAI_ADVERTISING);
    bool   estConnecte() const;
    void   setDelaiAdvertising(uint32_t ms);
    void   onConnect(BLEServer* pServer);
    void   onDisconnect(BLEServer* pServer);
    void   envoyer(String trame);
    bool   recevoir(String& trame, char delimiteur = BLE_UART_DELIMITEUR_FIN);
    size_t estDisponible() const;
    String readStringUntil(char delimiteur = BLE_UART_DELIMITEUR_FIN);
    static bool estEcheance(unsigned long intervalle);
    friend CharacteristicUART;
};

class CharacteristicUART : public BLECharacteristicCallbacks
{
  private:
    ServeurBLEUART* serveurBLEUART;

  public:
    CharacteristicUART(ServeurBLEUART* serveurBLEUART);
    void onWrite(BLECharacteristic* pCharacteristique);
};

#endif