#include "mafenetre.h"

MaFenetre::MaFenetre(QWidget *parent) :
    QWidget(parent)
{
    // La GUI
    labelListe = new QLabel("Interfaces :", this);
    listeInterfaces = new QComboBox(this);
    labelPeripherique = new QLabel("Périphérique :", this);
    editPeripherique = new QLineEdit(this);
    boutonAjouter = new QPushButton("Ajouter", this);
    boutonSupprimer = new QPushButton("Supprimer", this);

    QVBoxLayout *layoutPrincipal = new QVBoxLayout;
    QHBoxLayout *layoutListe = new QHBoxLayout;
    QHBoxLayout *layoutPeripherique = new QHBoxLayout;

    layoutListe->addStretch();
    layoutListe->addWidget(labelListe);
    layoutListe->addWidget(listeInterfaces);
    layoutListe->addWidget(boutonSupprimer);
    layoutPeripherique->addStretch();
    layoutPeripherique->addWidget(labelPeripherique);
    layoutPeripherique->addWidget(editPeripherique);
    layoutPeripherique->addWidget(boutonAjouter);

    layoutPrincipal->addLayout(layoutListe);
    layoutPrincipal->addLayout(layoutPeripherique);
    layoutPrincipal->addStretch();

    setLayout(layoutPrincipal);

    // Initialisation des données
    connect(boutonAjouter, SIGNAL(clicked()), this, SLOT(ajouter()));
    connect(boutonSupprimer, SIGNAL(clicked()), this, SLOT(supprimer()));
    if(lireXML())
    {
        afficherListe();
    }
}

MaFenetre::~MaFenetre()
{

}

bool MaFenetre::lireXML()
{
    // Le fichier XML
    QFile fichierXML(INTERFACES_XML);

    if(!(fichierXML.open(QIODevice::ReadOnly)))
    {
        QMessageBox::critical(0,"Erreur","Le fichier XML n'a pas pu être ouvert !");
        return false;
    }
    else
    {
        QDomDocument documentXML;

        documentXML.setContent(&fichierXML, false);
        QDomElement racine = documentXML.documentElement(); // <interfaces>
        if(racine.isNull())
        {
            qDebug() << "<MaFenetre::lireXML()> erreur racine !";
            return false;
        }

        QDomNode noeudInterface = racine.firstChild();
        if(noeudInterface.isNull())
        {
            qDebug() << "<MaFenetre::lireXML()> erreur racine vide !";
            return false;
        }

        while(!noeudInterface.isNull())
        {
            Interface interface;
            QDomElement elementInterface = noeudInterface.toElement(); // <interface>
            if(elementInterface.isNull())
            {
                qDebug() << "<MaFenetre::lireXML()> erreur element interface !";
                break;
            }

            QDomNode noeudPeripherique = elementInterface.firstChild();
            if(!noeudPeripherique.isNull())
            {
                QDomElement elementPeripherique = noeudPeripherique.toElement(); // <peripherique>

                interface.id = elementInterface.attribute("id").toInt(); // l'id
                interface.peripherique = elementPeripherique.text(); // le device
                qDebug() << QString::fromUtf8("<MaFenetre::lireXML()> %1 -> %2").arg(QString::number(interface.id)).arg(interface.peripherique);
                interfaces.push_back(interface);
            }
            else qDebug() << "<MaFenetre::lireXML()> erreur noeud peripherique !";

            noeudInterface = noeudInterface.nextSibling();
        }

        fichierXML.close();
    }

    return true;
}

bool MaFenetre::ecrireXML()
{
    // TODO    

    return false;
}

void MaFenetre::ajouter()
{
    if(!editPeripherique->text().isEmpty())
    {
        // TODO
        
        ecrireXML();
    }
}

void MaFenetre::supprimer()
{
    if(listeInterfaces->currentIndex() >= 0)
    {
        // TODO
        
        ecrireXML();
    }
}

void MaFenetre::afficherListe()
{
    listeInterfaces->clear();
    for(int i = 0; i < interfaces.size(); i++)
    {
        listeInterfaces->insertItem(interfaces[i].id, interfaces[i].peripherique);
    }
}
