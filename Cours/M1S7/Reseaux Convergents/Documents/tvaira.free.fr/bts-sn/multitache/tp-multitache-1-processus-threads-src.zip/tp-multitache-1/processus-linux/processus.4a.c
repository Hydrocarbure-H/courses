#include <stdio.h>

int main() 
{
   if (fork())
   {
          printf("Je suis le père\n");
          printf("Fin du père\n");
   }
   else
   {
          printf("Je suis le fils\n");
          printf("Fin du fils\n");
   }

   return 0;
}

