#include <iostream>
#include <sstream> // stringstream !
#include <string>
#include <cmath>

using namespace std;

#include "geolocalisation.h"

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*  Latitude/longitude spherical geodesy formulae & scripts (c) Chris Veness 2002-2012            */
/*   - www.movable-type.co.uk/scripts/latlong.html                                                */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */

int main()
{
   Geolocalisation *p1 = new Geolocalisation(44.086722, 4.968567); // Sarrians 44.086722,4.968567
   Geolocalisation *p2 = new Geolocalisation(43.948308, 4.816754); // Avignon 43.948308,4.816754
   Geolocalisation *p3, *p4;
   
   double dist = p1->distance(*p2);          // in km
   double brng1 = p1->orientation(*p2);           // in degres clockwise from north
   double brng2 = p1->orientationFinale(*p2);           // in degres clockwise from north
   p3 = p1->milieu(*p2);
   p4 = p1->destination(brng1, dist);

   cout << "p1 : 44.086722, 4.968567 (Sarrians)" << endl;
   cout << "p2 : 43.948308, 4.816754 (Avignon)" << endl;
   
   cout << "dist = " << dist << " km" << endl; // Affiche : dist = 19.6022 km
   cout << "brng1 = " << brng1 << " degres" << endl; // Affiche : brng = 218.317 degres
   cout << "brng2 = " << brng2 << " degres" << endl; // Affiche : brng = 218.317 degres
   
   cout << "p3 : " << p3->getLatitude() << ", " << p3->getLongitude() << " (milieu)" << endl; // Affiche : p3 : 44.0175, 4.89257 (milieu)
   cout << "p4 : " << p4->getLatitude() << ", " << p4->getLongitude() << " (destination)" << endl; // Affiche : p4 : 43.9483, 4.81675 (destination)

   dist = p1->rhumbDistanceTo(*p2);          // in km
   cout << "dist = " << dist << " km" << endl; // Affiche : dist = 19.6022 km

   return 0;
}
