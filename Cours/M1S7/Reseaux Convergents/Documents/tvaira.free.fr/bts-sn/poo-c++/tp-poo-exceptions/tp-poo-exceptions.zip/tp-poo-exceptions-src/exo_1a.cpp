#include <iostream>
#include <stdexcept> // pour std::range_error

using namespace std;

void Exo_1()
{
    int numerateur, denominateur;
    
    // initialiser une variable entière non nulle numerateur, 

    
    // et lire au clavier le dénominateur denominateur

    
    // Tester le dénominateur :
    // SI dénominateur non nul
    // ALORS on affiche le résultat de la division entière de numerateur par denominateur (opérateur /)
    // SINON on lève une exception entière (denominateur par exemple)
    // FIN SI
    
}

int main()
{
   // Sécuriser l'ensemble du corps de la fonction Exo_1() en l'incluant dans une instruction try-catch. 
   
       Exo_1();      
   
   
   cout << "Fin du programme" << endl;

   return 0;
}
