#include <stdio.h>

int main() 
{
   printf("1\n");
   fork();
   printf("2\n");
   fork();
   printf("3\n");

   return 0;
}

