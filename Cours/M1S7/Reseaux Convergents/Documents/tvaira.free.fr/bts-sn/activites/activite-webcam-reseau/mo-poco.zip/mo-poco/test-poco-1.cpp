#include <Poco/Net/HTTPClientSession.h>
#include <Poco/Net/HTTPRequest.h>
#include <Poco/Net/HTTPResponse.h>
#include <Poco/StreamCopier.h>
#include <Poco/Path.h>
#include <Poco/URI.h>
#include <Poco/Exception.h>
#include <iostream>
#include <string>

using namespace Poco::Net;
using namespace Poco;
using namespace std;

// sudo apt-get install libpoco-dev
// g++ -o test-poco-1 test-poco-1.cpp -lPocoNet -lPocoFoundation

int main(int argc, char **argv)
{  
    // Commande en montée la caméra IP Wanscam 
    char url[] = "http://192.168.52.216:99/decoder_control.cgi?command=0&onestep=1&user=admin&pwd="; 
    
    // prepare session
    URI uri(url);
    HTTPClientSession session(uri.getHost(), uri.getPort());

    // prepare path
    string path(uri.getPathAndQuery());
    if (path.empty()) path = "/";

    // send request
    HTTPRequest req(HTTPRequest::HTTP_GET, path, HTTPMessage::HTTP_1_1);
    session.sendRequest(req);

    // get response
    HTTPResponse res;
    cout << res.getStatus() << " " << res.getReason() << endl;

    // print response
    istream &is = session.receiveResponse(res);
    StreamCopier::copyStream(is, cout);

    return 0;
}
