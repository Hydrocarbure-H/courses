#include <windows.h>
#include <stdio.h>

int main( VOID )
{  
    STARTUPINFO si;
    PROCESS_INFORMATION pi;
	DWORD status ; // address to receive termination status
    ZeroMemory( &si, sizeof(si) );
    si.cb = sizeof(si);
    ZeroMemory( &pi, sizeof(pi) );
	
	if( !CreateProcess(".\\Child.exe",NULL,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi)) 
    {   printf( "CreateProcess failed (%d).\n", GetLastError() );
        ExitProcess(1);
    }
	WaitForSingleObject( pi.hProcess, INFINITE );
    if(GetExitCodeProcess( pi.hProcess, &status))
	   printf("I am the father. My child [%d,%d] has terminated with (%d). \n", pi.dwProcessId, pi.dwThreadId, status );
	else printf( "GetExitCodeProcess failed (%d).\n", GetLastError() );
	CloseHandle( pi.hProcess );
    CloseHandle( pi.hThread );
	printf( "I am the father. Going to terminate.\n");
	ExitProcess(0);
}

