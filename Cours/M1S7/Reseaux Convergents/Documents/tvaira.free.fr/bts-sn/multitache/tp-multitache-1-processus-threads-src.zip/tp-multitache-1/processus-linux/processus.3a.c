#include <stdio.h>
#include <stdlib.h>

int main()
{
   printf("Résultat de la commande ps -l :\n");
   system("ps -l");
   printf("Fin\n");
   
   return 0;
}

