#ifndef DialogueConsole_H
#define DialogueConsole_H

#include <QObject>
#include <QUdpSocket>

#include <QtGui>
#include <QMessageBox>

#define DEBUG_DialogueConsole

#define PORT_ENTTEC      3330 //Enttec Port

#define LG_MESSAGE_WOOD    28 // Message Console -> PC (voir wing_api_spec.pdf)
#define LG_KEY_STATES       6
#define INDEX_FIRMWARE      4
#define INDEX_VERSION       5

/********************************/

class DialogueConsole : public QObject
{
   Q_OBJECT

   public:
      DialogueConsole(QObject *pParent = 0);
      ~DialogueConsole();

      void demarrer();

   public slots:
      void ReceptionnerDatagrammes();

   signals : 
      void terminer();
   
   private:
      QUdpSocket     *udpSocket;
      bool           statut;
      
      int  VerifierDatagramme(char *donneesBrutes, int nbOctets);
      int  TraiterDatagramme(char *donneesBrutes, int nbOctets);
};

#endif // DIALOGUECONSOLE_H
