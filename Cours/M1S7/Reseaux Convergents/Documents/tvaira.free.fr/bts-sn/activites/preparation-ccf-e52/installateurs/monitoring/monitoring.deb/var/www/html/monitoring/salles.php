<?php
//error_reporting(E_ALL);
require_once ('./include/monitoring.inc.php');

$str = toString($_GET);
UpdateLog($str, $GLOBALS['config']['logfile']);

$base = NULL;
if ($GLOBALS['config']['bd'] == "sqlite") 
    $base = ouvrirBase();
else if ($GLOBALS['config']['bd'] == "mysql")
    $base = connecterBase();

$salles = array();

if($base != NULL)
{
    if(!Empty($_GET["term"]))
    {
        $requete = "SELECT salles.* FROM salles WHERE nom LIKE '%".$_GET["term"]."%' ORDER BY `nom` ASC";
    }
    else
    {        
        $requete = "SELECT salles.* FROM salles ORDER BY `nom` ASC";
    }
    //debug($requete);
    UpdateLog("Requête SQL -> ".$requete, $GLOBALS['config']['logfile']);
    // Récupère la liste des salles connues
    if ($result = $base->query($requete))
    {                         
       $i = 0;
       if ($GLOBALS['config']['bd'] == "sqlite") 
       {
           while($salle = fetch_object($result)) 
           {
               $uneSalle["value"] = $salle->nom;
               $uneSalle["label"] = $salle->nom." ($salle->ip)";
               $uneSalle["desc"] = "<p>Salle ".$salle->nom." ($salle->ip)</p>";
               $salles[$i++] = $uneSalle;
           }
       } 
       else if ($GLOBALS['config']['bd'] == "mysql")
       {
           while($salle = $result->fetch_object()) 
           {
               $uneSalle["value"] = $salle->nom;
               $uneSalle["label"] = $salle->nom." ($salle->ip)";
               $uneSalle["desc"] = "<p>Salle ".$salle->nom." ($salle->ip)</p>";
               $salles[$i++] = $uneSalle;
           }
           $result->free();
       }        
    }
    else
    {
        UpdateLog("Erreur requête SQL ! ".$requete, $GLOBALS['config']['logfile']);
        //debug($requete);
        if ($GLOBALS['config']['bd'] == "mysql")     
            debug($base->error);
    }
    if ($GLOBALS['config']['bd'] == "sqlite") 
        fermerBase($base);
    else if ($GLOBALS['config']['bd'] == "mysql")
        deconnecterBase($base);    
}
else
{
    $i = 0;
    for($j=0;$j<count($GLOBALS['config']['salles']);$j++) 
    {
        $salle = $GLOBALS['config']['salles'][$j];
        $pos = strpos($salle['nom'], $_GET["term"]);
        if ($pos === 0)
        {
            $uneSalle["value"] = $salle['nom'];
            $uneSalle["label"] = $salle['nom']." (".$salle['ip'].")";
            $uneSalle["desc"] = "<p>Salle ".$salle['nom']." (".$salle['ip'].")</p>";
            $salles[$i++] = $uneSalle;
        }
    }
}

echo json_encode($salles);
$str = toString($salles);
UpdateLog($str, $GLOBALS['config']['logfile']);

exit;
?>
