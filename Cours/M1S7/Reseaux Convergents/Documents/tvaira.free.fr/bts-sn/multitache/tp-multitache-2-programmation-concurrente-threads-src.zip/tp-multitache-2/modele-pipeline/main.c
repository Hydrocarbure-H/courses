// Pipeline

//#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <string.h>
#include <ctype.h>

//#define GUI

// taille de la file pour les requêtes
#define TAILLE_MAX 10

// nombre de requêtes à effectuer par le simulateur
#define NB_REQUETES 50

// nombre de threads
#define NB_THREADS_TRAVAILLEURS 3

typedef enum { NOIR, ROUGE, VERT, MARRON, BLEU, FUSHIA, CYAN, GRIS, NB_COULEURS } Couleur;
typedef enum { NORMAL, SOFTEN, NORMAL1, NORMAL2, SOULIGNE, BLINK, NORMAL3, INVERT } Mode;

#ifdef GUI
#define RESET_TERM()                printf("\x1b[0m")
#define SET_BGCOLOR(color)          printf("\x1b[1;37;4%dm",color)
#define SET_COLOR(color) 	        printf("\x1b[0;3%dm",color)
#define SET_MODECOLOR(mode,color)	printf("\x1b[%d;3%dm",mode,color)
#define SETCOLOR_SUCCESS()          printf("\x1b[1;32m")
#define SETCOLOR_FAILURE()          printf("\x1b[5;31m")
#define SETCOLOR_ERROR()            printf("\x1b[1;31m")
#define SETCOLOR_WARNING()          printf("\x1b[1;34m")
#define SETCOLOR_INFO()             printf("\x1b[0;37m")
#define SETCOLOR_NORMAL()           printf("\x1b[0;39m")
#define MOVE_TO_COL(col)	        printf("\x1B[%dG", col)
#define MOVE_XY(x,y)			    printf("\x1B[%d;%dH",x,y)
#define CLEAR_LINE(x,y)			    printf("\x1B[%d;%dH\x1b[2K",x,y)
#define RESET()					    printf("\x1B[2J")

#define LIGNE_SIMULATEUR            3
#define LIGNE_TRAVAILLEUR           LIGNE_SIMULATEUR+TAILLE_MAX+3
#define COLONNE_MOTIF               41
#endif

// Requête
typedef struct
{
    char motif;
    Couleur couleur;
    int nb;
    //int numeroTravailleur;
} Requete;

#define CLE     3

// Thread simulateur de requêtes
void *simulateur(void *nbRequetes);

// Threads travailleurs
void *travailleur1(void *);
void *travailleur2(void *);
void *travailleur3(void *);

pthread_t tidTravailleurs[NB_THREADS_TRAVAILLEURS];
int nbRequetes = NB_REQUETES;
Requete requetes[TAILLE_MAX]; // la file où seront déposées les requêtes
int in = 0; // indique le premier emplacement de libre pour déposer une requête


int main(void) 
{
    pthread_t tidSimulateur;

    setbuf(stdout, NULL);

    #ifdef GUI
    RESET();
    RESET_TERM();
    MOVE_XY(0,0);
    #endif
    printf("Répartiteur/Travailleurs : %d requêtes à traiter avec %d thread(s) travailleur(s)\n", nbRequetes, NB_THREADS_TRAVAILLEURS);

    pthread_create(&tidSimulateur, NULL, simulateur, (void *)&nbRequetes);
    pthread_create(&tidTravailleurs[0], NULL, travailleur1, NULL);
    pthread_create(&tidTravailleurs[1], NULL, travailleur2, NULL);
    pthread_create(&tidTravailleurs[2], NULL, travailleur3, NULL);
    
    pthread_join(tidSimulateur, NULL);
    for(int j=0;j<NB_THREADS_TRAVAILLEURS;j++)
    {
        pthread_join(tidTravailleurs[j], NULL);
        #ifdef GUI
        CLEAR_LINE(LIGNE_TRAVAILLEUR+j, 2);
        #endif
    }    

    #ifdef GUI
    CLEAR_LINE(LIGNE_TRAVAILLEUR-2, 2);
    CLEAR_LINE(LIGNE_SIMULATEUR, 2);
    RESET_TERM();
    MOVE_XY(1,0);
    #endif
    printf("\nTerminé\n");

    return 0;
}

void *simulateur(void *nbRequetes)
{
    Requete requete;
    int nb = *((int *)nbRequetes);

    srand(time(NULL));
    for(int i=0;i<nb;)
    {   
        

        // simule une attente avant l'arrivée d'une nouvelle requête
        if((i % 2) == 0)
            usleep(500000);
    }

    #ifdef GUI
    for(int i=0;i<TAILLE_MAX;i++)
        CLEAR_LINE(LIGNE_SIMULATEUR+i, 2);
    printf("\x1B[%d;%dH>>> Fin simulateur", LIGNE_SIMULATEUR, 2);
    #else
    printf("Fin simulateur\n");
    #endif
    pthread_exit(NULL);
    return NULL;
}

char cesar(char c, int cle)
{
   if('a' <= c && c <='z')
      return (c-'a'+cle)%26+'a';
   else if('A' <= c && c <='Z')
      return (c-'A'+cle)%26+'A';
   else
      return c;
}

void *travailleur1(void *inutilise)
{ 
    
    return NULL;
}

void *travailleur2(void *inutilise)
{
    
    return NULL;
}

void *travailleur3(void *inutilise)
{
    
    return NULL;
}
