#ifndef FINDDIALOG_H
#define FINDDIALOG_H

#include <QtGui>
#include <QDialog>

class QCheckBox;
class QLabel;
class QLineEdit;
class QPushButton;


class FindDialog : public QDialog 
{
    Q_OBJECT

    private:
        QLabel *label;
        QLineEdit *lineEdit;
        QCheckBox *caseCheckBox;
        QCheckBox *backwardCheckBox;
        QCheckBox *regCheckBox;
        QPushButton *findButton;
        QPushButton *closeButton; 

    public:
        FindDialog(QWidget *parent = 0);
        ~FindDialog();

    signals:
        void rechercherSuivant(const QString &str, Qt::CaseSensitivity cs);
        void rechercherPrecedent(const QString &str, Qt::CaseSensitivity cs);
        void rechercherSuivant(const QRegExp &re, Qt::CaseSensitivity cs);
        void rechercherPrecedent(const QRegExp &re, Qt::CaseSensitivity cs);

    private slots:
        void clicRechercher();
        void validerBouton(const QString &text);
};

#endif

