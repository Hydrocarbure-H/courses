#include "panneau.h"
#include "port.h"
#include <iostream>
#include <unistd.h>

using namespace std;

Panneau::Panneau(QString portPanneau)
{
    #ifdef DEBUG_PANNEAU
    qDebug() << Q_FUNC_INFO << "-> port : " << portPanneau;
    #endif
    
    #ifndef SIMULATION_PANNEAU
    port = new Port(portPanneau);
    #else
    Q_UNUSED(port)
    #endif
}

Panneau::~Panneau()
{
    #ifdef DEBUG_PANNEAU
    qDebug() << Q_FUNC_INFO;
    #endif
    #ifndef SIMULATION_PANNEAU
    delete port;
    #endif
}

void Panneau::afficher(QString message, int position)
{
    char trame[MAX_TRAME] = {FIN};
        
    #ifdef DEBUG_PANNEAU
    qDebug() << Q_FUNC_INFO << "-> message : " << message << "position : " << position;
    #endif

    // on fabrique la trame
    fabriquerTrame(&trame[0], message, position);
    
    // on envoie la trame
    envoyerTrame(trame);    

    //lireAcquittement(100);
}

int Panneau::envoyerTrame(char trame[MAX_TRAME])
{
    int retour = 0;

    #ifndef SIMULATION_PANNEAU
    retour = port->transmettre(trame);
    #else
    Q_UNUSED(trame)
    #endif    
    
    // si l'envoi de la trame echoue ?
    if (retour < 1)
    {
        #ifdef DEBUG_PANNEAU
        qDebug() << Q_FUNC_INFO << "-> erreur emission trame !";
        #endif
    }    

    return retour;
}

int Panneau::fabriquerTrame(char *trame, QString message, int position)
{
    int i = 0;
    char trameBrute[MAX_TRAME] = {SOT,NUM,NUM,OPT,AUX,F,F,AUX,Z,Z,STX,CHAN,LINE,FIN};

    // on concatène la position dans la trame
    sprintf(trame, "%s%02d", trameBrute, position);

    // on concatène le texte dans la trame
    strcat(trame, message.toLatin1());

    // on termine la trame
    i = strlen(trame);
    trame[i]   = ETX;
    trame[i+1] = EOT;
    trame[i+2] = FIN;    

    #ifdef DEBUG_PANNEAU
    char code[16];
    QString trameHexa = "";
    for(i = 0; i < (int)strlen(trame)-1; i++)
    {
        sprintf(code, "0x%02X ", trame[i]);
        trameHexa += code;
    }
    sprintf(code, "0x%02X", trame[i]);
    trameHexa += code;
    qDebug() << Q_FUNC_INFO << "-> trame : " << trameHexa;
    #endif

    return 0;
}

int Panneau::lireAcquittement(int timeout)
{
    int ret = 0;

    if(timeout > 0)
        usleep(timeout*1000);

    char ack;
    do
    {
        ack = port->lire();

        switch((int)ack)
        {
        case 0xC0: // packet received OK
            #ifdef DEBUG_PANNEAU
            qDebug() << Q_FUNC_INFO << "<- acquittement : packet received OK";
            #endif
            ret = 1;
            break;
        case 0xC1:
            #ifdef DEBUG_PANNEAU
            qDebug() << Q_FUNC_INFO << "<- acquittement : timeout !";
            #endif
            ret = 0;
            break;
        case 0xC2:
            #ifdef DEBUG_PANNEAU
            qDebug() << Q_FUNC_INFO << "<- acquittement : invalid value !";
            #endif
            ret = 0;
            break;
        case 0xC3:
            #ifdef DEBUG_PANNEAU
            qDebug() << Q_FUNC_INFO << "<- acquittement : invalid text !";
            #endif
            ret = 0;
            break;
        case 0xC4:
            #ifdef DEBUG_PANNEAU
            qDebug() << Q_FUNC_INFO << "<- acquittement : format error !";
            #endif
            ret = 0;
            break;
        default:
            #ifdef DEBUG_PANNEAU
            qDebug("<- acquittement : 0x%02x", (unsigned char)ack);
            #endif
            ret = 0;
            break;
        }
    }
    while(ack < 0xC0 || ack > 0xC4);

    /*QString acquittement;
    port->recevoir(acquittement);
    #ifdef DEBUG_PANNEAU
    qDebug() << Q_FUNC_INFO << "<- acquittement : " << acquittement;
    #endif*/

    return ret;
}
