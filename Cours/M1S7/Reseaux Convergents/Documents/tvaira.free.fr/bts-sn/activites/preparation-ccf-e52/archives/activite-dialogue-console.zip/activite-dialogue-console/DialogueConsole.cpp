#include "DialogueConsole.h"

#include <stdio.h>
#include <stdlib.h>
#include <string>

#include <iostream>

using namespace std;

DialogueConsole::DialogueConsole(QObject *pParent):
QObject(pParent)
{
   udpSocket = new QUdpSocket(this);
   
   // Attachement locale de la socket UDP :
   statut = udpSocket->bind(QHostAddress((QString)"0.0.0.0"), PORT_ENTTEC);
   //statut = udpSocket->bind(QHostAddress::LocalHost, PORT_ENTTEC);
    
   if(statut)
   {
      #ifdef DEBUG_DialogueConsole
      cout << "<" << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << "> " << "socket UDP sur le port 3330" << endl;
      #endif
   }
   else
   {
      #ifdef DEBUG_DialogueConsole
      cout << "<" << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << "> " << "erreur bind !" << endl;
      #endif
      QMessageBox::critical(NULL, "Serveur UDP", "Erreur bind sur le port 3330");
   }  
}

DialogueConsole::~DialogueConsole()
{
   udpSocket->close();
   #ifdef DEBUG_DIALOGUECONSOLE
   cout << "<" << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << "> " << "socket UDP fermé" << endl;
   #endif
}

void DialogueConsole::demarrer()
{
    if(statut)
    {
       connect(udpSocket, SIGNAL(readyRead()), this, SLOT(ReceptionnerDatagrammes()));
       connect(this, SIGNAL(terminer()), qApp, SLOT(quit()));
    }
}

void DialogueConsole::ReceptionnerDatagrammes()
{
   int nbOctets = 0;   
   int etat;
   
   while (udpSocket->hasPendingDatagrams()) // Retourne vrai si au moins un datagramme est en attente d'être lu
   {
      QByteArray donneesDatagramme;
      QHostAddress emetteurAdresse;
      quint16 emetteurPort;      

      // Fixe la taille du tableau au nombre d'octets reçus en attente
      donneesDatagramme.resize(udpSocket->pendingDatagramSize());
      
      // Lit le datagramme en attente
      //nbOctets = udpSocket->readDatagram(datagram.data(), datagram.size());
      nbOctets = udpSocket->readDatagram(donneesDatagramme.data(), donneesDatagramme.size(), &emetteurAdresse, &emetteurPort);
      
      // Vérifie la validité du datagramme
      etat = VerifierDatagramme(donneesDatagramme.data(), nbOctets);      
      if(etat == 1)
      {  
        #ifdef DEBUG_DialogueConsole
        QString qs_emetteurAdresse = emetteurAdresse.toString();
        //cout << "<" << qs_emetteurAdresse.toStdString() << ":" << emetteurPort << "> " << nbOctets << " octets reçus :" << (datagram.data()) << endl;
        cout << "<" << qs_emetteurAdresse.toStdString() << ":" << emetteurPort << "> datagramme de " << nbOctets << " octet(s) reçu(s)" << endl;
        #endif

        TraiterDatagramme(donneesDatagramme.data(), donneesDatagramme.size());	
      }
      else
      {
        #ifdef DEBUG_DialogueConsole
        QString qs_emetteurAdresse = emetteurAdresse.toString();
        //cout << "<" << qs_emetteurAdresse.toStdString() << ":" << emetteurPort << "> " << nbOctets << " octets reçus :" << (datagram.data()) << endl;
        cout << "<" << qs_emetteurAdresse.toStdString() << ":" << emetteurPort << "> datagramme de " << nbOctets << " octet(s) reçu(s) : INVALIDE !" << endl;
        #endif
        emit terminer(); /* sinon on quitte ! (à modifier par la suite) */
      }
   }
}

int DialogueConsole::VerifierDatagramme(char *donneesBrutes, int nbOctets)
{
  // première vérification : la taille d'un datagramme Enttec est de 28 octets pour le message WOOD
  if(nbOctets != LG_MESSAGE_WOOD)
  { 
    return 0; // invalide
  }

  // deuxième vérification : le type du message doit être "WOOD"
  for(int i=0;i<INDEX_FIRMWARE;i++)
  {
    switch(i)
    {
      case 0 : if(donneesBrutes[i] != 'W') return 0; break; // invalide
      case 1 : if(donneesBrutes[i] != 'O') return 0; break; // invalide
      case 2 : if(donneesBrutes[i] != 'D') return 0; break; // invalide
      case 3 : if(donneesBrutes[i] != 'D') return 0; break; // invalide
    }
  }

  return 1; // valide
}

int DialogueConsole::TraiterDatagramme(char *donneesBrutes, int nbOctets)
{
  bool commande = false;
  bool enregistrement = false;
  int etat;
  int valeur;
  
  #ifdef DEBUG_DialogueConsole
  if(nbOctets == LG_MESSAGE_WOOD)
  {
      for(int i=0;i<INDEX_FIRMWARE;i++)
        printf("%c", donneesBrutes[i]); //WODD
      printf(" ");
      for(int i=INDEX_FIRMWARE;i<nbOctets;i++)
        printf("0x%02X ", (unsigned char)donneesBrutes[i]); // le reste des données du datagramme
      printf("\n\n");
  }
  #endif
  
  return 0;
}

