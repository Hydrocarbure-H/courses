#ifndef _PANNEAU_H
#define _PANNEAU_H

#include <QtCore>

#include <cstdio>
#include <cstdlib>
#include <termios.h>
#include <unistd.h>
#include <sys/fcntl.h>
#include <string.h>
#include <iostream>

using namespace std;

#define DEBUG_PANNEAU
//#define SIMULATION_PANNEAU

#define ESCAPE          0x1b
#define DELETE          0x7F
#define NOUVELLE_LIGNE	0x0a

#define MAX_TRAME       64
#define MAX_TEXTE       10

#define SOT             0x01
#define NUM             0x30
#define OPT             0x06
#define AUX             0x0F
#define F               0x46
#define Z               0x30
#define STX             0x02
#define CHAN            0x31
#define LINE            0x32
#define POS_DEFAUT      11
#define ETX             0x03
#define EOT             0x04
#define FIN             0x00 // fin de chaîne

class Port;

class Panneau
{
  private:
    Port *port;
    
    int envoyerTrame(char trame[MAX_TRAME]);
    int fabriquerTrame(char *trame, QString message, int position);
    int lireAcquittement(int timeout=250);

  public:
    Panneau(QString portPanneau = "/dev/ttyUSB0");
    ~Panneau();
    void afficher(QString message, int position=POS_DEFAUT);
};

#endif
