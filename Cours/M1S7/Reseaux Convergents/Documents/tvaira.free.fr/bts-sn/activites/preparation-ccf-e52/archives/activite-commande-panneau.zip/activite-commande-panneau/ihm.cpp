#include "ihm.h"
#include "panneau.h"

IHM::IHM( QWidget *parent ) : QWidget( parent ), panneauLumineux(NULL)
{
    // Pour l'affichage dans la fenêtre
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));

    // les widgets       
    labelAdresseIP = new QLabel(this);
    labelAdresseIP->setText(QString::fromUtf8("Adresse IP : "));
    leAdresseIP = new QLineEdit(this);
    leAdresseIP->setFixedWidth(150);
    labelPort = new QLabel(this);
    labelPort->setText(QString::fromUtf8("Port : "));
    lePort = new QLineEdit(this);
    lePort->setFixedWidth(150);
    bConnecter    = new QPushButton(QString::fromUtf8("Connecter"), this);
    bDeconnecter  = new QPushButton(QString::fromUtf8("Deconnecter"), this);
    bDeconnecter->setEnabled(false);
    bEnvoyer      = new QPushButton(QString::fromUtf8("Envoyer"), this);
    bEnvoyer->setEnabled(false);
    bReset        = new QPushButton(QString::fromUtf8("Reinitialiser"), this);
    bReset->setEnabled(false);
    listeTaillePolice = new QComboBox(this);
    message = new QTextEdit(this);
    message->setReadOnly(false);

    // mise ne place des layout
    QHBoxLayout *hLayout0 = new QHBoxLayout;
    QHBoxLayout *hLayout1 = new QHBoxLayout;
    QHBoxLayout *hLayout2 = new QHBoxLayout;
    QHBoxLayout *hLayout3 = new QHBoxLayout;
    QVBoxLayout *mainLayout = new QVBoxLayout;

    hLayout0->addWidget(labelAdresseIP);
    hLayout0->addWidget(leAdresseIP);
    hLayout0->addWidget(labelPort);
    hLayout0->addWidget(lePort);
    hLayout0->addWidget(bConnecter);
    hLayout0->addWidget(bDeconnecter);
    hLayout0->addStretch();
    hLayout1->addWidget(listeTaillePolice);
    hLayout1->addStretch();
    hLayout2->addWidget(message);
    hLayout3->addWidget(bEnvoyer);
    hLayout3->addWidget(bReset);
    hLayout3->addStretch();

    mainLayout->addLayout(hLayout0);
    mainLayout->addLayout(hLayout1);
    mainLayout->addLayout(hLayout2);
    mainLayout->addLayout(hLayout3);
    mainLayout->addStretch(1);
    setLayout(mainLayout);

    // intialisation
    initialiserListeTaillePolice();
    QFont font;
    font.setFamily("Courier");
    font.setFixedPitch(true);
    font.setPointSize(12);
    message->setFont(font);
    message->setPlainText("Température 23 °C");
    lireParametres();

    setWindowTitle(QString::fromUtf8("Panneau Led Moving Sign"));
    setFixedHeight(sizeHint().height());
    setFixedWidth(sizeHint().width());

    // les signaux/slots
    // TODO

    // Pour rester compatible avec le panneau (cf. QByteArray)
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("ISO-8859-1"));
}

IHM::~IHM()
{

}

void IHM::quitter()
{
    deconnecter();
    emit quit();
}

void IHM::initialiserListeTaillePolice()
{
    listeTaillePolice->insertItem(0, "SMALL");
    listeTaillePolice->insertItem(1, "SMALL_BOLD");
    listeTaillePolice->insertItem(2, "SMALL_WIDE");
    listeTaillePolice->insertItem(3, "SMALL_WIDE_BOLD");
    listeTaillePolice->insertItem(4, "SMALL_SHORT");
    listeTaillePolice->insertItem(5, "NORMAL");
    listeTaillePolice->insertItem(6, "NORMAL_BOLD");
    listeTaillePolice->insertItem(7, "NORMAL_WIDE");
    listeTaillePolice->insertItem(8, "NORMAL_WIDE_BOLD");
    listeTaillePolice->insertItem(9, "NORMAL_DISCARDED");
    listeTaillePolice->insertItem(10, "NORMAL_DISCARDED_BOLD");
    listeTaillePolice->insertItem(11, "NORMAL_MORE_DISCARDED_BOLD");
    listeTaillePolice->insertItem(12, "NORMAL_DISCARDED_BOLDER");
    listeTaillePolice->insertItem(13, "NORMAL_DISCARDED_WIDE");
    listeTaillePolice->insertItem(14, "NORMAL_DISCARDED_WIDE_BOLD");
    listeTaillePolice->insertItem(15, "BIG");
    listeTaillePolice->insertItem(16, "BIG_BOLD");
    listeTaillePolice->insertItem(17, "BIG_WIDE");
    listeTaillePolice->insertItem(18, "BIG_WIDE_BOLD");
    listeTaillePolice->insertItem(19, "BIGGER");
    listeTaillePolice->insertItem(20, "BIGGER_BOLD");
    listeTaillePolice->insertItem(21, "BIGGER_WIDE");
    listeTaillePolice->insertItem(22, "BIGGER_WIDE_BOLD");
}

void IHM::lireParametres()
{
    QSettings parametres("panneau.ini", QSettings::IniFormat);

    adresseIP = parametres.value("panneau/adresse", "192.168.52.250").toString();
    port = parametres.value("panneau/port", "10001").toInt();

    leAdresseIP->setText(adresseIP);
    lePort->setText(QString::number(port));

    #ifdef DEBUG_IHM
    qDebug() << QString::fromUtf8("<IHM::lireParametres()> adresse ip : %1").arg(adresseIP);
    qDebug() << QString::fromUtf8("<IHM::lireParametres()> port : %1").arg(port);
    #endif
}

void IHM::connecter()
{
    panneauLumineux = new PanneauLumineux(adresseIP, port, this);
    bool connecte = panneauLumineux->connecter();
    // TODO
}

void IHM::deconnecter()
{
    if(panneauLumineux != NULL)
    {
        // TODO
    }
}

void IHM::envoyer()
{
    if(panneauLumineux != NULL)
    {
        message->setReadOnly(true);

        QTextDocument *texte = message->document(); // le message : texte->toPlainText().toAscii()
        #ifdef DEBUG_IHM
        qDebug() << QString::fromUtf8("<IHM::envoyer()> message : %1").arg(texte->toPlainText());
        #endif
        QByteArray trame;
        bool etat;

        // TODO : envoyer le message

        message->setReadOnly(false);
    }
}

void IHM::reinitialiser()
{
    if(panneauLumineux != NULL)
    {
        panneauLumineux->reinitialiser();
    }
}

void IHM::changerTaillePolice(int choix)
{
    if(panneauLumineux != NULL)
    {
        panneauLumineux->changerTaillePolice(choix);
    }
}
