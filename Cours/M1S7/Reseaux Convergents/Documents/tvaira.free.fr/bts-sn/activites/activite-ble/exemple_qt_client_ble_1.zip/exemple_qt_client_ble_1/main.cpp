#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>

#include "ClientBLE.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;

    ClientBLE *clientBLE = new ClientBLE();
    engine.rootContext()->setContextProperty("ClientBLE", clientBLE);

    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    return app.exec();
}
