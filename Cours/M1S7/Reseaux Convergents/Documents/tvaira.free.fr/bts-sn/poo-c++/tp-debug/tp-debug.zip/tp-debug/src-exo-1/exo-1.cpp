#include <iostream>

using namespace std;

float calculTTC(float, float);

int main(void)
{
  float prix_ht, prix_ttc, tva;

  cout << "Calcul du prix TTC\n\n";

  cout << "Entrez un prix HT et la TVA : ";
  cin >> prix_ht >> tva;

  prix_ttc = calculTTC(tva, prix_ht);

  cout << "\n" << prix_ht << " euros HT = " << prix_ttc << " euros TTC\n";

  return 0;
}

float calculTTC(float prix_ht, float tva)
{
   float prix_ttc;
   
   prix_ttc = prix_ht * tva / (100 + prix_ht);
   //prix_ttc = (prix_ht + prix_ht * tva) / 100;
  
   return prix_ht;
}
