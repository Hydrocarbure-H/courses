#include <QtCore/QCoreApplication>
#include <QDebug>

float calculTTC(float, float);

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
  
    float prix_ht, prix_ttc, tva;

    qDebug() << "Calcul du prix TTC\n";

    qDebug() << "Entrez un prix HT et la TVA ";
    prix_ht = 100.;
    tva = 19.6;
    qDebug() << "Prix euros HT = " << prix_ht;
    qDebug() << "TVA = " << tva;

    prix_ttc = calculTTC(tva, prix_ht);

    qDebug() << prix_ht << " euros HT => " << prix_ttc << " euros TTC\n";

    return 0;
}

float calculTTC(float prix_ht, float tva)
{
   float prix_ttc;
   
   prix_ttc = prix_ht * tva / (100 + prix_ht);
   //prix_ttc = (prix_ht + prix_ht * tva) / 100;
  
   return prix_ht;
}
