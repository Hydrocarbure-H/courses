#ifndef MAFENETRE_H
#define MAFENETRE_H

#include <QtGui>
#include <QFileInfo>
#include <QSettings>
#include <QMessageBox>
#include <QDebug>

// La structure de données pour une mesure
typedef struct
{
    QString horodatage;
    double  valeur;
} Mesure;

// Par défaut
#define NB_MESURES 10
// Plage de mesure
#define MIN 20
#define MAX 40

class MaFenetre : public QWidget
{
    Q_OBJECT
public:
    explicit MaFenetre(QWidget *parent = 0);
    ~MaFenetre();
    
private:
    QLabel          *labelNbMesures;
    QSpinBox        *editNbMesures;
    QTableWidget    *tableauMesures;
    QPushButton     *boutonAcquerir;
    QPushButton     *boutonCharger;
    QPushButton     *boutonEnregistrer;
    QVector<Mesure> mesures;

    bool    lireCSV(const QString &fichier);
    bool    ecrireCSV();
    Mesure  generer(long min=MIN, long max=MAX);
    void    afficher();

signals:
    
public slots:
    void    acquerir();
    void    charger();
    void    enregistrer();
};

#endif // MAFENETRE_H
