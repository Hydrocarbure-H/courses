#include "pupitreconducteur.h"
#include <iostream>

using namespace std;

PupitreConducteur::PupitreConducteur(QString port /*= "/dev/ttyUSB0"*/)
{
    #ifndef SIMULATION_PUPITRE
	qtp = new QTP(port);
    #else
    Q_UNUSED(port)
    #endif
}

PupitreConducteur::~PupitreConducteur()
{
    #ifndef SIMULATION_PUPITRE
	delete qtp;
    #endif
}

void PupitreConducteur::gererMenuService()
{
    bool fini = false;
    char touche;

    do
    {
        afficherMenuPrincipal();

        #ifdef SIMULATION_PUPITRE
        lireTouche(&touche, 1, QTP_NOECHO);
        #else
        qtp->lireTouche(&touche, 1, QTP_NOECHO);
        #endif
        switch(touche)
        {
            case '1' :  
                        break;
            case '2' :  
                        break;
            case '3' :  
                        break;
            case '4' :  fini = true;
                        break;
            default  :  fini = false;
                        break;
        }
    }
    while(!fini);
}

void PupitreConducteur::afficherMenuPrincipal()
{
	char messages[][LG_LIGNE+1] = 
	{
        //{"* MENU PRINCIPAL *"},
		{"1. PRISE DE SERVICE"},
		{"2. FIN DE SERVICE"},
        {"3. DEMARRER COURSE"},
        {"4. QUITTER"}
	};

	afficherMessage(messages);    
}

void PupitreConducteur::quitter()
{
	char messages[][LG_LIGNE+1] = 
	{
		{""},
		{"        FIN         "},
		{""},
	};

	afficherMessage(messages);
	sleep(2);
	effacer();
}

void PupitreConducteur::afficherMessage(char messages[][LG_LIGNE+1])
{
	int nbLignes = NB_LIGNES;
	int i;

    #ifdef SIMULATION_PUPITRE
    for(i=0;i<nbLignes;i++)
    {
        qDebug("%s", messages[i]);
    }
    #else
	qtp->cursorOff();
	for(i=0;i<nbLignes;i++)
	{
		qtp->gotoxy(i, 0);
		qtp->clearEndofline();
		qtp->afficher(messages[i], strlen(messages[i]));
	}
    #endif
}

void PupitreConducteur::effacer()
{
	int nbLignes = NB_LIGNES;
	int i;

    #ifdef SIMULATION_PUPITRE
    Q_UNUSED(nbLignes)
    Q_UNUSED(i)
    //system("clear");
    #else
	qtp->cursorOff();
	for(i=0;i<nbLignes;i++)
	{
		qtp->gotoxy(i, 0);
		qtp->clearEndofline();
	}
	qtp->cursorOn();
    #endif
}

// Simulation du clavier QTP
char PupitreConducteur::lireTouche(char *touche, int nbchar, int mode)
{
    Q_UNUSED(mode)

    char key;
    int lus;

    for(lus=0;lus<nbchar;lus++)
    {
        cin >> key;
        *(touche+lus) = key;
    }

    // conversion de touche (key)
    if (key == 48)
    {
        key = 0;
    }
    if (key == 49)
    {
        key = 1;
    }
    if (key == 50)
    {
        key = 2;
    }
    if (key == 51)
    {
        key = 3;
    }
    if (key == 52)
    {
        key = 4;
    }
    if (key == 53)
    {
        key = 5;
    }
    if (key == 54)
    {
        key = 6;
    }
    if (key == 55)
    {
        key = 7;
    }
    if (key == 56)
    {
        key = 8;
    }
    if (key == 57)
    {
        key = 9;
    }
    if (key == 0x23)
    {
        key = DIESE;
    }
    if (key == 0x2A)
    {
        key = ETOILE;
    }
    
    return key;
}
