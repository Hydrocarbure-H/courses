// threads.1.c

//#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

//#define GUI

#ifdef GUI
typedef enum { NOIR, ROUGE, VERT, MARRON, BLEU, FUSHIA, CYAN, GRIS, NB_COULEURS } Couleur;
typedef enum { NORMAL, SOFTEN, NORMAL1, NORMAL2, SOULIGNE, BLINK, NORMAL3, INVERT } Mode;

#define RESET_TERM()                printf("\x1b[0m")
#define SET_BGCOLOR(color)          printf("\x1b[1;37;4%dm",color)
#define SET_COLOR(color) 	        printf("\x1b[0;3%dm",color)
#define SET_MODECOLOR(mode,color)	printf("\x1b[%d;3%dm",mode,color)
#define SETCOLOR_SUCCESS()          printf("\x1b[1;32m")
#define SETCOLOR_FAILURE()          printf("\x1b[5;31m")
#define SETCOLOR_ERROR()            printf("\x1b[1;31m")
#define SETCOLOR_WARNING()          printf("\x1b[1;34m")
#define SETCOLOR_INFO()             printf("\x1b[0;37m")
#define SETCOLOR_NORMAL()           printf("\x1b[0;39m")
#define MOVE_TO_COL(col)	        printf("\x1B[%dG", col)
#define MOVE_XY(x,y)			    printf("\x1B[%d;%dH",x,y)
#define CLEAR_LINE(x,y)			    printf("\x1B[%d;%dH\x1b[2K",x,y)
#define RESET()					    printf("\x1B[2J")

#define LIGNE_THREAD1               4
#define LIGNE_THREAD2               LIGNE_THREAD1+5
#define COLONNE_MOTIF               12
#endif

// Chaque thread (tache) va faire ses COUNT boucles
#define COUNT  50

// Fonctions correspondant au corps d'un thread (tache)
void *etoile(void *inutilise);
void *diese(void *inutilise);

int main(void) 
{
    pthread_t thread1, thread2;

    setbuf(stdout, NULL);

    #ifdef GUI
    RESET();
    RESET_TERM();
    MOVE_XY(0,0);
    #endif

    #ifdef GUI
    printf("\x1B[%d;%dHDébut : %d boucles", 0, 0, COUNT);
    #else
    printf("Début : %d boucles\n", COUNT);
    #endif    

    pthread_create(&thread1, NULL, etoile, NULL);
    pthread_create(&thread2, NULL, diese, NULL);

    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    #ifdef GUI
    CLEAR_LINE(0, 0);
    printf("\x1B[%d;%dHFin : %d boucles", 1, 0, COUNT);
    #else
    printf("Fin : %d boucles\n", COUNT);
    #endif    

    #ifdef GUI
    CLEAR_LINE(LIGNE_THREAD1, 2);
    CLEAR_LINE(LIGNE_THREAD1+1, 2);
    CLEAR_LINE(LIGNE_THREAD2, 2);
    CLEAR_LINE(LIGNE_THREAD2+1, 2);
    CLEAR_LINE(LIGNE_THREAD2+2, 2);
    RESET_TERM();
    MOVE_XY(1,0);
    #endif
    printf("\nTerminé\n");

    return EXIT_SUCCESS;
}

void *etoile(void *inutilise) 
{
    int count = 0;
    char motif = '*';

    #ifdef GUI
    printf("\x1B[%d;%dHThread1 : ", LIGNE_THREAD1, 2);
    #endif    
   
    while(1)
    {
        #ifdef GUI
        printf("\x1B[%d;%dH%c", LIGNE_THREAD1, COLONNE_MOTIF+count, motif);
        usleep(50000);
        #else
        write(1, &motif, 1);
        usleep(10000);
        #endif

        count++;

        if(count >= COUNT) 
        {
            #ifdef GUI
            printf("\x1B[%d;%dH>>> Le thread1 a fait ses %d boucles", LIGNE_THREAD1+1, 2, count);
            sleep(1);
            #else
            printf("\nLe thread1 a fait ses %d boucles\n", count);
            #endif
            pthread_exit(NULL);
            return(NULL);
        }
    }

    return NULL;
}

void *diese(void *inutilise) 
{
    int count = 0;
    char motif = '#';

    #ifdef GUI
    printf("\x1B[%d;%dHThread2 : ", LIGNE_THREAD2, 2);
    #endif    
   
    while(1)
    {
        #ifdef GUI
        printf("\x1B[%d;%dH%c", LIGNE_THREAD2, COLONNE_MOTIF+count, motif);
        usleep(50000);
        #else
        write(1, &motif, 1);
        usleep(10000);
        #endif

        count++;

        if(count >= COUNT) 
        {
            #ifdef GUI
            printf("\x1B[%d;%dH>>> Le thread2 a fait ses %d boucles", LIGNE_THREAD2+1, 2, count);
            sleep(1);
            #else
            printf("\nLe thread2 a fait ses %d boucles\n", count);
            #endif
            pthread_exit(NULL);
            return(NULL);
        }
    }

    return NULL;
}
