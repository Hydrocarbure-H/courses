#include <QApplication>
#include "client.h"

int main(int argc, char ** argv)
{
	QApplication app( argc, argv );
    Client client;
    bool retour;

    if(argc == 3)
        retour = client.demarrer(argv[1], atoi(argv[2]));
    else if(argc == 2)
        retour = client.demarrer(argv[1]);
    else
       retour = client.demarrer();

    if(retour)
        return app.exec();
    return 1;
}
