#include "historique.h"

Historique::Historique(int taille/*=LG_HISTORIQUE*/) : indice(0), taille(taille)
{
	historique = new TInfo[taille];
}

Historique::~Historique()
{
	delete [] historique;
}

unsigned int Historique::getNbEvenements() const
{
   return indice;
}

unsigned int Historique::getTaille() const
{
   return taille;
}

void Historique::ajouterOrdre(TOrdre ordre)
{
   // quelle est la bonne solution ?
}

// Solution 1 :
void Historique::ajouterOrdreSolution1(TOrdre ordre)
{
   historique[indice].date = time(NULL);
   historique[indice].infoOrdre = ordre;
   indice++;
}

// Solution 2 :
void Historique::ajouterOrdreSolution2(TOrdre ordre)
{
   if (indice >= taille ) indice = 0;
   historique[indice].date = time(NULL);
   historique[indice].infoOrdre = ordre;
   indice++;
}

// Solution 3 :               
void Historique::ajouterOrdreSolution3(TOrdre ordre)
{
   historique[indice].date = time(NULL);
   historique[indice].infoOrdre = ordre;
   if (indice++ > taille ) indice = 0;
}

// Solution 4 :
void Historique::ajouterOrdreSolution4(TOrdre ordre)
{
   historique[indice % LG_HISTORIQUE].date = time(NULL);
   historique[indice % LG_HISTORIQUE].infoOrdre = ordre;
   indice++;
}

void Historique::ajouterPosition(TPosition position)
{
   /* TODO */
}

void Historique::ajouterReponse(TReponse reponse)
{
   /* TODO */
}

void Historique::afficherDernierOrdre()
{
   /* TODO */
}
