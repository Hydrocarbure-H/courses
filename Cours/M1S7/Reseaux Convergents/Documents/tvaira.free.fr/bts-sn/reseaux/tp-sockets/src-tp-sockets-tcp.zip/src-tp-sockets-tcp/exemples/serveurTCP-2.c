#include <stdio.h>
#include <stdlib.h> /* pour exit */
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h> /* pour memset */
#include <netinet/in.h> /* pour struct sockaddr_in */
#include <arpa/inet.h> /* pour htons et inet_aton */
#include <unistd.h> /* pour sleep */

#define PORT IPPORT_USERRESERVED // = 5000

int main()
{
   int socketEcoute;
   struct sockaddr_in pointDeRencontreLocal;
   socklen_t longueurAdresse;

   // Crée un socket de communication 
   socketEcoute = socket(PF_INET, SOCK_STREAM, 0); /* 0 indique que l'on utilisera le protocole par défaut associé à SOCK_STREAM soit TCP */

   // Teste la valeur renvoyée par l'appel système socket()
   if(socketEcoute < 0) /* échec ? */
   {
      perror("socket"); // Affiche le message d'erreur
      exit(-1); // On sort en indiquant un code erreur
   } 

   printf("Socket créée avec succès ! (%d)\n", socketEcoute);

   // On prépare l'adresse d'attachement locale
   longueurAdresse = sizeof(struct sockaddr_in);
   memset(&pointDeRencontreLocal, 0x00, longueurAdresse);
   pointDeRencontreLocal.sin_family        = PF_INET;
   pointDeRencontreLocal.sin_addr.s_addr   = htonl(INADDR_ANY); // toutes les interfaces locales disponibles
   pointDeRencontreLocal.sin_port          = htons(PORT);   

   // On demande l'attachement local de la socket
   if((bind(socketEcoute, (struct sockaddr *)&pointDeRencontreLocal, longueurAdresse)) < 0)
   {
      perror("bind");
      exit(-2);
   }
   
   printf("Socket attachée avec succès !\n");

   // On fixe la taille de la file d'attente à 5 (pour les demande de connexion non encore traitées)
   if(listen(socketEcoute, 5) < 0)
   {
      perror("listen");
      exit(-3);
   }

   // Fin de l'étape n°6 !
   printf("Socket placée en écoute passive ...\n");
   
   // On ferme la ressource avant de quitter   
   close(socketEcoute);

   return 0;
}
