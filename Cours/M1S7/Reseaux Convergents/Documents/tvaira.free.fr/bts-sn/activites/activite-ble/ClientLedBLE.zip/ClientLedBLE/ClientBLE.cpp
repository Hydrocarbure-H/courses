#include "ClientBLE.h"
#include "appareilble.h"

#include <QBluetoothDeviceInfo>
#include <QDebug>
#include <QtEndian>

ClientBLE::ClientBLE() : m_discoveryAgent(NULL), m_controller(NULL), m_service(NULL), m_etatConnexion(false), m_etatRecherche(false), m_connexionErreur(false), m_appareilDetecte(false)
{
    qDebug() << Q_FUNC_INFO;
    m_discoveryAgent = new QBluetoothDeviceDiscoveryAgent();
    m_discoveryAgent->setLowEnergyDiscoveryTimeout(5000);
    // Slot pour la recherche d'appareils BLE
    connect(m_discoveryAgent, SIGNAL(deviceDiscovered(QBluetoothDeviceInfo)), this, SLOT(ajouterAppareil(QBluetoothDeviceInfo)));
    connect(m_discoveryAgent, SIGNAL(error(QBluetoothDeviceDiscoveryAgent::Error)), this, SLOT(rechercheErreur(QBluetoothDeviceDiscoveryAgent::Error)));
    connect(m_discoveryAgent, SIGNAL(finished()), this, SLOT(rechercheTerminee()));
}

ClientBLE::~ClientBLE()
{
    if (m_controller)
        m_controller->disconnectFromDevice();
    delete m_controller;
    qDeleteAll(m_devices);
    qDebug() << Q_FUNC_INFO;
}

void ClientBLE::rechercher()
{
    qDeleteAll(m_devices);
    m_devices.clear();
    m_appareilDetecte = false;
    emit detecte();
    emit appareilsUpdated();

    qDebug() << Q_FUNC_INFO << "recherche appareil ble";
    m_discoveryAgent->start(QBluetoothDeviceDiscoveryAgent::LowEnergyMethod);
    if (m_discoveryAgent->isActive())
    {
        m_etatRecherche = true;
        emit recherche();
    }
}

void ClientBLE::arreter()
{
    if (m_etatRecherche && m_discoveryAgent->isActive())
    {
        qDebug() << Q_FUNC_INFO << "arret recherche appareil ble";
        m_discoveryAgent->stop();
    }
}

void ClientBLE::start(QString adresse)
{
    qDebug() << Q_FUNC_INFO << adresse;
    connecterAppareil(adresse);
}

void ClientBLE::stop()
{
    qDebug() << Q_FUNC_INFO;
    if (m_controller)
        m_controller->disconnectFromDevice();
}

void ClientBLE::read()
{

}

void ClientBLE::write(const QByteArray &data)
{
    if(m_service && m_characteristic.isValid())
    {
        //qDebug() << Q_FUNC_INFO << m_service->serviceUuid().toString();
        if (m_characteristic.properties() & QLowEnergyCharacteristic::Write)
        {            
            if(data.length() <= MAX_SIZE)
            {
                qDebug() << Q_FUNC_INFO << m_characteristic.uuid().toString() << data << data.length();
                if(data.length() == 3)
                    qDebug("%02X %02X %02X", (unsigned char)data[0], data[1], data[2]);
                else if(data.length() == 7)
                    qDebug("%02X %02X %02X %02X %02X %02X %02X", (unsigned char)data[0], (unsigned char)data[1], (unsigned char)data[2], (unsigned char)data[3], (unsigned char)data[4], (unsigned char)data[5], (unsigned char)data[6]);
                m_service->writeCharacteristic(m_characteristic, data, QLowEnergyService::WriteWithoutResponse);
            }
        }
    }
}

void ClientBLE::write(int rouge, int vert, int bleu, int white/*=0*/)
{
    Q_UNUSED(white)
    QByteArray datas(7, 0);

    datas[0] = 0x56;
    datas[1] = static_cast<char>(rouge); //RR
    datas[2] = static_cast<char>(vert); // GG
    datas[3] = static_cast<char>(bleu); // BB
    datas[4] = 0x00; // WW
    datas[5] = 0xf0;
    datas[6] = 0xaa;

    write(datas);
}

void ClientBLE::write(bool etat)
{
    QByteArray datas(3, 0);

    datas[0] = 0xcc;
    if(etat)
        datas[1] = 0x23;
    else
        datas[1] = 0x24;
    datas[2] = 0x33;

    write(datas);
}

void ClientBLE::gererNotification(bool notification)
{
    if(m_service && m_characteristic.isValid())
    {
        if (m_characteristic.properties() & QLowEnergyCharacteristic::Notify)
        {
            QLowEnergyDescriptor descripteurNotification = m_characteristic.descriptor(QBluetoothUuid::ClientCharacteristicConfiguration);
            if (descripteurNotification.isValid())
            {
                // active la notification : 0100 ou désactive 0000
                qDebug() << Q_FUNC_INFO << "modification notification" << m_characteristic.uuid().toString() << notification;
                if(notification)
                    m_service->writeDescriptor(descripteurNotification, QByteArray::fromHex("0100"));
                else
                    m_service->writeDescriptor(descripteurNotification, QByteArray::fromHex("0000"));
            }
        }
    }
}

QVariant ClientBLE::getAppareils()
{
    return QVariant::fromValue(m_devices);
}

void ClientBLE::ajouterAppareil(const QBluetoothDeviceInfo &info)
{
    // Bluetooth Low Energy ?
    if (info.coreConfigurations() & QBluetoothDeviceInfo::LowEnergyCoreConfiguration)
    {
        qDebug() << Q_FUNC_INFO << "appareil ble" << info.name() << info.address().toString();
        // Magic Blue ?
        if(info.name().startsWith("LEDBLE"))
        {
            qDebug() << Q_FUNC_INFO << "magic blue ble" << info.name() << info.address().toString();
            AppareilBLE *a = new AppareilBLE(info.name(), info.address().toString(), this);
            m_devices.append(a);
            m_appareilDetecte = true;
        }
    }
}

void ClientBLE::rechercheTerminee()
{
    m_etatRecherche = false;
    emit recherche();
    emit detecte();
    emit appareilsUpdated();
    if (m_devices.isEmpty())
        qDebug() << Q_FUNC_INFO << "recherche terminee : aucun appareil ble trouve !";
    else
        qDebug() << Q_FUNC_INFO << "recherche terminee";
}

void ClientBLE::rechercheErreur(QBluetoothDeviceDiscoveryAgent::Error erreur)
{
    if (erreur == QBluetoothDeviceDiscoveryAgent::PoweredOffError)
    {
        qDebug() << Q_FUNC_INFO << "bluetooth non activé !";
    }
    else if (erreur == QBluetoothDeviceDiscoveryAgent::UnknownError)
    {
        qDebug() << Q_FUNC_INFO << "erreur inconnue !";
    }
    else
    {
        qDebug() << Q_FUNC_INFO << "erreur scan !";
    }
    m_etatRecherche = false;
    emit recherche();
    emit detecte();
    emit appareilsUpdated();
}

void ClientBLE::connecterAppareil(const QString &adresseServeur)
{
    m_controller =  new QLowEnergyController(QBluetoothAddress(adresseServeur), this);

    // Slot pour la récupération des services
    connect(m_controller, SIGNAL(serviceDiscovered(QBluetoothUuid)), this, SLOT(ajouterService(QBluetoothUuid)));
    connect(m_controller, SIGNAL(connected()), this, SLOT(appareilConnecte()));
    connect(m_controller, SIGNAL(disconnected()), this, SLOT(appareilDeconnecte()));
    connect(m_controller, SIGNAL(error(QLowEnergyController::Error)), this, SLOT(connecteErreur(QLowEnergyController::Error)));

    qDebug() << Q_FUNC_INFO << "demande de connexion";
    m_connexionErreur = false;
    emit erreur();
    m_controller->setRemoteAddressType(QLowEnergyController::PublicAddress);
    m_controller->connectToDevice();
}

void ClientBLE::connecterService(QLowEnergyService *service)
{
    m_service = service;

    if (m_service->state() == QLowEnergyService::DiscoveryRequired)
    {
        // Slot pour le changement d'une caractéristique
        connect(m_service, SIGNAL(characteristicChanged(QLowEnergyCharacteristic,QByteArray)), this, SLOT(serviceCharacteristicChanged(QLowEnergyCharacteristic,QByteArray)));
        // Slot pour la récupération des caractéristiques
        connect(m_service, SIGNAL(stateChanged(QLowEnergyService::ServiceState)), this, SLOT(serviceDetailsDiscovered(QLowEnergyService::ServiceState)));

        qDebug() << Q_FUNC_INFO << "découverte des détails des services";
        m_service->discoverDetails();
    }
}

void ClientBLE::ajouterService(QBluetoothUuid serviceUuid)
{
    qDebug() << Q_FUNC_INFO << serviceUuid.toString();
    QLowEnergyService *service = m_controller->createServiceObject(serviceUuid);
    connecterService(service);
}

void ClientBLE::serviceCharacteristicChanged(const QLowEnergyCharacteristic &c, const QByteArray &value)
{
    qDebug() << Q_FUNC_INFO << c.uuid().toString() << value;
}

void ClientBLE::serviceDetailsDiscovered(QLowEnergyService::ServiceState newState)
{
    Q_UNUSED(newState)

    // décourverte ?
    if (newState != QLowEnergyService::ServiceDiscovered)
    {
        return;
    }

    QLowEnergyService *service = qobject_cast<QLowEnergyService *>(sender());
    qDebug() << Q_FUNC_INFO << "service" << service->serviceUuid().toString();

    if (service->serviceUuid().toString() == SERVICE_UUID)
    {
        foreach (QLowEnergyCharacteristic c, service->characteristics())
        {
            qDebug() << Q_FUNC_INFO << "characteristic" << c.uuid().toString();
            if (c.uuid().toString() == CHARACTERISTIC_UUID)
            {
                qDebug() << Q_FUNC_INFO << "my characteristic" << c.uuid().toString() << (c.properties() & QLowEnergyCharacteristic::Write);
                m_characteristic = c;
                m_service = service;
            }

            m_etatConnexion = true;
            emit connecte();
        }
    }
}

void ClientBLE::appareilConnecte()
{
    qDebug() << Q_FUNC_INFO;
    m_controller->discoverServices();
}

void ClientBLE::appareilDeconnecte()
{
    qDebug() << Q_FUNC_INFO;
    m_etatConnexion = false;
    emit connecte();
}

void ClientBLE::connecteErreur(QLowEnergyController::Error error)
{
    qDebug() << Q_FUNC_INFO << error;
    m_etatConnexion = false;
    m_connexionErreur = true;
    emit connecte();
    emit erreur();
}
