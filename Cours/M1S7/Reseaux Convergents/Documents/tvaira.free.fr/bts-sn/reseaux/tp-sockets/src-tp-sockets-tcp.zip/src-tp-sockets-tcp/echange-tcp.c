#include "echange-tcp.h"

ssize_t ecrireLigne(int sock, const void *buffer, size_t nb)
{
   ssize_t aEcrire, ecrits;

   aEcrire = nb;
   while ( aEcrire > 0 ) 
   {
      ecrits = write(sock, buffer, aEcrire);
      if ( ecrits <= 0 )
         return ecrits;  /* erreur ou aucune écriture */
      aEcrire -= ecrits; /* on décompte le nombre d'octets déjà écrits */
      buffer += ecrits;  /* on se déplace du nombre d'octets déjà écrits */
   }
   ecrits = write(sock, "\r\n", 2);
   if ( ecrits == 2 ) return 1; // ok

   return ecrits;
} 

ssize_t ecrireDonnees(int sock, const void *buffer, size_t nb)
{
   ssize_t aEcrire, ecrits;

   aEcrire = nb;
   while ( aEcrire > 0 ) 
   {
      ecrits = write(sock, buffer, aEcrire);
      if ( ecrits <= 0 )
         return ecrits;  /* erreur ou aucune écriture */
      aEcrire -= ecrits; /* on décompte le nombre d'octets déjà écrits */
      buffer += ecrits;  /* on se déplace du nombre d'octets déjà écrits */
   }
   return ( nb - aEcrire );
} 

ssize_t lireLigne(int sock, void *buffer, size_t nbMax)
{
   ssize_t aLire, lus;
   char data;
   char *start = (char *)buffer;
   char *ligne;

   aLire = nbMax;
   while ( aLire > 0 ) 
   {
      lus = read(sock, &data, 1); 
      if ( lus < 0 )
            return lus;     /* erreur */
      else
         if ( lus == 0 )
            return 0; /* fin de lecture */
         
         *(char *)buffer = data;
         aLire -= lus;    /* on decompte le nombre d'octets deja lus */            
         buffer += lus;   /* on se deplace du nombre d'octets deja lus */
         *(char *)buffer = 0x00; /* fin de chaine */
         //printf("aLire = %d - lus = %d -> %s\n", aLire, lus, start);
         /* on recherche les délimiteurs "\r\n" */
         ligne = (char *)strstr(start, "\r\n");
         if (ligne != NULL)
         {
            buffer -= 2;   /* on se recule du nombre d'octets des délimiteurs */
            *(char *)buffer = 0x00; /* fin de chaine */
            return 1; // ok
         }
   }

   return (nbMax - aLire);
}

ssize_t lireDonnees(int sock, void *buffer, size_t nbMax)
{
   ssize_t aLire, lus;
   char data;
   char *start = (char *)buffer;
   char *ligne;

   aLire = nbMax;
   while ( aLire > 0 ) 
   {
      lus = read(sock, &data, 1); 
      if ( lus < 0 )
            return lus;     /* erreur */
      else
         if ( lus == 0 )
            return 0; /* fin de lecture */
         
         *(char *)buffer = data;
         aLire -= lus;    /* on decompte le nombre d'octets deja lus */            
         buffer += lus;   /* on se deplace du nombre d'octets deja lus */
   }
   *(char *)buffer = 0x00; /* fin de chaine */
   printf("aLire = %d - nbMax = %d -> %s\n", aLire, nbMax, start);

   return (nbMax - aLire);
}
