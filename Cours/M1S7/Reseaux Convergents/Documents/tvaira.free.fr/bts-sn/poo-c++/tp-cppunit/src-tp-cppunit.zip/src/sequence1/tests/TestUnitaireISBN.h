#ifndef _TESTUNITAIREISBN_H
#define _TESTUNITAIREISBN_H

#include <cppunit/extensions/HelperMacros.h>

class ISBN; // La classe à tester

class TestUnitaireISBN : public CPPUNIT_NS::TestFixture
{
  CPPUNIT_TEST_SUITE( TestUnitaireISBN );
  CPPUNIT_TEST( testEstValideISBN10 ) ;
  CPPUNIT_TEST( testEstValideISBN13 ) ;
  CPPUNIT_TEST( testSetterISBN10 ) ;
  CPPUNIT_TEST( testSetterISBN13 ) ;
  CPPUNIT_TEST( testNettoieISBN ) ;
  // TODO : etc ...
  CPPUNIT_TEST_SUITE_END();

private:
   ISBN *isbn;
   
public:
   TestUnitaireISBN();
   virtual ~TestUnitaireISBN();

   // Call before tests
   void setUp();
   // Call after tests
   void tearDown();
        
   // Liste des tests
   void testEstValideISBN10();
   void testEstValideISBN13();
   void testSetterISBN10();
   void testSetterISBN13();
   void testNettoieISBN();
   // TODO : etc ...
};

#endif
