#include "port.h"

#include <QDebug>

Port::Port():port(NULL)
{
}

Port::Port(const QString &portName):port(NULL)
{
   #ifdef DEBUG_PORT
   qDebug() << "<Port::Port()> port : " << portName;
   #endif
    
   if(!portName.isEmpty())
   {
       ouvrir(portName, 9600);
   }
}

Port::~Port()
{
   if (port != NULL && port->isOpen())
      port->close();
}

bool Port::ouvrir(const QString &portName, int debit)
{
   if (port != NULL && port->isOpen())
      port->close();

   // mode synchrone : QextSerialPort::EventDriven (Can only be used with threads started with QThread) 
   //port = new QextSerialPort(QLatin1String("/dev/ttyAMA0"), QextSerialPort::EventDriven);
   // ou 
   // mode asynchrone : QextSerialPort::Polling
   this->port = new QextSerialPort(portName, QextSerialPort::Polling);
   switch(debit)
   {
   case 9600 :
       port->setBaudRate(BAUD9600);
       break;
   case 4800 :
       port->setBaudRate(BAUD4800);
       break;
   }
   port->setFlowControl(FLOW_OFF);
   port->setParity(PAR_NONE);
   port->setDataBits(DATA_8);
   port->setStopBits(STOP_1);
   port->setTimeout(500);

   //port->open(QIODevice::ReadWrite | QIODevice::Unbuffered);
   if (port->open(QIODevice::ReadWrite) == true) 
   {
      connect(port, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
      #ifdef DEBUG_PORT
      qDebug() << "<Port::ouvrir()> port " << port->portName() << " ouvert";
      #endif
   }
   else 
   {
      qDebug() << "<Port::ouvrir()> Erreur ouverture port " << port->portName();
   }

   return port->isOpen();
}

int Port::transmettre(const QString &message)
{
   int nbOctets = -1;

   if (port == NULL || !port->isOpen())
      return -1;

   nbOctets = port->write(message.toLatin1());
   
   #ifdef DEBUG_PORT
   qDebug("<Port::transmettre()> octets transmis : %d", nbOctets);
   qDebug() << "<Port::transmettre()> message transmis : " << message;
   #endif
   
   return nbOctets;
}

int Port::recevoir(QString &message)
{
   char buffer[BUFFERSIZE+1]; // + fin de chaine
   
   int nbOctets = -1;
   
   if (port == NULL || !port->isOpen())
      return -1;

   nbOctets = port->bytesAvailable();
   if(nbOctets > BUFFERSIZE)
       nbOctets = BUFFERSIZE;
   #ifdef DEBUG_PORT
   if(nbOctets != 0)
      qDebug("<Port::recevoir()> octets recus disponibles : %d", nbOctets);
   #endif

   int n = port->read(buffer, nbOctets);
   if (n != -1)
       buffer[n] = '\0'; // fin de chaine
   else
       buffer[0] = '\0'; // fin de chaine

   message = QLatin1String(buffer);

   #ifdef DEBUG_PORT
   if(n != 0)
   {
      qDebug("<Port::recevoir()> octets lus : %d", n);
      for(int i=0;i<n;i++)
         printf("0x%02X ", (unsigned char)buffer[i]);
      printf("\n\n");
   }   
   #endif

   return n;
}

char Port::lire()
{
   if (port == NULL || !port->isOpen())
      return -1;

   char c;
   int n = port->read(&c, 1);
   if (n == -1)
       c = '\0'; // fin de chaine

   //printf("%c (0x%02X)\n", c, c);

   return c;
}

long Port::getNbOctetsDisponibles()
{
   return port->bytesAvailable();
}

void Port::onReadyRead()
{
   QByteArray datas;
   
   int a = port->bytesAvailable();
   datas.resize(a);
   
   port->read(datas.data(), datas.size());
   #ifdef DEBUG_PORT
   qDebug() << "<Port::onReadyRead()> nb octets lus : " << datas.size();
   qDebug() << "<Port::onReadyRead()> donnees recues :" << datas;
   #endif
   
   #ifdef DEBUG_PORT
   for(int i=0;i<datas.size();i++)
      printf("0x%02X ", (unsigned char)datas.data()[i]);
   printf("\n\n");
   #endif
}

bool Port::estOuvert()
{
    if (port != NULL)
        return port->isOpen();
    else
        return false;
}
