#ifndef HISTORIQUE_H
#define HISTORIQUE_H

#include <ctime>

#define SEUIL_ALTITUDE_ALARME 39000

#define LG_HISTORIQUE 10

typedef long Altitude;

typedef struct
{
   time_t   date;
   Altitude altitude;
} TAlarme;

class Historique
{
	private:      
      unsigned int indice;
      const unsigned int taille;
      TAlarme *historique;

	public:
      Historique(int taille=LG_HISTORIQUE);
      ~Historique();
      
      unsigned int getNbAlarmes() const;
      unsigned int getTaille() const;
      
      void ajouterAlarme(Altitude altitude);
      void ajouterAlarmeSolution1(Altitude altitude);
      void ajouterAlarmeSolution2(Altitude altitude);
      void ajouterAlarmeSolution3(Altitude altitude);
      void ajouterAlarmeSolution4(Altitude altitude);

      void afficher() const;
      void afficherDerniereAlarme() const;
};

#endif
