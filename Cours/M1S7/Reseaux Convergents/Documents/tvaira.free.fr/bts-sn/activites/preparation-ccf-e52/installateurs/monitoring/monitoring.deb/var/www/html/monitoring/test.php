<?php
require_once ('./include/monitoring.inc.php');
require_once ('./include/salle.class.php');

function valideIP($ip)
{
   if(function_exists('inet_pton')) 
   {
      $in_addr = inet_pton($ip);
      if($in_addr === false)
            return false;
      else  return true;
   }
   if(function_exists('filter_var')) 
   {
      if(filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === FALSE)
            return false;
      else  return true;
   }
   if(ereg("^([0-9]{1,3}\.){3}[0-9]{1,3}$", $ip)) 
   {
      return true;
   }
   return false;
}

function ping($ip)
{
    UpdateLog("".__FUNCTION__."()", $GLOBALS['config']['logfile']);
    global $donnees;
    $verif = ini_get('safe_mode');
    if($verif == "1")
    {
        //echo("Désolé ! Ce serveur n'accepte pas l'exécution d'une commande externe.");
        $host = $ip;
        $timeout = 1;
        /* ICMP ping packet with a pre-calculated checksum */
        //$package = "\x08\x00\x7d\x4b\x00\x00\x00\x00PingHost";
        $package = "\x08\x00\x19\x2f\x00\x00\x00\x00\x70\x69\x6e\x67";
        $socket = socket_create(AF_INET, SOCK_RAW, 1);
        if ($socket === false) 
        {
            $donnees["message"] = "Erreur socket_create() : " . socket_strerror(socket_last_error()) . "";
            UpdateLog($donnees["message"], $GLOBALS['config']['logfile']);
            return false;
        }
        socket_strerror(socket_last_error($socket));
        socket_set_option($socket, SOL_SOCKET, SO_RCVTIMEO, array('sec' => $timeout, 'usec' => 0));
        socket_connect($socket, $host, null);
        $ts = microtime(true);
        socket_send($socket, $package, strLen($package), 0);
        if (socket_read($socket, 255)) 
        {
            $result = microtime(true) - $ts;
        } 
        else 
        {
            $donnees["message"] = "Erreur socket_read() : " . socket_strerror(socket_last_error($socket)) . "";
            UpdateLog($donnees["message"], $GLOBALS['config']['logfile']);
            $result = false;
        }
        socket_close($socket);
        return $result;
    }
    else
    {
        //echo("Ce serveur accepte l'exécution de la commande ping.");
        $nb = 1;
        $cmd = 'ping -c '.$nb.' '.$ip;
        @exec($cmd, $output, $return);
        for($i=0;$i<count($output);$i++)
            $contenu .= $output[$i]."\n";
        $str = toString($contenu);
        UpdateLog($str, $GLOBALS['config']['logfile']);
        if($return == 0)
        {
            UpdateLog("commande ping ok", $GLOBALS['config']['logfile']);
            return true;
        }
        else
        {
            $donnees["message"] = "ping erreur : " . $str . "";
            UpdateLog("commande ping erreur", $GLOBALS['config']['logfile']);
            return false;
        }        
    }
}

function read($sock, $size=128)
{
    $error = socket_last_error($sock);
    if ($error != SOCKET_EINPROGRESS && $error != SOCKET_EALREADY)
        return FALSE;
    //if(!socket_last_error($sock))
    //{        
        while($buffer = @socket_read($sock, $size, PHP_NORMAL_READ))
            if($buffer = trim($buffer))
                break;
    /*}
    else
        return FALSE;*/
    
    return $buffer;
}

function connecter(&$s, $remote, $port, $timeout = 10)
{
    socket_set_nonblock($s);

    $error = NULL;
    $attempts = 0;
    $timeout *= 1000;  // millisecondes
    $connected;
    while (!($connected = @socket_connect($s, $remote, $port+0)) && $attempts++ < $timeout)
    {
        $error = socket_last_error();
        if ($error != SOCKET_EINPROGRESS && $error != SOCKET_EALREADY)
        {
            //$this->errstr = "Error Connecting Socket: ".socket_strerror($error);
            //socket_close($s);
            return false;
        }
        if ($error == SOCKET_EISCONN)
        {
            $connected = true;
            break;
        }
        usleep(1000);
    }

    if (!$connected)
    {
        //$this->errstr = "Error Connecting Socket: Connect Timed Out After $timeout seconds. ".socket_strerror(socket_last_error());
        //socket_close($s);
        return false;
    }
   
    socket_set_block($s);

    return true;
} 

function recevoir($adresse, $port)
{	
    UpdateLog("".__FUNCTION__."()", $GLOBALS['config']['logfile']);
    global $donnees;
    $valid = false;
    $socket = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
    if ($socket === false) 
    {
		$valid = false;
        $donnees["message"] = "Erreur socket_create() : " . socket_strerror(socket_last_error()) . " [$adresse:$port]";
        UpdateLog($donnees['message'], $GLOBALS['config']['logfile']);
    }
    else
    {
        //$result = @socket_connect($socket, $adresse, $port);
        $result = connecter($socket, $adresse, $port);
        if ($socket === false || $result === false) 
        {
			$valid = false;
            $donnees["message"] = "Erreur socket_connect() : " . socket_strerror(socket_last_error($socket)) . " [$adresse:$port]";
            UpdateLog($donnees['message'], $GLOBALS['config']['logfile']);
        }
        else
        {       
            $sonde = false;
            $led = false;
            $trame = read($socket);
            //debug($trame);
            UpdateLog("Trame -> ".$trame, $GLOBALS['config']['logfile']);
            if($trame)
            {
                $champs = explode(";", $trame);
                if($champs[0] == "SONDE" && count($champs) >= 7)
                {
                    $sonde = true;
                    $donnees["message"] = $trame;
                }
                else if($champs[0] == "LED" && count($champs) >= 4)
                {
                    $led = true;
                    $donnees["message"] = $trame;
                }
                else
                {
                    $donnees["message"] = "Trame inconnue !";
                }
                $valid = ($sonde || $led);
            }
            else
            {
                $valid = false;
                $donnees["message"] = "Aucune trame reçue !";
            }
        }
    }
    
    //echo "Fermeture du socket ...";
    @socket_close($socket);
    
    return $valid;
}

$str = toString($_GET);
UpdateLog($str, $GLOBALS['config']['logfile']);
$donnees["ok"] = false;
$donnees["message"] = "";
if(!Empty($_GET["nom"]))
{
    $salle = new Salle($_GET["nom"]);
    if($salle->getTrouve())
    {
        if(!Empty($salle->getNom()))
        {
            if(!Empty($salle->getIp()))
            {
                if(valideIP($salle->getIp()))
                {
                    if(!Empty($_GET["action"]))
                    {
                        if($_GET["action"] == "ping")
                        {
                            $ok = ping($salle->getIp());
                            $donnees["ok"] = $ok;
                            //$donnees["message"] = "";
                        }
                        else if($_GET["action"] == "recv")
                        {
                            $ok = recevoir($salle->getIp(), $salle->getPort());
                            $donnees["ok"] = $ok;
                            //$donnees["message"] = "";
                        }
                        else
                        {
                            $donnees["message"] = "Erreur action inconnue !";
                            UpdateLog("Erreur action inconnue !", $GLOBALS['config']['logfile']);
                        }                    
                    }
                    else
                    {
                        $donnees["message"] = "Erreur action manquante !";
                        UpdateLog("Erreur action manquante !", $GLOBALS['config']['logfile']);
                    }
                }
                else
                {
                    $donnees["message"] = "Erreur adresse IP invalide !";
                    UpdateLog("Erreur adresse IP invalide !", $GLOBALS['config']['logfile']);
                }
            }
            else
            {
                $donnees["message"] = "Erreur adresse IP manquante !";
                UpdateLog("Erreur adresse IP manquante !", $GLOBALS['config']['logfile']);
            }
        }
        else
        {        
            $donnees["message"] = "Erreur nom de salle manquant !";
            UpdateLog("Erreur nom de salle manquant !", $GLOBALS['config']['logfile']);
        }
    }
    else
    {        
        $donnees["message"] = "Erreur salle introuvable !";
        UpdateLog("Erreur salle introuvable !", $GLOBALS['config']['logfile']);
    }
}
else
{
    $donnees["message"] = "Erreur nom manquant !";
    UpdateLog("Erreur nom manquant !", $GLOBALS['config']['logfile']);
}

echo json_encode($donnees);
$str = toString($donnees);
UpdateLog($str, $GLOBALS['config']['logfile']);
exit;
?>        
