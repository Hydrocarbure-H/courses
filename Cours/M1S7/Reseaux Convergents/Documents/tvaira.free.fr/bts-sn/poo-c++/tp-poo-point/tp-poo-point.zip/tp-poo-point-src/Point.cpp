#include <iostream>
#include <cmath> /* pour sqrt */

using namespace std;

#include "Point.h"

// Constructeurs


// Destructeur  


// Accesseurs et mutateurs


// Services
