#include "client.h"
#include <QDebug>

Client::Client(QObject *parent) : QObject(parent), socket(NULL)
{
    
}

bool Client::demarrer(QString adresse /*= ADRESSE_SERVEUR*/, int port /*= PORT_SERVEUR*/)
{
    

    return socket->isOpen();
}

void Client::estConnecte()
{
    
}

void Client::estDeconnecte()
{
    
}

void Client::recevoir()
{
    
}

void Client::envoyer(const QString &requete)
{
    
}
