#include <stdio.h>
#include <unistd.h>

int main()
{
   printf("Résultat de la commande ps -l :\n");
   execlp("ps", "ps", "-l", NULL); // cf. man execlp
   printf("Fin\n"); 
}

