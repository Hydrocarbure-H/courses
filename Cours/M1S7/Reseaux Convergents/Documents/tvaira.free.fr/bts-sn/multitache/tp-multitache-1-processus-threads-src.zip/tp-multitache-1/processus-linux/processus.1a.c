#include <stdio.h>

int main() 
{
   if (fork())
          printf("Je suis le père\n");
   else
          printf("Je suis le fils\n");

   return 0;
}

