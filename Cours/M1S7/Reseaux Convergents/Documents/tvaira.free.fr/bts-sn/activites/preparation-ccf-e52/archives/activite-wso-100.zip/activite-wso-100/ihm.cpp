#include "ihm.h"
#include "station.h"
#include "qwt_compass.h"
#include <qwt_dial_needle.h>
#include "qwt_thermo.h"

// $ sudo apt-get install libqwt-dev

IHM::IHM( QWidget *parent ) : QWidget( parent )
{    
    // les widgets       
    labelLieu = new QLabel(this);
    labelLieu->setText(QString::fromUtf8("Lieu : "));
    leLieu = new QLineEdit(this);
    leLieu->setFixedWidth(150);
    labelPeriode = new QLabel(this);
    labelPeriode->setText(QString::fromUtf8("Période : "));
    lePeriode = new QLineEdit(this);
    lePeriode->setFixedWidth(150);
    bDemarrer    = new QPushButton(QString::fromUtf8("Démarrer"), this);
    bArreter  = new QPushButton(QString::fromUtf8("Arrêter"), this);
    bArreter->setEnabled(false);
    message = new QTextEdit(this);
    message->setReadOnly(true);

    compassDirectionVent = new QwtCompass(this);
    //compassDirectionVent->setStyleSheet(QString::fromUtf8("color: rgb(170, 170, 255);"));
    compassDirectionVent->setLineWidth(4);
    compassDirectionVent->setScaleComponents(QwtAbstractScaleDraw::Ticks | QwtAbstractScaleDraw::Labels );
    compassDirectionVent->setScaleTicks(0, 0, 3);
    compassDirectionVent->setNeedle(new QwtCompassMagnetNeedle(QwtCompassMagnetNeedle::TriangleStyle, Qt::white, Qt::red));

    thermoTemperature = new QwtThermo(this);
    //thermoTemperature->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 127);"));
    thermoTemperature->setAlarmEnabled(true);
    thermoTemperature->setAlarmLevel(0);
    thermoTemperature->setScalePosition(QwtThermo::LeftScale);
    thermoTemperature->setSpacing(2);
    thermoTemperature->setMaxValue(50);
    thermoTemperature->setMinValue(-20);
    thermoTemperature->setScale(-20, 50, 10);
    thermoTemperature->setPipeWidth(10);

    // mise ne place des layout
    QHBoxLayout *hLayout0 = new QHBoxLayout;
    QHBoxLayout *hLayout1 = new QHBoxLayout;
    QHBoxLayout *hLayout2 = new QHBoxLayout;
    QHBoxLayout *hLayout3 = new QHBoxLayout;
    QVBoxLayout *mainLayout = new QVBoxLayout;

    hLayout0->addWidget(labelLieu);
    hLayout0->addWidget(leLieu);
    hLayout0->addWidget(labelPeriode);
    hLayout0->addWidget(lePeriode);
    hLayout0->addWidget(bDemarrer);
    hLayout0->addWidget(bArreter);
    hLayout0->addStretch();
    hLayout1->addWidget(thermoTemperature);
    hLayout1->addWidget(compassDirectionVent);
    hLayout2->addWidget(message);
    //hLayout2->addStretch();

    mainLayout->addLayout(hLayout0);
    mainLayout->addLayout(hLayout1);
    mainLayout->addLayout(hLayout2);
    //mainLayout->addStretch(1);
    setLayout(mainLayout);

    // intialisation
    QFont font;
    font.setPointSize(10);
    font.setBold(true);
    font.setWeight(75);
    compassDirectionVent->setFont(font);
    thermoTemperature->setFont(font);
    font.setFamily("Courier");
    font.setFixedPitch(true);
    font.setPointSize(12);
    message->setFont(font);

    lireParametres();

    stationMeteo = new StationMeteo(lieu.toStdString());
    timerStationMeteo = new QTimer(this);
    timerStationMeteo->setInterval(periode);

    setWindowTitle(QString::fromUtf8("Station météo WSO-100"));
    setFixedHeight(640);
    //setFixedHeight(sizeHint().height());
    setFixedWidth(sizeHint().width());

    // les signaux/slots
    connect(leLieu, SIGNAL(editingFinished()), this, SLOT(majLieu()));
    connect(lePeriode, SIGNAL(editingFinished()), this, SLOT(majPeriode()));
    connect(bDemarrer, SIGNAL(clicked()), this, SLOT(demarrer()));
    connect(bArreter, SIGNAL(clicked()), this, SLOT(arreter()));
    connect(timerStationMeteo, SIGNAL(timeout()), this, SLOT(acquerir()));
}

IHM::~IHM()
{
    delete stationMeteo;
}

void IHM::quitter()
{
    arreter();
    emit quit();
}

void IHM::lireParametres()
{
    QSettings parametres("wso-100.ini", QSettings::IniFormat);

    lieu = parametres.value("wso-100/lieu", "Inconnu").toString();
    periode = parametres.value("wso-100/periode", "60000").toInt();

    pgnWindData = parametres.value("wso-100/pgn-wind-data", "130306").toInt();
    pgnEnvironmentalParameters = parametres.value("wso-100/pgn-environmental-parameters", "130311").toInt();

    leLieu->setText(lieu);
    lePeriode->setText(QString::number(periode));
    QString infos;
    infos = "PGN : " + QString::number(pgnWindData) + "\n";
    infos += "PGN : " + QString::number(pgnEnvironmentalParameters);
    message->setPlainText(infos);

    #ifdef DEBUG_IHM
    qDebug() << QString::fromUtf8("<IHM::lireParametres()> lieu : %1").arg(lieu);
    qDebug() << QString::fromUtf8("<IHM::lireParametres()> période : %1").arg(periode);
    qDebug() << QString::fromUtf8("<IHM::lireParametres()> pgn : %1").arg(pgnWindData);
    qDebug() << QString::fromUtf8("<IHM::lireParametres()> pgn : %1").arg(pgnEnvironmentalParameters);
    #endif
}

void IHM::demarrer()
{
    timerStationMeteo->start();
    bDemarrer->setEnabled(false);
    bArreter->setEnabled(true);
}

void IHM::arreter()
{
    timerStationMeteo->stop();
    bDemarrer->setEnabled(true);
    bArreter->setEnabled(false);
}

void IHM::acquerir()
{
    stationMeteo->acquerir(pgnEnvironmentalParameters);
    message->insertPlainText("Température : " + QString::number(stationMeteo->getTemperature()) + " °C\n");
    thermoTemperature->setValue(stationMeteo->getTemperature());

    stationMeteo->acquerir(pgnWindData);
    message->insertPlainText("Direction : " + QString::number(stationMeteo->getDirectionVent()) + " °\n");
    compassDirectionVent->setValue(stationMeteo->getDirectionVent());
}

void IHM::majLieu()
{
    lieu = leLieu->text();
    stationMeteo->setLieu(lieu.toStdString());
}

void IHM::majPeriode()
{
    periode = lePeriode->text().toInt();
}
