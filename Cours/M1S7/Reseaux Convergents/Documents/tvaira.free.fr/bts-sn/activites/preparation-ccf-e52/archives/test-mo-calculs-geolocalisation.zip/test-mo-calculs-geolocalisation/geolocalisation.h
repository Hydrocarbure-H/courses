#ifndef GEOLOCALISATION_H
#define GEOLOCALISATION_H

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*  Latitude/longitude spherical geodesy formulae & scripts (c) Chris Veness 2002-2012            */
/*   - www.movable-type.co.uk/scripts/latlong.html                                                */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*  Sample usage:                                                                                 */
/*    double p1 = new Geolocalisation(51.5136, -0.0983);                                                      */
/*    double p2 = new Geolocalisation(51.4778, -0.0015);                                                      */
/*    double dist = p1.distanceTo(p2);          // in km                                             */
/*    double brng = p1.bearingTo(p2);           // in degrees clockwise from north                   */
/*    ... etc                                                                                     */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */

#define PI 3.14159265

class Geolocalisation
{
   private:
      double latitude;
      double longitude;
      double rayonTerre;

   public:
      Geolocalisation(double latitude, double longitude, double rayonTerre=6371);
      double distance(const Geolocalisation &point, int precision=4);
      double orientation(const Geolocalisation &point);
      double orientationFinale(const Geolocalisation &point);
      Geolocalisation* milieu(const Geolocalisation &point);
      Geolocalisation* destination(double brng, double dist);
      Geolocalisation* intersection(const Geolocalisation &p1, double brng1, const Geolocalisation &p2, double brng2); 
      double rhumbDistanceTo(const Geolocalisation &point); 
      double rhumbBearingTo(const Geolocalisation &point); 
      Geolocalisation* rhumbDestinationPoint(double brng, double dist); 
      Geolocalisation* rhumbMidpointTo(const Geolocalisation &point); 

      double getLatitude();
      string getLatitude(string format, int dp);
      double getLongitude();
      string getLongitude(string format, int dp);
      string toString(string format, int dp);
      string toString(double x, string format, int dp);
      string doubleToString(double n);
      
      double radians(double x);
      double degres(double x);
};

#endif
