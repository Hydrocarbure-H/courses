#include <stdio.h>
#include <stdlib.h> /* pour exit */
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h> /* pour memset */
#include <netinet/in.h> /* pour struct sockaddr_in */
#include <arpa/inet.h> /* pour htons et inet_aton */
#include <netdb.h> /* pour getnameinfo */

#define PORT IPPORT_USERRESERVED // = 5000

#define LG_MESSAGE   256

int main(int argc, char *argv[])
{
   int socketEcoute;
   struct sockaddr_in pointDeRencontreLocal;
   socklen_t longueurAdresse;
   int socketDialogue;
   struct sockaddr_in pointDeRencontreDistant;
   char messageEnvoi[LG_MESSAGE]; /* le message de la couche Application ! */  
   char messageRecu[LG_MESSAGE]; /* le message de la couche Application ! */  
   int ecrits, lus; /* nb d'octets ecrits et lus */
   int retour;
   char host[NI_MAXHOST], service[NI_MAXSERV];
   int finEntete = 0;

   // Crée un socket de communication 
   socketEcoute = socket(PF_INET, SOCK_STREAM, 0); /* 0 indique que l'on utilisera le protocole par défaut associé à SOCK_STREAM soit TCP */

   // Teste la valeur renvoyée par l'appel système socket()
   if(socketEcoute < 0) /* échec ? */
   {
      perror("socket"); // Affiche le message d'erreur
      exit(-1); // On sort en indiquant un code erreur
   } 

   printf("Socket créée avec succès ! (%d)\n", socketEcoute);

   // On prépare l'adresse d'attachement locale
   longueurAdresse = sizeof(struct sockaddr_in);
   memset(&pointDeRencontreLocal, 0x00, longueurAdresse);
   pointDeRencontreLocal.sin_family        = PF_INET;
   pointDeRencontreLocal.sin_addr.s_addr   = htonl(INADDR_ANY); // toutes les interfaces locales disponibles
   pointDeRencontreLocal.sin_port          = htons(PORT);   

   // On demande l'attachement local de la socket
   if((bind(socketEcoute, (struct sockaddr *)&pointDeRencontreLocal, longueurAdresse)) < 0)
   {
      perror("bind");
      exit(-2);
   }
   
   printf("Socket attachée avec succès !\n");

   // On fixe la taille de la file d'attente à 5 (pour les demande de connexion non encore traitées)
   if(listen(socketEcoute, 5) < 0)
   {
      perror("listen");
      exit(-3);
   }

   printf("Socket placée en écoute passive ...\n");
   
   // boucle d'attente de connexion : en théorie, un serveur attend indéfiniment !
   while(1)
   {
      memset(messageEnvoi, 0x00, LG_MESSAGE*sizeof(char));
      memset(messageRecu, 0x00, LG_MESSAGE*sizeof(char));   
      printf("Attente d'une demande de connexion (quitter avec Ctrl-C)\n\n");
      // c'est un appel bloquant
      socketDialogue = accept(socketEcoute, (struct sockaddr *)&pointDeRencontreDistant, &longueurAdresse);

      if (socketDialogue < 0)
      {
         perror("accept");
         close(socketDialogue);
         close(socketEcoute);
         exit(-4);
      }

      // Récupère les informations sur le client
      retour = getnameinfo((struct sockaddr *)&pointDeRencontreDistant, longueurAdresse, host, NI_MAXHOST, service, NI_MAXSERV, NI_NUMERICSERV);
      if (retour == 0)
         printf("Connexion client %s:%s\n", host, service);
      else
         fprintf(stderr, "getnameinfo: %s\n", gai_strerror(retour));

      /* Création du processus de dialogue */
      switch(fork())
      {
      case -1 :   perror("fork:"); exit(-7);
      case 0  :   /* processus fils */
                  /* le fils n'utilise pas la socket d'écoute */
                  close(socketEcoute);
                  
                  // Récupère les informations sur le client
                  retour = getnameinfo((struct sockaddr *)&pointDeRencontreDistant, longueurAdresse, host, NI_MAXHOST, service, NI_MAXSERV, NI_NUMERICSERV);
                  if (retour == 0)
                     printf("Connexion client %s:%s\n", host, service);
                  else
                     fprintf(stderr, "getnameinfo: %s\n", gai_strerror(retour));

                  // On réception les données du client (cf. protocole)
                  lus = read(socketDialogue, messageRecu, LG_MESSAGE*sizeof(char)); // ici appel bloquant
                  switch(lus)
                  {
                     case -1 : /* une erreur ! */
                        perror("read");
                        close(socketDialogue);
                        exit(-5);
                     case 0 : /* la socket est fermée */
                        fprintf(stderr, "La socket a été fermée par le client !\n\n"); 
                        close(socketDialogue);
                        return 0;
                     default: /* réception de n octets */
                        printf("Message reçu : %s (%d octets)\n\n", messageRecu, lus); 
                  }

                  // On envoie des données vers le client (cf. protocole)
                  sprintf(messageEnvoi, "ok\n");
                  ecrits = write(socketDialogue, messageEnvoi, strlen(messageEnvoi));
                  switch(ecrits)
                  {
                     case -1 : /* une erreur ! */
                        perror("write");
                        close(socketDialogue);
                        exit(-6);
                     case 0 : /* la socket est fermée */
                        fprintf(stderr, "La socket a été fermée par le client !\n\n"); 
                        close(socketDialogue);
                        return 0;
                     default: /* envoi de n octets */
                        printf("Message %s envoyé (%d octets)\n\n", messageEnvoi, ecrits); 
                  }

                  // On ferme la socket de dialogue et on se replace en attente ...
                  close(socketDialogue);
                 
                  /* à la fin du dialogue, on ferme la socket de dialogue */
                  close(socketDialogue); 
                  exit(0); /* fin du processus fils */
      default :   /* processus pere */
                  /* le pere n'utilise pas la socket de dialogue */
                  close(socketDialogue);
                  /* le pere se replace en attente des demandes de connexion */
      }
   }
   
   // On ferme la ressource avant de quitter   
   close(socketEcoute);

   return 0;
}
