#include "log.h"

Log* Log::_log = NULL;
int Log::nbAcces = 0;

Log* Log::getInstance()
{
    if(_log == NULL)
        _log = new Log();

    nbAcces++;

    return _log;
}

void Log::detruireInstance()
{
    // instance ?
    if(_log != NULL)
    {
        nbAcces--;
        // dernier ?
        if(nbAcces == 0)
            delete _log;
    }
}

Log::Log(QObject *parent) : QObject(parent)
{
    // Préparation du log
    QString fileLog = QCoreApplication::instance()->applicationDirPath() + "/" + QCoreApplication::instance()->applicationName() + ".log";

    log = new QFile(fileLog, this);
    log->open(QIODevice::WriteOnly);
    if(!log->isOpen())
    {
        qDebug() << "<Log::Log()> impossible d'ouvrir le fichier de log !";
    }
}

void Log::journaliser(const QString &message)
{
    QMutexLocker verrou(&mutex);

    if(log->isOpen())
    {
        QTextStream monLog(log);
        QDateTime maintenant = QDateTime::currentDateTime();
        QString dateEtHeureActuelle = maintenant.toString("dd/MM/yyyy hh:mm");

        // Autres :
        //qDebug() << qApp->applicationDirPath();
        //qDebug() << qApp->applicationFilePath();
        //qDebug() << qApp->applicationName();

        monLog << dateEtHeureActuelle << " " << qApp->applicationName() << " : " << message << endl;
    }
}
