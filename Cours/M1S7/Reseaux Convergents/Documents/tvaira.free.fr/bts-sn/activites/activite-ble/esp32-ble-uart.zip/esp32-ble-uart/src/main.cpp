/**
*
* @file src/main.cpp
* @brief Exemple Bluetooth BLE UART
* @author Thierry Vaira
* @version 0.1
*/

#include <Arduino.h>
//#include "BluetoothSerial.h"
#include <Wire.h>
#include <Preferences.h>
#include "ble_uart.h"

ServeurBLEUART serveurBLE;

/**
 * @brief Initialise les ressources
 *
 * @fn setup()
 */
void setup()
{
  Serial.begin(115200);
  while (!Serial);

  #ifdef DEBUG
  Serial.println(F("Bluetooth BLE UART"));
  #endif

  serveurBLE.initialiser();
  // ou :
  //initialiser("nom"); // nom = nom du périphérique bluetooth

  serveurBLE.demarrer();
}

/**
 * @brief Boucle principale
 *
 * @fn loop()
 */
void loop()
{
  String trame;

  // Si besoin, démarre l'advertising
  serveurBLE.diffuser(); // ou : serveurBLE.diffuser(1000); // 1000 ms délai entre chaque démarrage

  // Envoi une trame toutes les 5 secondes
  if(ServeurBLEUART::estEcheance(5000))
  {
      serveurBLE.envoyer("$groom;HELLO\r\n");
  }

  // Réception de trames si nécessaire
  serveurBLE.recevoir(trame);
  /**
   * @see estDisponible() et readStringUntil(char delimiteur)
   *
   */
}
