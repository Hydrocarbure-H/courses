#include <Poco/Net/HTTPClientSession.h>
#include <Poco/Net/HTTPRequest.h>
#include <Poco/Net/HTTPResponse.h>
#include <Poco/StreamCopier.h>
#include <Poco/Path.h>
#include <Poco/URI.h>
#include <Poco/Exception.h>

#include <iostream>
#include <iomanip>
#include <string>

#include <cv.h> // contient les déclarations des classes de manipulation d'images (libcv-dev)
#include <highgui.h> // contient déclarations des fonctions d'affichage des images (libhighgui-dev)

// codes touche
#define HAUT    0x52
#define BAS     0x54
#define GAUCHE  0x51
#define DROITE  0x53
#define QUIT    0x71

using namespace cv;

using namespace Poco::Net;
using namespace Poco;
using namespace std;

// sudo apt-get install libcv-dev
// sudo apt-get install libhighgui-dev
// sudo apt-get install libpoco-dev

// g++ -o test-poco-2 test-poco-2.cpp -lPocoNet -lPocoFoundation `pkg-config --cflags --libs opencv`

// http://www.appinf.com/docs/poco/Poco.html

void commander(URI &uri)
{
    HTTPClientSession session(uri.getHost(), uri.getPort());
    
    // prepare path
    string path(uri.getPathAndQuery());
    if (path.empty()) path = "/";

    // send request
    HTTPRequest req(HTTPRequest::HTTP_GET, path, HTTPMessage::HTTP_1_1);
    session.sendRequest(req);
    
    // get response
    HTTPResponse res;
    cout << res.getStatus() << " " << res.getReason() << endl;

    // print response
    istream &is = session.receiveResponse(res);
    StreamCopier::copyStream(is, cout);
}

int main(int argc, char **argv)
{  
    // Commandes de la caméra IP Wanscam 
    char haut[] = "http://192.168.52.14:99/decoder_control.cgi?command=0&onestep=1&user=admin&pwd="; 
    char bas[] = "http://192.168.52.14:99/decoder_control.cgi?command=2&onestep=1&user=admin&pwd="; 
    char droite[] = "http://192.168.52.14:99/decoder_control.cgi?command=6&onestep=1&user=admin&pwd="; 
    char gauche[] = "http://192.168.52.14:99/decoder_control.cgi?command=4&onestep=1&user=admin&pwd="; 
    bool fini = false;
    int touche;    
    URI uri;
    
    namedWindow("Wanscam", CV_WINDOW_AUTOSIZE);
    while(!fini)
    {            
    

        //touche = cv::waitKey(0);
        touche = cvWaitKey(100);
        if(touche != -1)
            printf("touche = 0x%02X\n", (unsigned char)touche);
        switch((unsigned char)touche)
        {
            case HAUT:
                printf("touche HAUT\n");
                uri = URI(haut);
                commander(uri);
                break;
            case BAS:
                printf("touche BAS\n");
                uri = URI(bas);
                commander(uri);
                break;
            case DROITE:
                printf("touche DROITE\n");
                uri = URI(droite);
                commander(uri);
                break;
            case GAUCHE:       
                printf("touche GAUCHE\n");
                uri = URI(gauche);
                commander(uri);
                break;
            case QUIT:
                printf("touche QUIT\n");
                fini = true;
                break;
        }
    }
    
    return 0;
}
