#ifndef _QTP_H
#define _QTP_H

#include <QtCore> 
#include <stdio.h> 
#include <errno.h> 
#include <termios.h> 
#include <stdlib.h>
#include <string.h> 
#include <unistd.h>
#include <sys/ioctl.h> 
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/signal.h>
#include <fcntl.h> 

//codes etat
#define QTP_READY		0x06
#define QTP_NOTREADY	0x15

//limites EEPROM
#define MAX_MESS_256		9
#define MAX_MESS_512		22
#define MAX_MESS_1024	47
#define MAX_MESS_2048	99
#define MAX_LENGTH		20

//codes cmds
#define NB_CMDS				21
#define LG_CMD					6
#define ABS						0
#define CLEAR_ENDOFLINE		1
#define CLEAR_ENDOFPAGE		2
#define CURSOR_OFF			3
#define CURSOR_ON				4
#define BLINK					5
#define REQUEST_READY		6
#define TEST_WRITE			7
#define TEST_READ				8
#define KEY_RECONFIG			9
#define KEYCLICK_ON			10
#define KEYCLICK_OFF			11
#define KEYCLICK_ON_SAVE	12
#define KEYCLICK_OFF_SAVE	13
#define READ_VERSION			14
#define READ_NUMBER			15
#define MESSAGE_STORING		16
#define MESSAGE_READING		17
#define MESSAGE_DISPLAY		18
#define MESSAGE_SCROLL		19
#define INPUTS_CONFIG		20
#define INPUTS_READING		21

//codes QTP
#define CURSOR_LEFT	0x15
#define CURSOR_RIGHT	0x06
#define CURSOR_DOWN	0x0A
#define CURSOR_UP		0x1A
#define CURSOR_HOME	0x01
#define CR				0x0D
#define LF				0x0A 
#define CRLF			0x1D
#define BS				0x08
#define CLEAR_PAGE	0x0C
#define CLEAR_LINE	0x19
#define BELL			0x07
#define BEEP			0x07
#define ESC				0x1B
#define ACK				0x06
#define NACK			0x15
#define TEST			0x55

//divers
#define ERROR	-1
#define VRAI	1
#define FAUX	0

#define LG_LIGNE	20  
#define NB_LIGNES	4

#define QTP_ECHO		1
#define QTP_NOECHO	0

//codes clavier
#define DIESE		0x0D
#define ETOILE		0x1B

//macro: récupérer le nombre d'octets d'une commande
#define NB_CHAR(x)	(cmds[x][LG_CMD-1])


class QTP
{
public:
	QTP(QString port = "/dev/ttyUSB0");
	~QTP();
    
    int afficher(char* message, int nbchar);
    char lireTouche(char *touche, int nbchar, int mode);
    
	void gotoxy(int ligne, int colonne);
	void clearEndofline();
	void clearEndofpage();
	void cursorOn();
	void cursorOff();
	void cursorBlink();

protected:	
	int send(char *cmd, int nbchar);
	int recv(char *mess, int nbchar);
	int requestReady();

private:
	int _qtpid;
};

#endif

