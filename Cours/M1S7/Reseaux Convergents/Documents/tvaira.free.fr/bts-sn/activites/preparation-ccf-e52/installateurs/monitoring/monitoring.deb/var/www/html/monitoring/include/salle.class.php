<?php
require_once ('./include/monitoring.inc.php');

class Salle
{
    private $idSalle;
    private $nom; 
    private $description; 
    private $ip; 
    private $port;     
    private $etat;
    private $trouve = false;
    private $bd = NULL;

    function __construct($nomSalle="")
    {
        UpdateLog("Classe ".get_class($this)." ".__FUNCTION__."(\"".$nomSalle."\")", $GLOBALS['config']['logfile']);
        if ($GLOBALS['config']['bd'] == "sqlite") 
            $this->bd = ouvrirBase();
        else if ($GLOBALS['config']['bd'] == "mysql") 
            $this->bd = connecterBase();
        $this->get($nomSalle);
    }
    
    function __destruct()
    {
        UpdateLog("Classe ".get_class($this)." ".__FUNCTION__."()", $GLOBALS['config']['logfile']);
        if ($GLOBALS['config']['bd'] == "sqlite") 
            fermerBase($this->bd);
        else if ($GLOBALS['config']['bd'] == "mysql") 
            deconnecterBase($this->bd);
    }

    public function getId()
    {
        return $this->idSalle;
    }

    public function setId($idSalle="")
    {
        if(!Empty($idSalle))
            $this->idSalle = $idSalle;
    }

    public function getNom()
    {
        return $this->nom;
    }

    public function setNom($nom="")
    {
        if(!Empty($nom))
            $this->nom = $nom;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function setDescription($description="")
    {
        if(!Empty($description))
            $this->description = $description;
    }

    public function getIp()
    {
        return $this->ip;
    }

    public function setIp($ip="")
    {
        if(!Empty($ip))
            $this->ip = $ip;
    }

    public function getPort()
    {
        return $this->port;
    }

    public function setPort($port="")
    {
        if(!Empty($port))
            $this->port = $port;
    }

    public function getEtat()
    {
        return $this->etat;
    }

    public function setEtat($etat="")
    {
        if($etat === "on")
        {
            $this->etat = 1;
        }
        else if($etat === "off")
        {
            $this->etat = 0;
        }
        else if($etat === "1")
        {
            $this->etat = 1;
        }
        else if($etat === "0")
        {
            $this->etat = 0;
        }
        else if($etat === 1)
        {
            $this->etat = 1;
        }
        else if($etat === 0)
        {
            $this->etat = 0;
        }
        else
        {
            debug($etat);
        }
    }
    
    public function getTrouve()
    {
        return $this->trouve;
    }

    public function get($nomSalle="")
    {
        if(!Empty($nomSalle))
        {
            UpdateLog("Classe ".get_class($this)." ".__FUNCTION__."(\"".$nomSalle."\")", $GLOBALS['config']['logfile']);            
            if($this->bd != NULL)
            {
                $requete = "SELECT salles.* FROM salles WHERE nom = '".$nomSalle."'";
                UpdateLog("Requête SQL : " .$requete, $GLOBALS['config']['logfile']);
                $result = $this->bd->query($requete);
                if ($result)
                {                
                    if ($GLOBALS['config']['bd'] == "sqlite") 
                    {
                        $salle = fetch_object($result);
                    }
                    else if ($GLOBALS['config']['bd'] == "mysql") 
                    {
                        $salle = $result->fetch_object();
                    }                    
                    if($salle != NULL)
                    {
                        $this->setId($salle->idSalle);
                        $this->nom = $salle->nom; 
                        $this->description = $salle->description;                      
                        $this->ip = $salle->ip;  
                        $this->port = $salle->port;                      
                        $this->setEtat($salle->etat);
                        $this->trouve = true;
                    }                
                    if ($GLOBALS['config']['bd'] == "mysql") 
                        $result->free();
                    return $salle;
                }
                else
                {
                    UpdateLog("Erreur SQL -> " .$requete, $GLOBALS['config']['logfile']);
                    //debug($requete);
                    if ($GLOBALS['config']['bd'] == "mysql")     
                        debug($this->bd->error);
                }            
            }
            else
            {
                UpdateLog("Recherche : " .$nomSalle, $GLOBALS['config']['logfile']);
                for($j=0;$j<count($GLOBALS['config']['salles']);$j++) 
                {
                    $s = $GLOBALS['config']['salles'][$j];
                    if($s['nom'] == $nomSalle)
                    {
                        $salle = new stdClass();
                        $salle->idSalle = $s['idSalle'];
                        $salle->nom = $s['nom']; 
                        $salle->description = $s['description'];
                        $salle->ip = $s['ip'];
                        $salle->port = $s['port'];
                        $salle->etat = $s['etat'];
                        $this->trouve = true;
                        break;
                    }                        
                }
                if($salle != NULL)
                {
                    $this->setId($salle->idSalle);
                    $this->nom = $salle->nom; 
                    $this->description = $salle->description;                      
                    $this->ip = $salle->ip;  
                    $this->port = $salle->port;                      
                    $this->setEtat($salle->etat);
                    $this->trouve = true;
                }                
                if ($GLOBALS['config']['bd'] == "mysql") 
                    $result->free();
                return $salle;
            }
        }
        return NULL;
    }

    public function set($datas)
    {
        if(is_array($datas))
        {
            $this->setNom($datas["nom"]);
            $this->setDescription($datas["description"]);
            $this->setIp($datas["ip"]);
            $this->setPort($datas["port"]);
            if(IsSet($datas["etat"]))
                $this->setEtat($datas["etat"]);
            else
                $this->setEtat(0);
        }
    }
    
    public function inserer()
    {
        $requete = "INSERT INTO `salles` (`nom`, `description`, `ip`, `port`, `etat`) VALUES ('".$this->nom."', '".$this->description."', '".$this->ip."', '', '".$this->port."', '".$this->etat."')";
        if (!$result = $this->bd->query($requete))
        {                
            debug($requete);
            if ($GLOBALS['config']['bd'] == "mysql")     
                debug($this->bd->error);
            return FALSE;
        }
        else
        {
            return TRUE;
        }        
    }
    
    public function modifier($idSalle="")
    {
        $this->setId($idSalle);
        
        if(!Empty($this->idSalle))    
        {
            $requete = "UPDATE salles SET `nom` = '".$this->nom."', `description` = '".$this->description."', `ip` = '".$this->ip."', `port` = '".$this->port."', `etat` = '".$this->etat."' WHERE `salles`.`idSalle` = '".$this->idSalle."'";
            if (!$result = $this->bd->query($requete))
            {
                debug($requete);
                if ($GLOBALS['config']['bd'] == "mysql")     
                    debug($this->bd->error);
                return FALSE;
            }
        }
        return TRUE;
    }
    
    public function supprimer($idSalle="")
    {
        $this->setId($idSalle);
        
        if(!Empty($this->idSalle))    
        {
            $requete = "DELETE FROM `salles` WHERE `salles`.`idSalle` = '".$this->idSalle."'";
            if (!$result = $this->bd->query($requete))
            {
                debug($requete);
                if ($GLOBALS['config']['bd'] == "mysql")     
                    debug($this->bd->error);
                return FALSE;
            }                
            else
            {
                debug($requete);
                if ($GLOBALS['config']['bd'] == "mysql")
                    debug($this->bd->error);
                return FALSE;
            }
        }
        return TRUE;
    }

    public function activer($idSalle="")
    {
        $this->setId($idSalle);
        
        if(!Empty($this->idSalle))    
        {
            if($this->getEtat())
                $etat = 0;
            else
                $etat = 1;
            $requete = "UPDATE salles SET `etat` = '".$etat."' WHERE `salles`.`idSalle` = '".$this->idSalle."'";
            debug($requete);
            if (!$result = $this->bd->query($requete))
            {
                debug($requete);
                if ($GLOBALS['config']['bd'] == "mysql")     
                    debug($this->bd->error);
                return FALSE;
            }
        }
        return TRUE;
    }
    
    public function getListe()
    {
        UpdateLog("Classe ".get_class($this)." ".__FUNCTION__."()", $GLOBALS['config']['logfile']);
        // Récupère la liste des salles connues
        $requete = "SELECT salles.* FROM salles ORDER BY nom ASC";
        UpdateLog("Requête SQL -> " .$requete, $GLOBALS['config']['logfile']);
        if ($result = $this->bd->query($requete))
        {                         
           $i = 0;
           if ($GLOBALS['config']['bd'] == "sqlite") 
           {
               while($salle = fetch_object($result)) 
               {
                   $liste[$i++] = $salle;
               }
           } 
           else if ($GLOBALS['config']['bd'] == "mysql") 
           {
               while($salle = $result->fetch_object()) 
               {
                   $liste[$i++] = $salle;
               }
               $result->free();
           }
           else
           {
                for($j=0;$j<count($GLOBALS['config']['salles']);$j++) 
                {
                    $salle = $GLOBALS['config']['salles'][$j];
                    $liste[$i++] = $salle;
                }
           }
        }
        else
        {
            UpdateLog("Erreur SQL -> " .$requete, $GLOBALS['config']['logfile']);
            //debug($requete);
            if ($GLOBALS['config']['bd'] == "mysql")     
                debug($this->bd->error);
        }
        return $liste;
    }
}

?>
