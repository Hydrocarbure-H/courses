// Répartiteur/Travailleurs

//#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <string.h>

//#define GUI

#ifdef GUI
typedef enum { NOIR, ROUGE, VERT, MARRON, BLEU, FUSHIA, CYAN, GRIS } Couleur;
typedef enum { NORMAL, SOFTEN, NORMAL1, NORMAL2, SOULIGNE, BLINK, NORMAL3, INVERT } Mode;

#define RESET_TERM()                printf("\x1b[0m")
#define SET_BGCOLOR(color)          printf("\x1b[1;37;4%dm",color)
#define SET_COLOR(color) 	        printf("\x1b[0;3%dm",color)
#define SET_MODECOLOR(mode,color)	printf("\x1b[%d;3%dm",mode,color)
#define SETCOLOR_SUCCESS()          printf("\x1b[1;32m")
#define SETCOLOR_FAILURE()          printf("\x1b[5;31m")
#define SETCOLOR_ERROR()            printf("\x1b[1;31m")
#define SETCOLOR_WARNING()          printf("\x1b[1;34m")
#define SETCOLOR_INFO()             printf("\x1b[0;37m")
#define SETCOLOR_NORMAL()           printf("\x1b[0;39m")
#define MOVE_TO_COL(col)	        printf("\x1B[%dG", col)
#define MOVE_XY(x,y)			    printf("\x1B[%d;%dH",x,y)
#define CLEAR_LINE(x,y)			    printf("\x1B[%d;%dH\x1b[2K",x,y)
#define RESET()					    printf("\x1B[2J")

#define LIGNE_SIMULATEUR            3
#define LIGNE_REPARTITEUR           7
#define LIGNE_TRAVAILLEUR           13
#define COLONNE_MOTIF               36
#endif

// taille de la file pour les requêtes
#define TAILLE_MAX 10

// nombre de requêtes à effectuer par le simulateur
#define NB_REQUETES 50

// nombre de threads max
#define NB_THREADS_TRAVAILLEURS 5

// Requête
typedef struct
{
    char motif;
    int nb;
    int numeroTravailleur;
} Requete;

// Thread simulateur de requêtes
void *simulateur(void *);

// Thread répartiteur
void *repartiteur(void *);

// Thread travailleur
void *travailleur(void *);

Requete requetes[TAILLE_MAX]; // la file où seront déposées les requêtes
int in = 0; // indique le premier emplacement de libre pour déposer une requête
int out = 0; // indique l'emplacement de la prochaine requête à retirer
pthread_t tidTravailleurs[NB_THREADS_TRAVAILLEURS];

// Ressources de synchronisation


int main(void) 
{
    pthread_t tidSimulateur;
    pthread_t tidRepartiteur;
    int nbRequetes = NB_REQUETES;

    setbuf(stdout, NULL);

    #ifdef GUI
    RESET();
    RESET_TERM();
    MOVE_XY(0,0);
    #endif
    printf("Répartiteur/Travailleurs : %d requêtes à traiter avec %d thread(s) travailleur(s)", nbRequetes, NB_THREADS_TRAVAILLEURS);


    pthread_create(&tidRepartiteur, NULL, repartiteur, (void *)&nbRequetes);
    pthread_create(&tidSimulateur, NULL, simulateur, (void *)&nbRequetes);
    
    pthread_join(tidSimulateur, NULL);
    pthread_join(tidRepartiteur, NULL);

    #ifdef GUI
    CLEAR_LINE(LIGNE_SIMULATEUR, 2);
    RESET_TERM();
    MOVE_XY(1,0);
    #endif
    printf("\nTerminé\n");

    return 0;
}

void *simulateur(void *nbRequetes)
{
    Requete requete;
    int nb = *((int *)nbRequetes);

    srand(time(NULL));
    for(int i=0;i<nb;)
    {   
        // pas plein ?
        if ((in + 1) % TAILLE_MAX != out)
        {
            // fabrique une nouvelle requete
            requete.motif = '!' + rand() % 15; // entre '!' et '/'
            requete.nb = 10 + rand() % 51; // entre 10 et 60


        
            // place la requête dans la file
            requetes[in] = requete;

            // signale la requête



            #ifdef GUI
            printf("\x1B[%d;%dH>>> Nouvelle requête  : %d x '%c' (%02d/%02d)  [%02d/%02d]", LIGNE_SIMULATEUR, 2, requete.nb, requete.motif, i+1, nb, in, out);
            #else
            printf(">>> Nouvelle requête  : %d x '%c' (%02d/%02d)  [%02d/%02d]\n", requete.nb, requete.motif, i+1, nb, in, out);
            #endif
            in = (in + 1) % TAILLE_MAX;
            i++;
        }

        // simule une attente avant l'arrivée d'une nouvelle requête
        if((i % 8) == 0)
            usleep(100000);
    }

    #ifdef GUI
    CLEAR_LINE(LIGNE_SIMULATEUR, 2);
    printf("\x1B[%d;%dH>>> Fin simulateur", LIGNE_SIMULATEUR, 2);
    #else
    printf("Fin simulateur\n");
    #endif
    pthread_exit(NULL);
    return NULL;
}

void afficherNbRequetesRestantes()
{
    int restantes = 0;
    if(out > in)
        restantes = (TAILLE_MAX - out) + in;
    else
        restantes = in - out;
    #ifdef GUI
    printf("\x1B[%d;%dH=== Nb de requêtes à traiter : %d", LIGNE_REPARTITEUR-2, 2, restantes);
    MOVE_XY(LIGNE_TRAVAILLEUR+NB_THREADS_TRAVAILLEURS+1,0);
    #endif
}

void attendreTravailleurs()
{
    for(int j=0;j<NB_THREADS_TRAVAILLEURS;j++)
    {
        if(tidTravailleurs[j] != 0)
        {            
            if(pthread_tryjoin_np(tidTravailleurs[j], NULL) == 0)
            {
                tidTravailleurs[j] = 0;
                #ifdef GUI
                CLEAR_LINE(LIGNE_REPARTITEUR+j, 2);
                #endif
            }
        }
    }
}

void *repartiteur(void *nbRequetes)
{    
    Requete *requete;
    int nb = *((int *)nbRequetes);
    int restantes = 0;

    for(int i=0;i<nb;)
    {
        

        
    }

    #ifdef GUI
    CLEAR_LINE(5, 2);
    for(int j=0;j<NB_THREADS_TRAVAILLEURS;j++)
    {
        if(tidTravailleurs[j] != 0)
            pthread_join(tidTravailleurs[j], NULL);
        CLEAR_LINE(LIGNE_REPARTITEUR+j, 2);
    }
    #endif
    
    pthread_exit(NULL);
    return NULL;
}

void *travailleur(void *requete)
{
    Requete *r = (Requete *)requete;

    #ifdef GUI
    printf("\x1B[%d;%dHThread travailleur %d : %d x '%c' -> ", LIGNE_TRAVAILLEUR+r->numeroTravailleur, 2, r->numeroTravailleur, r->nb, r->motif);
    #endif
    for(int i=1;i<=r->nb;i++)
    {
        #ifdef GUI
        printf("\x1B[%d;%dH%c", LIGNE_TRAVAILLEUR+r->numeroTravailleur, COLONNE_MOTIF+i, r->motif);
        usleep(50000);
        #else
        write(1, &(r->motif), 1);
        #endif
    }

    #ifdef GUI
    CLEAR_LINE(LIGNE_TRAVAILLEUR+r->numeroTravailleur, 2);
    #endif
    
    free(requete);
    pthread_exit(NULL);
    return NULL;
}
