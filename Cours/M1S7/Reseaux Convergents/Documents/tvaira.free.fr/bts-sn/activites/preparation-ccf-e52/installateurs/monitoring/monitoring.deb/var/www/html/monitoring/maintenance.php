<?php
require_once ('./include/monitoring.inc.php');
require_once ('./include/salle.class.php');
UpdateLog("Maintenance", $config['logfile']);

$base = NULL;
if ($GLOBALS['config']['bd'] == "sqlite") 
    $base = ouvrirBase();
else if ($GLOBALS['config']['bd'] == "mysql")
    $base = connecterBase();

$salles = array();

if($base != NULL)
{            
    $requete = "SELECT salles.* FROM salles ORDER BY `nom` ASC";

    //debug($requete);
    UpdateLog("Requête SQL -> ".$requete, $GLOBALS['config']['logfile']);
    // Récupère la liste des salles connues
    if ($result = $base->query($requete))
    {                         
       $i = 0;
       if ($GLOBALS['config']['bd'] == "sqlite") 
       {
           while($salle = fetch_object($result)) 
           {
               $uneSalle["value"] = $salle->nom;
               $uneSalle["adresse"] = $salle->ip;
               $uneSalle["desc"] = "<p>Salle ".$salle->nom." ($salle->ip)</p>";
               $salles[$i++] = $uneSalle;
           }
       } 
       else if ($GLOBALS['config']['bd'] == "mysql")
       {
           while($salle = $result->fetch_object()) 
           {
               $uneSalle["value"] = $salle->nom;
               $uneSalle["adresse"] = $salle->ip;
               $uneSalle["desc"] = "<p>Salle ".$salle->nom." ($salle->ip)</p>";
               $salles[$i++] = $uneSalle;
           }
           $result->free();
       }        
    }
    else
    {
        UpdateLog("Erreur requête SQL ! ".$requete, $GLOBALS['config']['logfile']);
        //debug($requete);
        if ($GLOBALS['config']['bd'] == "mysql")     
            debug($base->error);
    }
    if ($GLOBALS['config']['bd'] == "sqlite") 
        fermerBase($base);
    else if ($GLOBALS['config']['bd'] == "mysql")
        deconnecterBase($base);    
}
else
{
    $i = 0;
    for($j=0;$j<count($GLOBALS['config']['salles']);$j++) 
    {
        $salle = $GLOBALS['config']['salles'][$j];
		$uneSalle["value"] = $salle['nom'];
		$uneSalle["adresse"] = $salle['ip'];
        $uneSalle["port"] = $salle['port'];
		$uneSalle["desc"] = "<p>Salle ".$salle['nom']." (".$salle['ip'].")</p>";
		$salles[$i++] = $uneSalle;
    }
}

?>
<!DOCTYPE html>
<html lang="fr-FR">
 <head>
  <meta charset="<?= $config['charset'] ?>">  
  <title><?= $config['description'] ?></title>
  <link href="jquery-ui/jquery-ui.css" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link href="include/app.min.css" rel="stylesheet">
  <link href="include/industrial.css" rel="stylesheet">
  <link href="include/monitoring.css" rel="stylesheet">
 </head>
 <body>

    <div class="ui-widget">        
        <h1>Maintenance</h1>
    </div>    
    <div id="busy" style="float: right; margin-right: 50px;"></div>
    <div class="ui-widget" style="font-size: 120%;">
<?php
if(count($salles) > 0)
{
    if(count($salles) == 1)
        echo "<p>Il y a une salle : </p>";
    else
        echo "<p>Il y a ".count($salles)." salles : </p>";
}
else
{
    echo "<p>Aucune salle disponible !</p>";
}
?>
        
<?php
for($i=0;$i<count($salles);$i++) 
{	
	if(!Empty($salles[$i]["value"]))
	{
		$salle = new Salle($salles[$i]["value"]);    
		if(!Empty($salle->getIp()) && !Empty($salle->getNom()))
		{
			$description = "Test salle : " . $salle->getNom() . " [".$salle->getIp().":".$salle->getPort()."]";    
			UpdateLog($description, $GLOBALS['config']['logfile']);
            echo "<p>&nbsp;&nbsp;&nbsp;&bull;&nbsp;Salle n°".($i+1)." : ".$salles[$i]["value"]." &rarr; ".$salles[$i]["adresse"].":".$salles[$i]["port"];
            echo "&nbsp;&nbsp;&nbsp;<button class=\"ping\" id=\"".$salles[$i]["value"]."\">ping</button>";
            echo "&nbsp;&nbsp;&nbsp;<button class=\"recv\" id=\"".$salles[$i]["value"]."\">réception</button></p>";
            //echo "<div id=\"busy\"></div>";
            echo "<div id=\"resultats_".$salles[$i]["value"]."\"><p>&nbsp;</p></div>";
		}
	}
}
?>        
    </div>
    
    <div>&nbsp;</div>
    <div><a href="index.php"><?= $config['description'] ?></a></div>
    <div>&nbsp;</div>
    <p id="footer"><span><?= $config['signature'] ?></span></p>    
    <script src="jquery-ui/external/jquery/jquery.js"></script>
    <script src="jquery-ui/jquery-ui.min.js"></script>
    <script src="js/app.min.js"></script>
    <script>        
        $(function() {
            $( "button" ).button();
            $( document ).ajaxStart(function() {
                $("#busy").busyLoad("show", {fontawesome: "fa fa-spinner fa-spin fa-3x fa-fw" });
            }).ajaxStop(function() {
                $("#busy").busyLoad("hide", {fontawesome: "fa fa-spinner fa-spin fa-3x fa-fw" });
            });
            $( ".ping" ).click( function( event ) {
              event.preventDefault();
              var nomSalle = $(this).attr('id');
              var id = "#resultats_" + nomSalle;
              $(id).html("<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;...</p>");
              //console.log("click ping " + nomSalle);
              $.ajax({
                        type: "GET",
                        url: "test.php",
                        //data: $("#idForm").serialize(),
                        data: "nom=" + nomSalle + "&action=ping",
                        //dataType : 'html',
                        dataType : 'json',
                        success: function(data)
                        {
                            //$donnees["ok"] = false;
                            //$donnees["message"] = "";                            
                            console.log(data);
                            //console.log("id : " + id);
							var date = new Date();
							var hours = "0" + date.getHours();
							var minutes = "0" + date.getMinutes();
							var seconds = "0" + date.getSeconds();
							var formattedTime = hours.substr(-2) + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
                            if(!data["ok"])
                            {
                                console.log("message : " + data["message"]);
                                $(id).html("<p style='color:red;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[" + formattedTime + "] " + data["message"] + "</p>");
                            }
                            else
                            {
                                $(id).html("<p style='color:green;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[" + formattedTime + "] ping : ok</p>");
                            }
                            $(id).show();
                        },
                        error: function() {
                            console.log('Erreur ajax');
                            $(id).html("<p style='color:red;'>Impossible de communiquer avec la salle " + nomSalle + "</p>");
                            $(id).show();
                        }
                    });
            });
            $( ".recv" ).click( function( event ) {
              event.preventDefault();
              var nomSalle = $(this).attr('id');
              console.log("click recv " + nomSalle);
              var id = "#resultats_" + nomSalle;
              $(id).html("<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;...</p>");
              //console.log("click ping " + nomSalle);
              $.ajax({
                        type: "GET",
                        url: "test.php",
                        //data: $("#idForm").serialize(),
                        data: "nom=" + nomSalle + "&action=recv",
                        //dataType : 'html',
                        dataType : 'json',
                        success: function(data)
                        {
                            //$donnees["ok"] = false;
                            //$donnees["message"] = "";                            
                            console.log(data);
                            //console.log("id : " + id);
                            var date = new Date();
							var hours = "0" + date.getHours();
							var minutes = "0" + date.getMinutes();
							var seconds = "0" + date.getSeconds();
							var formattedTime = hours.substr(-2) + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
                            if(!data["ok"])
                            {
                                console.log("message : " + data["message"]);
                                $(id).html("<p style='color:red;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[" + formattedTime + "] " + data["message"] + "</p>");
                            }
                            else
                            {
                                $(id).html("<p style='color:green;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[" + formattedTime + "] réception : " + data["message"] + "</p>");
                            }
                            $(id).show();
                        },
                        error: function() {
                            console.log('Erreur ajax');
                            $(id).html("<p style='color:red;'>Impossible de communiquer avec la salle " + nomSalle + "</p>");
                            $(id).show();
                        }
                    });
            });
        });
    </script>
 </body>
</html>
