#include "camera.h"

Camera::Camera(std::string adresseIP/*=ADRESSE_DEFAUT*/, int port/*=PORT_DEFAUT*/, std::string utilisateur/*=UTILISATEUR_DEFAUT*/, std::string motDePasse/*=PASSWORD_DEFAUT*/)
{
    numeroPhoto         = 0;
    this->adresseIP     = adresseIP;
    this->port          = port;
    this->utilisateur   = utilisateur;
    this->motDePasse    = motDePasse;
    scriptCGIVideo      = CGI_VIDEO;
    scriptCGIPhoto      = CGI_PHOTO;
    resolution          = RESOLUTION_DEFAUT;
    rate                = 0;
    init                = false;
    fenetre             = "Wanscam";

    this->url = "http://" + adresseIP + ":" + Camera::IntToString(port) + "/" + scriptCGIVideo + "?user=" + utilisateur + "&pwd=" + motDePasse + "&resolution=" + Camera::IntToString(resolution) + "&rate=" + Camera::IntToString(rate) + "&.mjpg";
    
    #ifdef DEBUG
    cout << "<debug> url : " << url << endl;
    #endif    
}

Camera::Camera(const char *adresseIP, int port/*=PORT_DEFAUT*/, std::string utilisateur/*=UTILISATEUR_DEFAUT*/, std::string motDePasse/*=PASSWORD_DEFAUT*/)
{
    numeroPhoto         = 0;
    this->adresseIP     = string(adresseIP);
    this->port          = port;
    this->utilisateur   = utilisateur;
    this->motDePasse    = motDePasse;
    scriptCGIVideo      = CGI_VIDEO;
    scriptCGIPhoto      = CGI_PHOTO;
    resolution          = RESOLUTION_DEFAUT;
    rate                = 0;
    init                = false;
    fenetre             = "Wanscam";

    this->url = "http://" + this->adresseIP + ":" + Camera::IntToString(port) + "/" + scriptCGIVideo + "?user=" + utilisateur + "&pwd=" + motDePasse + "&resolution=" + Camera::IntToString(resolution) + "&rate=" + Camera::IntToString(rate) + "&.mjpg";
    
    #ifdef DEBUG
    cout << "<debug> url : " << url << endl;
    #endif    
}

Camera::~Camera()
{
}

bool Camera::initialiser()
{
    // TODO
    
    namedWindow(fenetre, CV_WINDOW_AUTOSIZE);
    
    return init;
}

bool Camera::acquerir()
{   
    bool succes = false;
    
    // TODO
    
    return succes;
}

void Camera::capturer()
{
    // TODO
}

void Camera::afficher()
{
    // TODO
}

void Camera::demarrer()
{
    bool fini = false;
    
    initialiser();
    
    while(!fini)
    {            
        if(acquerir())
        {
            afficher();
        }       
    
        fini = gererActions();
    }
}

bool Camera::gererActions() 
{
    int touche;
    bool fini = false;
    
    touche = cv::waitKey(TIMEOUT_CLAVIER);
    #ifdef DEBUG
    if(touche != -1)
        printf("touche = 0x%02X\n", (unsigned char)touche);
    #endif
    switch((unsigned char)touche)
    {
        case ESPACE:
            #ifdef DEBUG
            printf("touche ESPACE\n");
            #endif
            // TODO
            break;
        case HAUT:
            #ifdef DEBUG
            printf("touche HAUT\n");
            #endif
            // TODO
            break;
        case BAS:
            #ifdef DEBUG
            printf("touche BAS\n");
            #endif
            // TODO
            break;
        case DROITE:
            #ifdef DEBUG
            printf("touche DROITE\n");
            #endif
            // TODO
            break;
        case GAUCHE:    
            #ifdef DEBUG
            printf("touche GAUCHE\n");
            #endif
            // TODO
            break;
        case QUIT:
            #ifdef DEBUG
            printf("touche QUIT\n");
            #endif
            fini = true;
            break;
    }
    
    return fini;
}

void Camera::orienter(URI &uri)
{
    // TODO
}

std::string Camera::IntToString(int n)
{
   std::ostringstream oss;
   oss << n;
   return oss.str();
}

std::string Camera::IntToString(int n, int base)
{
   std::ostringstream oss;
   if(base == 8)  oss << oct << n;
   else if (base == 10) oss << dec << n;
   else if (base == 16) oss << hex << n;
   return oss.str();
}

int Camera::StringToInt(string str)
{
   int n;
   std::istringstream iss(str);
   iss >> n;
   return n;
}

std::string Camera::FloatToString(float n)
{
   std::ostringstream oss;
   oss << n;
   return oss.str();
}

float Camera::StringToFloat(const std::string str)
{
   float n;
   std::istringstream iss(str);
   iss >> n;
   return n;
}

std::string Camera::DoubleToString(double n)
{
   std::ostringstream oss;
   oss << n;
   return oss.str();
}

double Camera::StringToDouble(const std::string str)
{
   double n;
   std::istringstream iss(str);
   iss >> n;
   return n;
}
