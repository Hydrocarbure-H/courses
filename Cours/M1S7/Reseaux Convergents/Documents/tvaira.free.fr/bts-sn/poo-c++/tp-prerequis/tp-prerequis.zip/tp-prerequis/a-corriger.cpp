/Qu'est censé faire ce programme ?

// auteur : e. remy

include <iostrem>

using namespace std;

integer main()
{
 /* Vous devez corriger ce programme et arriver à le compiler puis l'exécuter.
 cout << 'Le programme marche !' << end;
 int valeur = 10
 cout << "valeur =" << valeur << end;
 // Attention : la division de deux entiers est une division euclidienne,
 // c'est-à-dire une division ***ENTIERE*** !
 int quotient = 10 / 3
 cout << "quotient=" << quotient << end;
 int reste = 10 % 3
 cout << "reste=" << reste << end;
 // Si vous voulez faire une division réelle, il faut convertir un des
 // arguments en réel :
 out << "quotient reel =" << valeur / 3.0 <<end; // Cette fois-ci 3.0 est réel
 out << "Fin du programme;
 return 0;
}

