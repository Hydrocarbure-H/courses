#include <cppunit/config/SourcePrefix.h>

#include "TestUnitaireISBN.h"
#include "isbn.h" // Classe � tester

// Enregistrement des diff�rents cas de tests
CPPUNIT_TEST_SUITE_REGISTRATION( TestUnitaireISBN );

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

TestUnitaireISBN::TestUnitaireISBN()
{

}

TestUnitaireISBN::~TestUnitaireISBN()
{

}

void TestUnitaireISBN::setUp() 
{
   // Initialisation pour les tests
   isbn = new ISBN;   
}

void TestUnitaireISBN::tearDown() 
{
   delete isbn;
}

void TestUnitaireISBN::testEstValideISBN10()
{
	// Initialisation du test   

   // V�rification des r�sultats attendus
   // Classes valides :
   // Ici on peut prendre un �chantillon pour chaque cl� de contr�le possible
   CPPUNIT_ASSERT_EQUAL( true, isbn->estValide("9-604-25059-0") );
   CPPUNIT_ASSERT_EQUAL( true, isbn->estValide("2-100-03781-1") );
   CPPUNIT_ASSERT_EQUAL( true, isbn->estValide("2-123-45680-2") );
   CPPUNIT_ASSERT_EQUAL( true, isbn->estValide("1-932-69818-3") );
   CPPUNIT_ASSERT_EQUAL( true, isbn->estValide("2-702-13411-4") );
   CPPUNIT_ASSERT_EQUAL( true, isbn->estValide("0-684-84328-5") );
   CPPUNIT_ASSERT_EQUAL( true, isbn->estValide("2-266-11156-6") );
   CPPUNIT_ASSERT_EQUAL( true, isbn->estValide("1-402-89462-7") );
   CPPUNIT_ASSERT_EQUAL( true, isbn->estValide("2-212-08774-8") );
   CPPUNIT_ASSERT_EQUAL( true, isbn->estValide("2-765-40912-9") );
   // Et sans les tirets :
   CPPUNIT_ASSERT_EQUAL( true, isbn->estValide("2266111566") );  
   
   // Classes invalides :
   CPPUNIT_ASSERT_EQUAL( false, isbn->estValide("2-266-11156-5") ); // mauvaise code de controle
   CPPUNIT_ASSERT_EQUAL( false, isbn->estValide("206-11156-6") ); // mauvaise longueur
   CPPUNIT_ASSERT_EQUAL( false, isbn->estValide("2-XXX-11156-6") ); // mauvais codes 
   CPPUNIT_ASSERT_EQUAL( false, isbn->estValide("") ); // code vide
      
   // Technique d�taill�e :
   bool resultatObtenu;
   bool resultatAttendu = true;   
   
   // Appel m�thode test�e (lancement)
   resultatObtenu = isbn->estValide("2-266-11156-6");
   
   // V�rification des r�sultats attendus
   CPPUNIT_ASSERT_MESSAGE( "classe valide : code ISBN-10 valide", resultatObtenu == resultatAttendu);
   // ou : CPPUNIT_ASSERT_EQUAL_MESSAGE(message, expected, actual);
   CPPUNIT_ASSERT_EQUAL( resultatAttendu, isbn->estValide("2-266-11156-6") ); 
   // ou :
   //CPPUNIT_ASSERT( isbn->estValide("2-266-11156-6") == resultatAttendu );
   // etc ...
}

void TestUnitaireISBN::testEstValideISBN13()
{
   // Initialisation du test   

   // V�rification des r�sultats attendus
   // Classe valide :
   CPPUNIT_ASSERT_EQUAL( true, isbn->estValide("978-2-86889-006-1") );
   // etc ...
   
   // Classes invalides :
   CPPUNIT_ASSERT_EQUAL( false, isbn->estValide("978-2-86889-006-5") ); // mauvaise code de controle
   CPPUNIT_ASSERT_EQUAL( false, isbn->estValide("78-2-86889-006-1") ); // mauvaise longueur
   CPPUNIT_ASSERT_EQUAL( false, isbn->estValide("978-2-86889-AAA-1") ); // mauvais codes 
   CPPUNIT_ASSERT_EQUAL( false, isbn->estValide("908-2-86889-006-1") ); // mauvais identifiants attribu�s aux livres dans la codification EAN
   CPPUNIT_ASSERT_EQUAL( false, isbn->estValide("") ); // code vide
}

void TestUnitaireISBN::testSetterISBN10()
{
	// Classe valide :
   isbn->setISBN("2-266-11156-6");
   CPPUNIT_ASSERT( isbn->getISBN() == "2-266-11156-6" );
   // etc ...
   
   // Classes invalides :
   isbn->setISBN("2-266-11156-5"); // mauvaise code de controle
   CPPUNIT_ASSERT( isbn->getISBN() == "" ); 
   isbn->setISBN("206-11156-6"); // mauvaise longueur
   CPPUNIT_ASSERT( isbn->getISBN() == "" ); 
   isbn->setISBN("2-XXX-11156-6"); // mauvais codes 
   CPPUNIT_ASSERT( isbn->getISBN() == "" ); 
   isbn->setISBN(""); // code vide
   CPPUNIT_ASSERT( isbn->getISBN() == "" ); 
}

void TestUnitaireISBN::testSetterISBN13()
{
	// TODO
   CPPUNIT_FAIL( "TODO" );
}

void TestUnitaireISBN::testNettoieISBN()
{
   std::string codeISBN;
   
	// Classe valide 1 : un code ISBN-10
   codeISBN = isbn->nettoie("2-266-11156-6");
   CPPUNIT_ASSERT( codeISBN == "2266111566" );
   // Classe valide 2 : un code ISBN-13
   codeISBN = isbn->nettoie("978-2-86889-006-1");
   CPPUNIT_ASSERT( codeISBN == "9782868890061" );
}

// TODO : etc ...
