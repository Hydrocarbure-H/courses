// Manipulation d'un pointeur

#include <iostream>

using namespace std;

int main()
{
   // On utilise l'étoile (*) définir un pointeur
   int *ptrInt; // ptrInt est un pointeur sur un entier (int)

   // On utilise le & devant une variable pour avoir la valeur de son adresse et s'en servir pour initialiser ou affecter un pointeur
   int i = 2;
   ptrInt = &i; // affectation de ptrInt avec l'adresse de la variable i (&i)
   cout << "Le contenu de i est : " << i << '\n';
   cout << "L'adresse de i est : " << &i << '\n';
   cout << "Le contenu de prtInt est : " << ptrInt << '\n';
   cout << "L'adresse de prtInt est : " << &ptrInt << '\n';
   cout << "prtInt pointe sur : " << *ptrInt << '\n' << '\n';

   // On utilise l'étoile devant le pointeur (*) pour accéder à l'adresse stockée
   *ptrInt = 3; // indirection ("on pointe sur le contenu de i")
   
   // et maintenant la variable i contient 3
   cout << "Le contenu de i est : " << i << '\n';
   cout << "L'adresse de i est : " << &i << '\n';
   cout << "Le contenu de prtInt est : " << ptrInt << '\n';
   cout << "L'adresse de prtInt est : " << &ptrInt << '\n';
   cout << "prtInt pointe sur : " << *ptrInt << '\n' << '\n';

   return 0;
}
