#include "ServeurBLE.h"
#include <QFile>

ServeurBLE::ServeurBLE() : service(NULL), controleurBLE(NULL), timerTemperature(NULL)
{
    qDebug() << Q_FUNC_INFO;
    timerTemperature = new QTimer(this);
    connect(timerTemperature, SIGNAL(timeout()), this, SLOT(updateTemperature()));
}

ServeurBLE::~ServeurBLE()
{
    qDebug() << Q_FUNC_INFO;
}

void ServeurBLE::demarrer()
{
    qDebug() << Q_FUNC_INFO;

	// Création du serveur GATT sur le périphérique
    advertisingData.setDiscoverability(QLowEnergyAdvertisingData::DiscoverabilityGeneral);
    //advertisingData.setIncludePowerLevel(true);
    advertisingData.setLocalName("MonServeurBLE");
    // Définition des services à offrir aux périphériques
    QBluetoothUuid serviceUuid(QString(SERVICE_UUID));
    advertisingData.setServices(QList<QBluetoothUuid>() << serviceUuid);

    // Création des caractéristiques
    QBluetoothUuid userUuid(QString(CHAR_UUID_USER1));
    QBluetoothUuid temperatureUuid((quint32)CHAR_UUID_TEMPERATURE);
    QLowEnergyCharacteristicData charUser = createCharacteristic(userUuid, QLowEnergyCharacteristic::Write | QLowEnergyCharacteristic::Read);
    QLowEnergyCharacteristicData charTemperature = createCharacteristic(temperatureUuid, QLowEnergyCharacteristic::Read | QLowEnergyCharacteristic::Notify);

    // Association des caractéristiques au service 
    QLowEnergyServiceData serviceData;
    serviceData.setType(QLowEnergyServiceData::ServiceTypePrimary);
    serviceData.setUuid(serviceUuid);
    serviceData.addCharacteristic(charUser);
    serviceData.addCharacteristic(charTemperature);

    // Création du controleur BLE
    controleurBLE = QLowEnergyController::createPeripheral();
    connect(controleurBLE, SIGNAL(stateChanged(QLowEnergyController::ControllerState)), this, SLOT(controllerStateChanged(QLowEnergyController::ControllerState)));

    // Ajout du service
    service = controleurBLE->addService(serviceData);
    connect(service, SIGNAL(characteristicChanged(QLowEnergyCharacteristic,QByteArray)), this, SLOT(characteristicChanged(QLowEnergyCharacteristic,QByteArray)));

    // Démarrage
    controleurBLE->startAdvertising(QLowEnergyAdvertisingParameters(), advertisingData, advertisingData);
}

void ServeurBLE::onDeviceConnected()
{
    qDebug() << Q_FUNC_INFO;
}
    
void ServeurBLE::onDeviceDisconnected()
{
    qDebug() << Q_FUNC_INFO;
}

void ServeurBLE::onError(QLowEnergyController::Error erreur)
{
    qDebug() << Q_FUNC_INFO << erreur;
}

void ServeurBLE::controllerStateChanged(QLowEnergyController::ControllerState state)
{
    if (state == QLowEnergyController::UnconnectedState)
    {
        qDebug() << Q_FUNC_INFO << "client déconnecté";
        controleurBLE->startAdvertising(QLowEnergyAdvertisingParameters(), advertisingData, advertisingData);        
        timerTemperature->stop();
    }

    if (state == QLowEnergyController::ConnectedState)
    {
        qDebug() << Q_FUNC_INFO << "client connecté";
        //démarrage lecture température
        timerTemperature->start(1000);
    }
}

void ServeurBLE::characteristicChanged(QLowEnergyCharacteristic c, QByteArray data)
{
    qDebug() << Q_FUNC_INFO << c.uuid().toString() << data;
}

void ServeurBLE::updateTemperature()
{
    // Récupération de la valeur de température
    QByteArray rawTemp = readValueFromFile("/sys/devices/virtual/thermal/thermal_zone0/temp");
    float temperatureC = rawTemp.toInt() / 1000.;
    qDebug() << Q_FUNC_INFO << temperatureC;
    qint16 temperature = rawTemp.toInt() / 100;

    // Récupération de la caratéristique du service
    QLowEnergyCharacteristic characteristic = service->characteristic(QBluetoothUuid((quint32)CHAR_UUID_TEMPERATURE));
    if(characteristic.isValid())
    {
        // Mise à jour de la donnée
        QByteArray datas((char*)&temperature, sizeof(qint16));
        service->writeCharacteristic(characteristic, datas); // Potentially causes notification.
        qDebug() << Q_FUNC_INFO << datas;
    }
    else
        qDebug() << Q_FUNC_INFO << characteristic.uuid().toString() << "not valid";
}

void ServeurBLE::setValue(QBluetoothUuid uuid, quint32 value)
{
    QLowEnergyCharacteristic characteristic = service->characteristic(uuid);
    if(characteristic.isValid())
    {
        //if (characteristic.properties() & QLowEnergyCharacteristic::Write)
        {
            service->writeCharacteristic(characteristic, QByteArray::number(value)); // Potentially causes notification.
            qDebug() << Q_FUNC_INFO << QByteArray::number(value);
        }
    }
}

QLowEnergyCharacteristicData ServeurBLE::createCharacteristic(QBluetoothUuid uuid, QLowEnergyCharacteristic::PropertyTypes type)
{
    QLowEnergyCharacteristicData charData;
    charData.setUuid(QBluetoothUuid(uuid));
    charData.setValue(QByteArray(2, 0));
    charData.setProperties(type);
    const QLowEnergyDescriptorData clientConfig(QBluetoothUuid::ClientCharacteristicConfiguration, QByteArray(2, 0));
    charData.addDescriptor(clientConfig);

    return charData;
}

QByteArray ServeurBLE::readValueFromFile(QString filePath)
{
    QByteArray data;

    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly))
    {
        data = file.readAll();
        data.remove(data.length()-1, 1);
        file.close();
    }

    return data;
}
