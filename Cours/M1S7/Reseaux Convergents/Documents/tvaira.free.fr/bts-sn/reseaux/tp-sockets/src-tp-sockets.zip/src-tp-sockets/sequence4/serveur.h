#ifndef SERVEUR_H
#define SERVEUR_H

#include <QObject>
#include <QtNetwork>
#include <QList>

#define ADRESSE_SERVEUR              "127.0.0.1"
#define PORT_SERVEUR                    5000

class Serveur : public QObject
{
   Q_OBJECT

   public:
      Serveur();
      void demarrer();

   private:
      QTcpServer *serveur;
      //QList<QTcpSocket *> clients;

   private slots:
      void nouvelleConnexion();
      void deconnexionClient();
      void envoyer(const QString adresseIP, int numeroPort, const QString &Message);
      void recevoir();

   signals:
};

#endif
