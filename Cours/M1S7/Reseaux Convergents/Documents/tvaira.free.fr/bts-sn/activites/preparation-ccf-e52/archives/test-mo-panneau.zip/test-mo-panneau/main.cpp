#include <QApplication>
#include <QString>
#include <QTextCodec>

#include "panneau.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    Panneau panneau; // "/dev/ttyUSB0" par défaut

    QString message = "SAEIV 2016";
    
    panneau.afficher(message);

    qDebug() << "Fin";

    return 0;
}
