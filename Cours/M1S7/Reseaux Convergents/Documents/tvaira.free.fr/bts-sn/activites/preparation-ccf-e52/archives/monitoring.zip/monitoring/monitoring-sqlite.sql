CREATE TABLE salles (
    "idSalle" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, 
    "nom" VARCHAR(255) NOT NULL UNIQUE,
    "description" VARCHAR(255),
    "ip" VARCHAR(15) NOT NULL UNIQUE,
    "port" INTEGER NOT NULL,
    "etat" INTEGER NOT NULL
);

INSERT INTO salles (idSalle, nom, description, ip, port, etat) VALUES
(1, 'B20', 'salle BTS SN', '192.168.52.30', 5000, 1),
(2, 'B22', 'salle BTS SN', '192.168.52.31', 5000, 1),
(3, 'C12', 'salle', '192.168.52.32', 5000, 1);

