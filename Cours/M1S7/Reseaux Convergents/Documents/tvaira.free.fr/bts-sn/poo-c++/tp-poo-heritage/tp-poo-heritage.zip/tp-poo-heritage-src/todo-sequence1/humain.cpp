#include "humain.h"

// Constructeur
Humain::Humain(const string nom/*=""*/, const string boissonFavorite/*="eau"*/) : nom(nom), boissonFavorite(boissonFavorite)
{
}

Humain::~Humain()
{
}

// Accesseurs

string Humain::getBoissonFavorite() const
{
   return boissonFavorite;
}

void Humain::setBoissonFavorite(const string nouvelleBoissonFavorite)
{
   this->boissonFavorite = nouvelleBoissonFavorite;
}


// Services
void Humain::parle(const string texte) const
{
   cout << "(" << nom << ") -- " << texte << endl;
}
