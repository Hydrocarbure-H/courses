#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <stdint.h>
#include <cstring>

/*

7E	            Start Delimeter
00 0A	         Length Bytes
01 	         API Identifier
01 	         API Frame ID
50 01	         Destination Address low
00 	         Option Byte
48 65 6C 6C 6F Data Packet
B8             Checksum
*/

int main()
{
   uint8_t cmd[64];
   char message[64] = "Hello";
   uint16_t checksum = 0xFF;
   int n;
   
   cmd[0] = 0x7E; //Start Delimeter
   cmd[1] = 0x00; //Length Bytes
   cmd[2] = 0x0A; //
   cmd[3] = 0x01; //API Identifier
   cmd[4] = 0x01; //API Frame ID
   cmd[5] = 0x50; //Destination Address low
   cmd[6] = 0x00; //
   cmd[7] = 0x00; //Option Byte
   n = 8;
   for(int i=0; i<strlen(message);i++,n++)
   {
      cmd[n] = message[i];
      //printf("0x%02X 0x%02X\n", message[i], cmd[n]);
   }
   cmd[n] = 0x00; //Checksum   
   //printf("n=%d\n", n);   
   for(int i=3; i<n;i++)
   {
      checksum -= cmd[i];
      //printf("0x%02X %d\n", cmd[i], checksum);
   }
   cmd[n++] = (checksum & 0x00FF); //Checksum   
   //printf("checksum = 0x%02X\n", checksum & 0x00FF);
   
   printf("\n\n\t");
   for(int i=0; i<n;i++)
   {
      printf("%02X ", cmd[i]);
   }
   printf("\n\n\n\n");
   
   return 0;
}
