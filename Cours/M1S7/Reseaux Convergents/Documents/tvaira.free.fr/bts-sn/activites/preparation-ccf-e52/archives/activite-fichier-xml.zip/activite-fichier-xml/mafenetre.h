#ifndef MAFENETRE_H
#define MAFENETRE_H

#include <QtGui>
#include <QtXml/QDomDocument>
#include <QFileInfo>
#include <QSettings>
#include <QMessageBox>
#include <QDebug>

#define INTERFACES_XML "interfaces.xml"

// Des données
typedef struct
{
    int             id;
    QString         peripherique;

} Interface;

class MaFenetre : public QWidget
{
    Q_OBJECT
public:
    explicit MaFenetre(QWidget *parent = 0);
    ~MaFenetre();
    
private:
    QLabel              *labelListe;
    QComboBox           *listeInterfaces;
    QLabel              *labelPeripherique;
    QLineEdit           *editPeripherique;
    QPushButton         *boutonAjouter;
    QPushButton         *boutonSupprimer;
    QList<Interface>    interfaces;

    bool lireXML();
    bool ecrireXML();
    void afficherListe();

signals:
    
public slots:
    void ajouter();
    void supprimer();
};

#endif // MAFENETRE_H
