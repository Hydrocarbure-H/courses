#include <QApplication>
#include <QTextCodec>

#include "pupitreconducteur.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    PupitreConducteur pupitreConducteur; // "/dev/ttyUSB0" par défaut

    pupitreConducteur.gererMenuService();

    pupitreConducteur.quitter();

    qDebug() << "Fin";

    return 0;
}
