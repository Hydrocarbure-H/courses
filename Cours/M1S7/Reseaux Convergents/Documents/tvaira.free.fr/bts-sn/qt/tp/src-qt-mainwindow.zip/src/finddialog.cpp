#include "finddialog.h"

FindDialog::FindDialog(QWidget *parent)
 : QDialog(parent)
{
    label = new QLabel(tr("Recherche :"));
    lineEdit = new QLineEdit;
    label->setBuddy(lineEdit);

    caseCheckBox = new QCheckBox(tr("Respecter la &casse"));
    backwardCheckBox = new QCheckBox(QString::fromUtf8("Chercher en &arrière"));
    regCheckBox = new QCheckBox(QString::fromUtf8("Utiliser des expressions &régulières"));

    findButton = new QPushButton(tr("&Rechercher"));
    findButton->setDefault(true);
    findButton->setEnabled(false);

    closeButton = new QPushButton(tr("&Fermer"));

    connect(lineEdit, SIGNAL(textChanged(const QString &)), this, SLOT(validerBouton(const QString &)));
    connect(findButton, SIGNAL(clicked()), this, SLOT(clicRechercher()));
    connect(closeButton, SIGNAL(clicked()), this, SLOT(close()));

    QHBoxLayout *topLeftLayout = new QHBoxLayout;
    topLeftLayout->addWidget(label);
    topLeftLayout->addWidget(lineEdit);

    QVBoxLayout *leftLayout = new QVBoxLayout;
    leftLayout->addLayout(topLeftLayout);
    leftLayout->addWidget(caseCheckBox);
    leftLayout->addWidget(backwardCheckBox);
    leftLayout->addWidget(regCheckBox);

    QVBoxLayout *rightLayout = new QVBoxLayout;
    rightLayout->addWidget(findButton);
    rightLayout->addWidget(closeButton);
    rightLayout->addStretch();

    QHBoxLayout *mainLayout = new QHBoxLayout;
    mainLayout->addLayout(leftLayout);
    mainLayout->addLayout(rightLayout);
    setLayout(mainLayout);

    setWindowTitle(tr("Rechercher..."));
    setFixedHeight(sizeHint().height());
}

FindDialog::~FindDialog() 
{

}

void FindDialog::clicRechercher()
{
    QString text = lineEdit->text();
    QRegExp re(text);
    Qt::CaseSensitivity cs = caseCheckBox->isChecked() ? Qt::CaseSensitive : Qt::CaseInsensitive;

    //expr.setPatternSyntax(QRegExp::Wildcard);

    if (!regCheckBox->isChecked())
    {
      if (backwardCheckBox->isChecked())
      {
        emit rechercherPrecedent(text, cs);
      }
      else
      {
        emit rechercherSuivant(text, cs);
      }
   }
   else
   {
      if (backwardCheckBox->isChecked())
      {
        emit rechercherPrecedent(re, cs);
      }
      else
      {
        emit rechercherSuivant(re, cs);
      }
   }
}

void FindDialog::validerBouton(const QString &text)
{
    findButton->setEnabled(!text.isEmpty());
}
