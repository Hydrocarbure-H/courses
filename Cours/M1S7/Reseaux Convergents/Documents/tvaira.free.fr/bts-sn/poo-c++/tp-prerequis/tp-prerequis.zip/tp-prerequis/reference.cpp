// Manipulation d'une référence

#include <iostream>

using namespace std;

int main()
{
   int i = 2; // i est un entier valant 2
   int x = 0;

   // On indique le & devant le nom de la variable et cela signifie ``référence''
   int &j = i; // j est une référence sur un entier et cet entier est i
   cout << "Le contenu de i est : " << i << '\n';
   cout << "Le contenu de j est : " << j << '\n' << '\n';

   //&j = x; // Erreur : illégal (on ne peut pas affecter une nouvelle variable à une référence déjà initialisée)
   //int &k = 44; // Erreur : illégal (on ne peut pas créer une référence sur une valeur)

   // A partir d'ici j est ``synonyme`` de i, ainsi :
   j = j + 1; // est équivalent à i = i + 1 !

   cout << "Le contenu de i est : " << i << '\n';
   cout << "Le contenu de j est : " << j << '\n' << '\n';

   return 0;
}
