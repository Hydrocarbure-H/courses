<?php
//error_reporting(E_ALL);
require_once ('./include/monitoring.inc.php');
require_once ('./include/salle.class.php');

function read($sock, $size=128)
{
    if(!socket_last_error($sock))
    {
        while($buffer = @socket_read($sock, $size, PHP_NORMAL_READ))
        if($buffer = trim($buffer))
            break;
    }
    else
        return FALSE;
    
    return $buffer;
}

function recevoir($adresse, $port)
{
    UpdateLog("".__FUNCTION__."()", $GLOBALS['config']['logfile']);
    $socket = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
    if ($socket === false) 
    {
        $donnees["erreur"] = true;
        $donnees["message"] = "Erreur socket_create() : " . socket_strerror(socket_last_error()) . " [$adresse:$port]";
        UpdateLog($donnees['message'], $GLOBALS['config']['logfile']);
    }
    else
    {
        $result = @socket_connect($socket, $adresse, $port);
        if ($socket === false || $result === false) 
        {
            $donnees["erreur"] = true;
            $donnees["message"] = "Erreur socket_connect() : " . socket_strerror(socket_last_error($socket)) . " [$adresse:$port]";
            UpdateLog($donnees['message'], $GLOBALS['config']['logfile']);
        }
        else
        {       
            $sonde = false;
            $led = false;
            $nb = 0;
            do
            {
                $trame = read($socket);        
                /*
                // Exemples :
                $trame = "SONDE;21.5;C;20.8;C;43;%;1194;lux;";
                $trame = "LED;1;0;1;1;";
                */
                //debug($trame);
                UpdateLog("Trame -> ".$trame, $GLOBALS['config']['logfile']);
                if($trame)
                {
                    $champs = explode(";", $trame);
                    if($champs[0] == "SONDE" && count($champs) >= 7)
                    {
                        $donnees = array();
                        $donnees["temperature"] = $champs[1];
                        $donnees["ressentie"] = $champs[3];
                        $donnees["humidite"] = $champs[5];
                        $donnees["luminosite"] = $champs[7];
                        $sonde = true;
                    }
                    else if($champs[0] == "LED" && count($champs) >= 4)
                    {
                        $donnees["led"] = $champs[4];
                        $led = true;
                    }
                    else
                    {
                        $nb++;
                    }
                    $valid = ($sonde && $led) || ($nb > 3);
                    
                }
                else
                {
                    $donnees["erreur"] = true;
                    $donnees["message"] = "Aucune trame !"; 
                    $valid = true;           
                }
            }
            while(!$valid);
            if($nb > 3)
            {
                $donnees["erreur"] = true;
                $donnees["message"] = "Aucune trame valide !";            
            }
            else
            {
                $donnees["erreur"] = false;
                $donnees["message"] = "";
            }
        }
    }
    
    //echo "Fermeture du socket ...";
    @socket_close($socket);
    
    echo json_encode($donnees);
    $str = toString($donnees);
    UpdateLog($str, $GLOBALS['config']['logfile']);
}

function envoyer($adresse, $port, $send)
{
    UpdateLog("".__FUNCTION__."()", $GLOBALS['config']['logfile']);
    $socket = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
    if ($socket === false) 
    {
        $donnees["erreur"] = true;
        $donnees["message"] = "Erreur socket_create() : " . socket_strerror(socket_last_error()) . " [$adresse:$port]";
        UpdateLog($donnees['message'], $GLOBALS['config']['logfile']);
    }
    else
    {
        $result = @socket_connect($socket, $adresse, $port);
        if ($socket === false || $result === false) 
        {
            $donnees["erreur"] = true;
            $donnees["message"] = "Erreur socket_connect() : " . socket_strerror(socket_last_error($socket)) . " [$adresse:$port]";
            UpdateLog($donnees['message'], $GLOBALS['config']['logfile']);
        }
        else
        {
            //SET LED 0\n -> éteint la Led 
            //SET LED 1\n -> allume la Led en rouge
            //SET LED ROUGE
            //SET LED VERTE
            $requete = "SET LED $send\r";
            //debug($requete);
            UpdateLog("Requête -> ".$requete, $GLOBALS['config']['logfile']);
            socket_write($socket, $requete, strlen($requete));
            $trame = read($socket);        
            //debug($trame);
            UpdateLog("Trame -> ".$trame, $GLOBALS['config']['logfile']);
            if($trame)
            {
                if($trame == "ERREUR")
                {
                    $donnees["erreur"] = true;
                    $donnees["message"] = "Erreur";
                }
                else if($trame == "OK")
                {
                    $donnees["erreur"] = false;
                    $donnees["message"] = "Ok";
                }
                else
                {
                    $donnees["erreur"] = true;
                    $donnees["message"] = "Aucune trame !";
                }
            }
        }
    }
    //echo "Fermeture du socket ...";
    @socket_close($socket);   
    
    echo json_encode($donnees);
    $str = toString($donnees);
    UpdateLog($str, $GLOBALS['config']['logfile']);
}

$str = toString($_POST);
UpdateLog($str, $GLOBALS['config']['logfile']);
//UpdateLog("Nom -> ".$_POST['nom'], $GLOBALS['config']['logfile']);

if(!Empty($_POST["nom"]))
{
    $salle = new Salle($_POST["nom"]);    
    if(!Empty($salle->getIp()))
    {
        $description = "Salle : " . $salle->getNom() . " [".$salle->getIp().":".$salle->getPort()."]";    
        UpdateLog($description, $GLOBALS['config']['logfile']);
        if(!IsSet($_POST["send"]))
            recevoir($salle->getIp(), $salle->getPort());
        else
            envoyer($salle->getIp(), $salle->getPort(), $_POST["send"]);
    }
}

exit;
?>
