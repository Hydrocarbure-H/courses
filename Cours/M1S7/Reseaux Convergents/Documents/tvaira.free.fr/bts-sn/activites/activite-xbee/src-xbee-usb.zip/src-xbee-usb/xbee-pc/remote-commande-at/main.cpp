/*
	libxbee - a C/C++ library to aid the use of Digi's XBee wireless modules
	          running in API mode.

	Copyright (C) 2009 onwards  Attie Grande (attie@attie.co.uk)

	libxbee is free software: you can redistribute it and/or modify it
	under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	libxbee is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with libxbee. If not, see <http://www.gnu.org/licenses/>.
*/

/*
	This sample has been designed to give you a very basic introduction to
	libxbee. The sample will start libxbee, create a connection to the local
	XBee module, and then request its Node Identifier before shutting down.
	This sample does not use callback functions.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <xbee.h>

const char commandes[7][3] = { { "ID" },
                               { "MY" },
                               { "SH" },
                               { "SL" },
                               { "VR" },
                               { "CH" },
                               { "NI" }
                             };

int main(void) 
{
	struct xbee *xbee;
	struct xbee_con *con;
   struct xbee_conAddress address;
	unsigned char txRet;
	xbee_err ret;

	/* setup libxbee, using the USB to Serial adapter '/dev/ttyUSB0' at 57600 baud */
	if ((ret = xbee_setup(&xbee, "xbee1", "/dev/ttyUSB0", 9600)) != XBEE_ENONE) {
		printf("ret: %d (%s)\n", ret, xbee_errorToStr(ret));
		return ret;
	}

	/* create a new AT connection to the local XBee */
	if ((ret = xbee_conNew(xbee, &con, "Local AT", NULL)) != XBEE_ENONE) {
		printf("xbee_conNew() returned: %d (%s)", ret, xbee_errorToStr(ret));
		return ret;
	}
   
    memset(&address, 0, sizeof(address));
    /* 64 bits */
	/*address.addr64_enabled = 1;
	address.addr64[0] = 0x00;
	address.addr64[1] = 0x13;
	address.addr64[2] = 0xA2;
	address.addr64[3] = 0x00;
	address.addr64[4] = 0x40;
	address.addr64[5] = 0xC1;
	address.addr64[6] = 0x72;
	address.addr64[7] = 0x5A;*/
    
    /* 16 bits */
    address.addr16_enabled = 1;
	address.addr16[0] = 0x50;
    address.addr16[1] = 0x01;	
	if ((ret = xbee_conNew(xbee, &con, "Remote AT", &address)) != XBEE_ENONE) {
		printf("xbee_conNew() returned: %d (%s)", ret, xbee_errorToStr(ret));
		return ret;
	}

   for(int n=0;n<7;n++)
   {
      /* send the AT command 
         when the response is recieved, the packet will be directed to the callback function */
      ret = xbee_conTx(con, &txRet, commandes[n]);
      /* print out the return value
         if this is non-zero, then check 'enum xbee_errors' in xbee.h for its meaning
         alternatively look at the xbee_errorToStr() function */
      if (ret == XBEE_ETX) 
      {
         printf("Error: %s... (0x%02X)\n", xbee_errorToStr(ret), txRet);
      } 
      else if (ret) 
      {
         printf("Error: %s\n", xbee_errorToStr(ret));
      } 
      else 
      {
         //printf("tx: %d\n", ret);
         struct xbee_pkt *pkt;
         if ((ret = xbee_conRx(con, &pkt, NULL)) != XBEE_ENONE) 
         {
            printf("Error after calling xbee_conRx(): %s\n", xbee_errorToStr(ret));
         } 
         else 
         {
            int i;
            //printf("rx: %d\n", ret);
            printf("Command: AT%s\n", commandes[n]);
            printf("Response is %d bytes long:\n", pkt->dataLen);
            for (i = 0; i < pkt->dataLen; i++) 
            {
               printf("%3d: 0x%02X - %c\n", i, pkt->data[i], (((pkt->data[i] >= ' ') && (pkt->data[i] <= '~'))?pkt->data[i]:'.'));
            }
            printf("\n");
         }
      }
   }
	
	/* shutdown the connection */
	if ((ret = xbee_conEnd(con)) != XBEE_ENONE) {
		xbee_log(xbee, -1, "xbee_conEnd() returned: %d", ret);
		return ret;
	}

	/* shutdown libxbee */
	xbee_shutdown(xbee);

	return 0;
}
