#include "mafenetre.h"

MaFenetre::MaFenetre(QWidget *parent) :
    QWidget(parent)
{
    // La GUI
    labelNbMesures = new QLabel("Nb mesures :", this);
    editNbMesures = new QSpinBox(this);
    editNbMesures->setValue(NB_MESURES); // par défaut
    tableauMesures = new QTableWidget(this);
    QStringList labelsMesures;
    labelsMesures << "Horodatage" << "Température °C";
    tableauMesures->setColumnCount(labelsMesures.count());
    tableauMesures->setHorizontalHeaderLabels(labelsMesures);
    tableauMesures->setRowCount(0);
    boutonAcquerir = new QPushButton("Acquérir", this);
    boutonCharger = new QPushButton("Charger", this);
    boutonEnregistrer = new QPushButton("Enregistrer", this);

    QVBoxLayout *layoutPrincipal = new QVBoxLayout;
    QHBoxLayout *layoutMesures = new QHBoxLayout;
    QHBoxLayout *layoutTableau = new QHBoxLayout;
    QHBoxLayout *layoutBoutons = new QHBoxLayout;

    layoutMesures->addWidget(labelNbMesures);
    layoutMesures->addWidget(editNbMesures);
    layoutTableau->addWidget(tableauMesures);
    layoutBoutons->addWidget(boutonAcquerir);
    layoutBoutons->addWidget(boutonCharger);
    layoutBoutons->addWidget(boutonEnregistrer);

    layoutPrincipal->addLayout(layoutMesures);
    layoutPrincipal->addLayout(layoutTableau);
    layoutPrincipal->addLayout(layoutBoutons);
    layoutPrincipal->addStretch();

    setLayout(layoutPrincipal);

    // Initialisation
    connect(boutonAcquerir, SIGNAL(clicked()), this, SLOT(acquerir()));
    connect(boutonCharger, SIGNAL(clicked()), this, SLOT(charger()));
    connect(boutonEnregistrer, SIGNAL(clicked()), this, SLOT(enregistrer()));
    qsrand(QTime::currentTime().msec());
}

MaFenetre::~MaFenetre()
{
}

bool MaFenetre::lireCSV(const QString &fichier)
{
    // TODO

    return false;
}

bool MaFenetre::ecrireCSV()
{
    // Le fichier CSV
    QFile *fichierCSV = new QFile("datas.csv");

    // Ouverture du fichier en mode texte et en écriture seule
    if (fichierCSV->open(QFile::WriteOnly | QIODevice::Text))
    {
        // Ecriture de l'en-tête
        QTextStream entete(fichierCSV);
        entete << QString::fromUtf8("Horodatage;Température °C") << endl;
    }
    else
    {
        QMessageBox::critical(0, "Erreur !", ("Impossible d'ouvrir le fichier datas.csv"));
        delete fichierCSV;

        return false;
    }

    // Ecriture des données
    QTextStream datas(fichierCSV);
    QString data;

    // on récupère toutes les mesures et on les écrit dans le fichier
    int n = 0;
    while ( n < mesures.size() )
    {
        qDebug() << QString::fromUtf8("<MaFenetre::ecrireCSV()> %1 : %2 °C").arg(mesures[n].horodatage).arg(QString::number(mesures[n].valeur));
        data = mesures[n].horodatage;
        datas << "\"" << data << "\""; // on protège la data avec des "
        datas << ";";
        data = QString::number(mesures[n].valeur);
        //data.sprintf("%.2f", mesures[n].valeur);
        // A la française ?
        data.replace(QString("."), QString(","));
        datas << "\"" << data << "\""; // on protège la data avec des "
        datas << endl;
        ++n;
    }

    // On ferme le fichier
    fichierCSV->close();

    delete fichierCSV;

    return true;
}

void MaFenetre::acquerir()
{
    // nouvelle acquisition
    mesures.clear();
    for(int i = 0; i < editNbMesures->value(); i++)
    {
        Mesure mesure = generer();
        qDebug() << QString::fromUtf8("<MaFenetre::acquerir()> %1 : %2 °C").arg(mesure.horodatage).arg(QString::number(mesure.valeur));
        mesures.push_back(mesure);
    }
    afficher();
}

void MaFenetre::charger()
{
    // TODO cf. QFileDialog::getOpenFileName()

}

void MaFenetre::enregistrer()
{
    ecrireCSV();
}

Mesure MaFenetre::generer(long min, long max)
{
    Mesure mesure;
    long   echantillon;
    double valeur;

    // simule des nombres après la virgule
    min *= 100;
    max *= 100;
    echantillon = static_cast<long>(min + (static_cast<float>(qrand()) / RAND_MAX * (max - min + 1)));
    valeur = double(echantillon) / 100.;

    QDateTime maintenant = QDateTime::currentDateTime();
    QString horodatage = maintenant.toString("dd/MM/yyyy hh:mm");

    mesure.horodatage = horodatage;
    mesure.valeur = valeur;

    return mesure;
}

void MaFenetre::afficher()
{
    QTableWidgetItem *itemHorodatage, *itemMesure;

    // on réinitialise la table
    int nb = tableauMesures->rowCount();
    if(nb != 0)
    {
        // on les efface
        for(int r = 0; r < nb; r++)
            tableauMesures->removeRow(0);
    }

    // on récupère toutes les mesures
    int n = 0;
    while ( n < mesures.size() )
    {
        // on affiche les informations dans la table
        itemHorodatage = new QTableWidgetItem(mesures[n].horodatage);
        itemHorodatage->setFlags(Qt::NoItemFlags);
        itemHorodatage->setTextAlignment(Qt::AlignHCenter);

        itemMesure = new QTableWidgetItem(QString::number(mesures[n].valeur));
        itemMesure->setFlags(Qt::NoItemFlags);
        itemMesure->setTextAlignment(Qt::AlignHCenter);

        // on récupère le nombre de lignes déjà affichées dans la table
        int nb = tableauMesures->rowCount();

        // on ajoute une nouvelle ligne
        tableauMesures->setRowCount(++nb);
        // on insère les informations dans la table
        tableauMesures->setItem(nb-1, 0, itemHorodatage);
        tableauMesures->setItem(nb-1, 1, itemMesure);
        tableauMesures->resizeColumnsToContents();
        ++n;
    }
}
