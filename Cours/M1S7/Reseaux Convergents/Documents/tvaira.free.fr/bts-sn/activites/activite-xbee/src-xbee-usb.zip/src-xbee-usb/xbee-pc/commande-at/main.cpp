#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <xbee.h>

const char commandes[7][3] = { { "ID" },
                               { "MY" },
                               { "SH" },
                               { "SL" },
                               { "VR" },
                               { "CH" },
                               { "NI" } };

int main(void) 
{
	struct xbee *xbee;
	struct xbee_con *con;
	unsigned char txRet;
	xbee_err ret;

	if ((ret = xbee_setup(&xbee, "xbee1", "/dev/ttyUSB0", 9600)) != XBEE_ENONE) 
    {
		printf("Erreur : %d (%s)\n", ret, xbee_errorToStr(ret));
		return ret;
	}

	if ((ret = xbee_conNew(xbee, &con, "Local AT", NULL)) != XBEE_ENONE) 
    {
		xbee_log(xbee, -1, "Erreur xbee_conNew() : %d (%s)", ret, xbee_errorToStr(ret));
		return ret;
	}

    for(int n=0;n<7;n++)
    {
      ret = xbee_conTx(con, &txRet, commandes[n]);
      if (ret == XBEE_ETX) 
      {
         printf("Erreur : %s... (0x%02X)\n", xbee_errorToStr(ret), txRet);
      } 
      else if (ret) 
      {
         printf("Erreur : %s (%d)\n", xbee_errorToStr(ret), ret);
      } 
      else 
      {
         struct xbee_pkt *pkt;
         if ((ret = xbee_conRx(con, &pkt, NULL)) != XBEE_ENONE) 
         {
            printf("Erreur xbee_conRx() : %s\n", xbee_errorToStr(ret));
         } 
         else 
         {
            int i;
            printf("Commande AT%s\n", commandes[n]);
            printf("Réponse : (%d octets)\n", pkt->dataLen);
            for (i = 0; i < pkt->dataLen; i++) 
            {
               printf("%3d : 0x%02X - %c\n", i, pkt->data[i], (((pkt->data[i] >= ' ') && (pkt->data[i] <= '~'))?pkt->data[i]:'.'));
            }
            printf("\n");
         }
      }
    }
	
	if ((ret = xbee_conEnd(con)) != XBEE_ENONE) 
    {
		xbee_log(xbee, -1, "Erreur xbee_conEnd() : %d", ret);
		return ret;
	}

	xbee_shutdown(xbee);

	return 0;
}
