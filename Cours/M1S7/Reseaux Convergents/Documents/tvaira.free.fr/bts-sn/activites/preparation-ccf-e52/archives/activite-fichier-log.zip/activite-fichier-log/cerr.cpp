#include <iostream>

using namespace std;

int main( int argc, char **argv )
{
    cout << "un message sur cout (stdout)\n";
    cerr << "un message sur cerr (stderr)\n";
    
    return 0;
}
