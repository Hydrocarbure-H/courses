#ifndef POINT_H
#define POINT_H

class Point 
{
   private:
      double    x, y;

      
   public:
      
};

#endif //POINT_H