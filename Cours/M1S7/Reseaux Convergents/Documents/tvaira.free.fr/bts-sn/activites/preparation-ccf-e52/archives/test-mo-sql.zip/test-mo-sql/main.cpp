#include <QtGui>
#include <QDebug>
#include <QtSql/QtSql>
#include <iostream>

/*
  Pré-requis : $ sudo apt-get install libqt4-sql-mysql
*/

/* Pour MySQL :

USE test;

CREATE TABLE `mesures` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `heure` time NOT NULL,
  `temperature` float NOT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `mesures` (`id`, `date`, `heure`, `temperature`) VALUES
(1, '2009-09-08', '08:00:00', 35.23),
(2, '2009-09-08', '08:01:00', 35.1),
(3, '2009-09-08', '08:02:00', 34.45),
(4, '2009-09-08', '08:03:00', 35.02),
(5, '2009-09-08', '08:04:00', 35.53),
(6, '2009-09-09', '08:00:00', 35.23),
(7, '2009-09-09', '08:01:00', 35.1),
(8, '2009-09-09', '08:02:00', 34.45),
(9, '2009-09-09', '08:03:00', 35.02),
(10, '2009-09-09', '08:04:00', 35.53),
(11, '2009-09-09', '08:05:00', 35.12);

*/

/*
  Lire :
*/

int main(int argc,char **argv)
{
   QApplication app(argc,argv);   

   QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
   //QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE"); // ou mettre QSQLITE

   db.setHostName("localhost");
   db.setUserName("root");
   db.setPassword("password");
   db.setDatabaseName("test");
   //db.setDatabaseName("bd-sqlite.sqlite"); // ou mettre le nom du fichier sqlite

   if(db.open())
   {
       std::cout << "Connexion réussie à " << db.hostName().toStdString() << std::endl;
   }
   else
   {
       std::cout << "La connexion a échouée !" << std::endl;
       return -1;
   }

   // Exemple 1 :
   QSqlQuery query("SELECT temperature FROM mesures");
   while (query.next()) 
   {
      QString temperature = query.value(0).toString();
      qDebug() << "temperature : " << temperature;
   }

   // Exemple 2 :
   bool retour;
   QString requete = "SELECT * FROM mesures";
   retour = query.exec(requete);
   if(retour)
   {
      qDebug() << "nb enregistrements : " << query.size();
      qDebug() << "nb colonnes : " << query.record().count();
      int fieldNo = query.record().indexOf("temperature");
      while (query.next()) 
      {
         QString date = query.value(fieldNo).toString();
         qDebug() << "temperature : " << date;
      }
   }
   else  qDebug() << query.lastError().text();
   
   // Exemple 3 :
   requete = "SELECT * FROM mesures";
   retour = query.exec(requete);
   if(retour)
   {
      while ( query.next() )  
      {  
         qDebug() << "enregistrement -> ";
         for(int i=0;i<query.record().count();i++)
            qDebug() << query.value(i).toString();
      } 
   }
   else  qDebug() << query.lastError().text();
   
   // Exemple 4 :
   requete = "SELECT count(temperature) AS nb FROM mesures";
   
   query.exec(requete);
   query.first();
   int nb = query.value(0).toInt();
   qDebug() << "nb mesures : " << nb;

   // Exemple 5 :
   QSqlQuery r;
   // Utilisation des marqueurs '?'
   // INSERT INTO `mesures` (`id`, `date`, `heure`, `temperature`) VALUES (...)
   r.prepare("INSERT INTO mesures (id, date, heure, temperature) VALUES ('', ?, ?, ?)");
   // id en auto-incrément
   r.addBindValue("2009-09-10");
   r.addBindValue("09:01:00");
   r.addBindValue(35.12);
   if (r.exec())
   {
       std::cout << "Insertion réussie" << std::endl;
   }
   else
   {
       std::cout << "Echec insertion !" << std::endl;
       qDebug() << r.lastError().text();
   }

   // Utilisation des marqueurs nominatifs
   r.prepare("INSERT INTO mesures (id, date, heure, temperature) VALUES (:id, :date, :heure, :temperature)");
   r.bindValue(":id", ""); // auto-incrément
   r.bindValue(":date", "2009-09-10");
   r.bindValue(":heure", "09:01:00");
   r.bindValue(":temperature", 34.92);
   if (r.exec())
   {
       std::cout << "Insertion réussie" << std::endl;
   }
   else
   {
       std::cout << "Echec insertion !" << std::endl;
       qDebug() << r.lastError().text();
   }

   db.close();
   return 0;
}
