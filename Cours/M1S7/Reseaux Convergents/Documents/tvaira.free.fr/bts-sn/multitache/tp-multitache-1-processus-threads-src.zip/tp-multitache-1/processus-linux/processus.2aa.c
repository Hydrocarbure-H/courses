#include <stdio.h>

int main() 
{
   setbuf(stdout, NULL);
   printf("+");
   fork();
   printf("*");
   fork();
   printf("!");

   return 0;
}

