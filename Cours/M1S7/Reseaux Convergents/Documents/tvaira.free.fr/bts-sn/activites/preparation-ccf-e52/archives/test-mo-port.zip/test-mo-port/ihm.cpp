#include "ihm.h"
#include "port.h"

#include <QDebug>

IHM::IHM(QWidget *parent) : QWidget(parent)
{
    lireConfiguration();

    labelPort = new QLabel(this);
    QString strPort = QString::fromUtf8("Port : ") + portPeripherique;
    labelPort->setText(strPort);

    labelPeriode = new QLabel(this);
    QString strPeriode = QString::fromUtf8("Période : ") + QString::number(periode) + QString::fromUtf8(" ms");
    labelPeriode->setText(strPeriode);
    cbPeriode = new QCheckBox("actif", this);

    labelDonnees = new QLabel(this);
    labelDonnees->setText(QString::fromUtf8("Données : "));
    donnees = new QTextEdit(this);
    donnees->setReadOnly(true);

    bDemarrer  = new QPushButton(QString::fromUtf8("Lire"), this);
    bDemarrer->setEnabled(false);
    bArreter   = new QPushButton(QString::fromUtf8("Effacer"), this);
    bArreter->setEnabled(true);
    bQuitter   = new QPushButton("Quitter", this);

    QHBoxLayout *hLayout0 = new QHBoxLayout;
    QHBoxLayout *hLayout0b = new QHBoxLayout;
    QHBoxLayout *hLayout1 = new QHBoxLayout;
    QHBoxLayout *hLayout2 = new QHBoxLayout;
    QHBoxLayout *hLayout3 = new QHBoxLayout;
    QVBoxLayout *mainLayout = new QVBoxLayout;
    hLayout0->addWidget(labelPort);
    hLayout0b->addWidget(labelPeriode);
    hLayout0b->addWidget(cbPeriode);
    hLayout1->addWidget(labelDonnees);
    hLayout2->addWidget(donnees);
    hLayout3->addWidget(bDemarrer);
    hLayout3->addWidget(bArreter);
    hLayout3->addWidget(bQuitter);
    mainLayout->addLayout(hLayout0);
    mainLayout->addLayout(hLayout0b);
    mainLayout->addLayout(hLayout1);
    mainLayout->addLayout(hLayout2);
    mainLayout->addLayout(hLayout3);
    setLayout(mainLayout);

    connect(cbPeriode, SIGNAL(stateChanged(int)), this, SLOT(activerModePeriodique(int)));
    connect(bDemarrer, SIGNAL(clicked()), this, SLOT(lire()));
    connect(bArreter, SIGNAL(clicked()), this, SLOT(effacer()));
    connect(bQuitter, SIGNAL(clicked()), this, SLOT(quitter()));
    connect(this, SIGNAL(quit()), qApp, SLOT(quit()));

    port = new Port(portPeripherique);
    if(port->estOuvert())
        bDemarrer->setEnabled(true);

    timerReception = new QTimer(this);
    timerReception->setInterval(periode);
    connect(timerReception, SIGNAL(timeout()), this, SLOT(lire()));
    
    //setWindowFlags(Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint);
    move(0, 0);
}

IHM::~IHM()
{    
    delete port;
}

void IHM::lireConfiguration()
{
    QString fichierINI = QCoreApplication::instance()->applicationDirPath() + "/" + QCoreApplication::instance()->applicationName() + ".ini";
    QSettings parametres(fichierINI, QSettings::IniFormat);
    //parametres.setIniCodec(QTextCodec::codecForName("UTF-8"));

    portPeripherique = parametres.value("main/port", "/dev/ttyUSB0").toString();
    periode = parametres.value("main/periode", 1000).toInt();

    #ifdef DEBUG_IHM    
    //qDebug() << QString::fromUtf8("IHM::lireConfiguration()> fichier          : %1").arg(parametres.fileName());
    qDebug() << QString::fromUtf8("IHM::lireConfiguration()> fichier          : %1").arg(fichierINI);
    qDebug() << QString::fromUtf8("IHM::lireConfiguration()> portPeripherique : %1").arg(portPeripherique);
    qDebug() << QString::fromUtf8("IHM::lireConfiguration()> periode          : %1").arg(periode);
    #endif
}

void IHM::lire()
{
    QString trame;
    port->recevoir(trame);
    actualiserTrame(trame);
}

void IHM::effacer()
{
    donnees->clear();
}

void IHM::quitter()
{
   emit quit();
}

void IHM::actualiserTrame(const QString &trame)
{
   donnees->append(trame);
}

void IHM::activerModePeriodique(int etat)
{
    if(etat == Qt::Checked)
    {
        timerReception->start(periode);
    }
    else
    {
        timerReception->stop();
    }
}
