#include <cstdio>
#include <time.h>
#include "port-xbee.h"

int main()
{
    PortXbee portXbee;
    char donnees[128];    
    time_t ts = time(NULL);
    struct tm *tmp;
    double temperatures[10] = { 25.1, 26.2, 22.3, 28.4, 25.5, 26.6, 24.7, 28.8, 24.9, 25.0 };
    int pressions[10] = { 1001, 1002, 1003, 1004, 1015, 1010, 1020, 1008, 1050, 1000 };
    double humidites[10] = { 30.1, 35.2, 33.3, 34.4, 37.5, 31.6, 32.7, 34.8, 35.9, 35.0 };
    char destid[2] = { 0x50, 0x00};
    char myid[2] = { 0x50, 0x01};
    int i = 0;

    srand(time(NULL));
    
    portXbee.ouvrir("/dev/ttyUSB0");

    //while(i < 50)
    while(1)
    {        
        memset(&donnees, 0, sizeof(donnees));
        
        ts = time(NULL);
        tmp = localtime(&ts);
        if (tmp == NULL) 
        {
            return 1;
        }

        if (strftime(donnees, sizeof(donnees), "%d/%m/%Y;%T", tmp) == 0) 
        {
            return 1;
        }
        printf("horodatage : %s\n", donnees);
     
        sprintf(donnees, "%s;%02x%02x;%.1f;%d;%.1f;\r\n", donnees, myid[0], myid[1], temperatures[rand() % 10], pressions[rand() % 10], humidites[rand() % 10]);
        //sprintf(donnees, "%d\r\n", i);
        portXbee.envoyer(destid, donnees, strlen(donnees));
        
        usleep(500000); // 100 ms
        
        ++i;
    }
    
    portXbee.fermer();
    
    return 0;
}

