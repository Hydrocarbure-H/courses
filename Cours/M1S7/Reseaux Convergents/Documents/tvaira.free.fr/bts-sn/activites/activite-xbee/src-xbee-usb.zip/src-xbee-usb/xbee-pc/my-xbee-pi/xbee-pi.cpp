#include "xbee-pi.h"

ConnexionXbee::ConnexionXbee(XBee &parent, string type, struct xbee_conAddress *address) : ConCallback(parent, type, address)
{
}

ConnexionXbee::~ConnexionXbee()
{
}

void ConnexionXbee::xbee_conCallback(libxbee::Pkt **paquet)
{
    recevoir(paquet);
}

void ConnexionXbee::recevoir(Pkt **paquet)
{
    cout << "recevoir() !\n";

	int i;
	for (i = 0; i < (*paquet)->size(); i++) 
    {
		cout << (**paquet)[i];
	}
	cout << "\n";

	/* if you want to keep the packet, then you MUST do the following:
	      libxbee::Pkt *myhandle = *paquet;
	      *paquet = NULL;
	   and then later, you MUST delete the packet to free up the memory:
	      delete myhandle;
	   if you do not want to keep the packet, then just leave everything as-is, and it will be free'd for you */
}
