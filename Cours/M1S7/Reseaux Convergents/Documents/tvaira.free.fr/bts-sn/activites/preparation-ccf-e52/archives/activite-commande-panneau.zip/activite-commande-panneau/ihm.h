#ifndef IHM_H
#define IHM_H

#include <QtGui>
#include <QtNetwork>

#define DEBUG_IHM

class PanneauLumineux;

class IHM : public QWidget
{
    Q_OBJECT

public:
    IHM( QWidget *parent = 0 );
    ~IHM();

private:
    PanneauLumineux *panneauLumineux;
    QString         adresseIP;
    int             port;

    // Widgets    
    QLabel          *labelAdresseIP;
    QLineEdit       *leAdresseIP;
    QLabel          *labelPort;
    QLineEdit       *lePort;
    QPushButton     *bConnecter;
    QPushButton     *bDeconnecter;
    QPushButton     *bEnvoyer;
    QPushButton     *bReset;
    QComboBox       *listeTaillePolice;
    QTextEdit       *message;
    
    void            initialiserListeTaillePolice();
    void            lireParametres();

signals:
    void            quit();

public slots:    
    void            quitter();
    void            connecter();
    void            deconnecter();
    void            envoyer();
    void            reinitialiser();
    void            changerTaillePolice(int choix);
    // slots pour la mise à jour de l'adresse ip et du numéro de port
    // TODO
};

#endif // IHM_H
