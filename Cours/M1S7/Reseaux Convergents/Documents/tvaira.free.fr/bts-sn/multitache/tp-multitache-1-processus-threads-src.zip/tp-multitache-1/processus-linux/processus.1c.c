#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() 
{
   int pid;
   
   pid = fork();
   if (pid == -1)
   {
      perror("fork"); exit(-1);
   }
   if (pid == 0)
   {
     
   }
   if (pid != 0) 
   {
      
   }

   return 0;
}

