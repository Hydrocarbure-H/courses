#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void etoile(void) 
{
  int i;
  char c1 = '*';
   
  for(i=1;i<=200;i++)
  {
     write(1, &c1, 1);// écrit un caractère sur stdout (descripteur 1)
  }
  return;
}


void diese(void) 
{
  int i;
  char c1 = '#';
   
  for(i=1;i<=200;i++)
  {
      write(1, &c1, 1);
  }
  return;
}

int main() 
{
   int pid;
   
   pid = fork();
   if (pid == -1)
   {
      perror("fork"); 
      exit(-1);
   }
   if (pid == 0)
   {
      
   }
   if (pid != 0) 
   {
      
   }

   return 0;
}

