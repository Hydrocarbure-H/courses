#include "mywidget.h"
#include "isbn.h"

MyWidget::MyWidget( QWidget *parent ) : QWidget( parent )
{
   // Création des widgets
   saisieISBN = new QLineEdit( this );
   etatISBN = new QLabel( this );

   QLabel *label1 = new QLabel( "Code ISBN :", this );

   // Création des layouts
   QHBoxLayout *mainLayout = new QHBoxLayout;

   // Mise en place des widgets et des layouts
   mainLayout->addWidget(label1);
   mainLayout->addWidget(saisieISBN);
   mainLayout->addWidget(etatISBN);
   setLayout(mainLayout);   

   // Initialisation
   isbn = new ISBN();
   if(isbn->estValide())
       setVert();
   else
       setRouge();

   // Connexion des signaux/slots
   connect( saisieISBN, SIGNAL(textChanged ( const QString & )), this, SLOT(valider( const QString & )) );
}

MyWidget::~MyWidget()
{
    delete isbn;
}

void MyWidget::valider( const QString & code )
{
    isbn->setISBN(code.toStdString());

    if(isbn->estValide())
        setVert();
    else
        setRouge();
}

void MyWidget::setRouge()
{
    QImage *image;
    QPixmap pixmap;

    image = new QImage();
    if(!(image->load("rouge.png")))
    {
       qWarning("Fichier introuvable !");
    }

    pixmap = QPixmap::fromImage(*image);
    etatISBN->setPixmap(pixmap);

    delete image;
}

void MyWidget::setVert()
{
    QImage *image;
    QPixmap pixmap;

    image = new QImage();
    if(!(image->load("vert.png")))
    {
       qWarning("Fichier introuvable !");
    }

    pixmap = QPixmap::fromImage(*image);
    etatISBN->setPixmap(pixmap);
    delete image;
}
