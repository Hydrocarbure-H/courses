#ifndef HISTORIQUE_H
#define HISTORIQUE_H

#include <ctime>

#define LG_HISTORIQUE 10

typedef unsigned char TPoste;

typedef struct
{
   char ordre;
   TPoste poste;
} TOrdre;

typedef struct
{
   char capteur;
   TPoste poste;
} TPosition;

typedef enum { POM = 0xFD, ACK, NAK } TReponse;

typedef struct
{
   time_t date;
   union
   {
      TOrdre      infoOrdre;
      TPosition   infoPosition;
      TReponse    infoReponse;
   };
} TInfo;

class Historique
{
	private:      
		unsigned int indice;
      const unsigned int taille;
      TInfo *historique;

	public:
		Historique(int taille=LG_HISTORIQUE);
      ~Historique();
      
      unsigned int getNbEvenements() const;
      unsigned int getTaille() const;
      
		void ajouterOrdre(TOrdre ordre);
      void ajouterOrdreSolution1(TOrdre ordre);
      void ajouterOrdreSolution2(TOrdre ordre);
      void ajouterOrdreSolution3(TOrdre ordre);
      void ajouterOrdreSolution4(TOrdre ordre);
		
		void ajouterPosition(TPosition position);
		void ajouterReponse(TReponse reponse);

		void afficherDernierOrdre();
};

#endif
