#ifndef PORT_H
#define PORT_H

#include <QObject>
#include <QList>

#include "qextserialenumerator.h"
#include "qextserialport.h"

#define DEBUG_PORT

#define BUFFERSIZE 1024 

class Port : public QObject
{
Q_OBJECT
public:
   Port();
   Port(const QString &portName);
   ~Port();
   
   bool ouvrir(const QString &portName, int debit = 9600);
   int  transmettre(const QString &message);
   int  transmettre(char *message);
   int  recevoir(QString &message);
   char lire();
   long getNbOctetsDisponibles();
   bool estOuvert();
   
private:
   QextSerialPort *port;

private slots:
   void onReadyRead();
};


#endif // PORT_H
