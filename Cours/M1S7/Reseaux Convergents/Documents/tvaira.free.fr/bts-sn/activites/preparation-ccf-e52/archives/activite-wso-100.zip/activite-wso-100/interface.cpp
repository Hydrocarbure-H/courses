#include <QDebug>

#include "interface.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

InterfacePeakNMEA2000::InterfacePeakNMEA2000()
{
   setlocale(LC_ALL, "");
   #ifndef INTERFACE_SIMULATION
   handle = 0;
   initialise = false;
   wBTR0BTR1 = 0x011c; // 250 kbits/s -> NMEA 2000
   nExtended = CAN_INIT_TYPE_EX; // Etendu -> NMEA 2000
   interface = INTERFACE_DEFAUT;
   #else
   initialise = false;
   interface = INTERFACE_DEFAUT;
   // Initialise le g�n�rateur pseudo-al�atoire
   qsrand(QTime::currentTime().msec());
   #endif
}

InterfacePeakNMEA2000::~InterfacePeakNMEA2000()
{
}

bool InterfacePeakNMEA2000::initialiser()
{
    DWORD etat;

	if(initialise == false)
	{
      #ifndef INTERFACE_SIMULATION
		handle = LINUX_CAN_Open(interface.c_str(), O_RDWR);
		if(handle)  // Initialisation r�ussie ?
		{
			initialise = true;
            etat = CAN_Init(handle, wBTR0BTR1, nExtended);
            if(etat)
            {
                initialise = false;
                cerr << "Erreur initialisation ! (CAN_Init)" << endl;
            }
		}
		else
		{
			/* TODO : gestion des erreurs */
			initialise = false;
            cerr << "Erreur ouverture ! (LINUX_CAN_Open)" << endl;
		}
      #else
      initialise = true;
      #endif
	}
	
	return initialise;
}

void InterfacePeakNMEA2000::fermer()
{
   #ifndef INTERFACE_SIMULATION
	CAN_Close(handle);
   #endif
	initialise = false;
}

int InterfacePeakNMEA2000::obtenirMessage(int pgn, TPCANMsg &message)
{
   time_t ts;
   return obtenirMessage(pgn, message, ts);
}

int InterfacePeakNMEA2000::obtenirMessage(int pgn, TPCANMsg &message, time_t &timestamp)
{
   int pgnCourant;
   bool fini = false;
   
   #ifndef INTERFACE_SIMULATION
   TPCANRdMsg msg;
   int erreur;
   __u32 status;
   
   if(initialise == true)
	{ 
      #ifdef DEBUG_INTERFACE
      cout << "<InterfacePeakNMEA2000::obtenirMessage()> ...\n";
      #endif
      
      fini = false;
      do
      {
         if (LINUX_CAN_Read(handle, &msg)) 
         {
            #ifdef DEBUG_INTERFACE
            //perror("LINUX_CAN_Read()");
            cerr << "<InterfacePeakNMEA2000::obtenirMessage()> erreur !\n";
            #endif
            return -1;
         }
         timestamp = time(NULL);
         
         #ifdef DEBUG_INTERFACE
         printf("<%u.%u> ", msg.dwTime, msg.wUsec);
         afficherMessage(&msg.Msg);
         #endif
          
         if (msg.Msg.MSGTYPE & MSGTYPE_STATUS) 
         {
            status = CAN_Status(handle);
            if ((int)status < 0) 
            {
                erreur = nGetLastError();
                #ifdef DEBUG_INTERFACE
                cerr << "<InterfacePeakNMEA2000::obtenirMessage()> erreur " << erreur << " !\n";
                //errno = nGetLastError();
                //perror("CAN_Status()");
                #endif
                return erreur;
            }
            #ifdef DEBUG_INTERFACE
            else
               printf("<InterfacePeakNMEA2000::obtenirMessage()> �tat CAN 0x%04x !\n", (__u16)status);
            #endif
         }
         
         pgnCourant = (msg.Msg.ID & 0x03FFFF00) >> 8;
         // ou :
         //pgnCourant = (msg.Msg.ID >> 8) & 0x03FFFF;
         if(pgnCourant == pgn)
            fini = true;
      }
      while(!fini);
      
      message = msg.Msg;
      
      return 0; // OK
   }
   #else
   do
   {
      simuler(message);
      timestamp = time(NULL);     

      #ifdef DEBUG_INTERFACE
      time_t ts = timestamp;
      printf("<%ld> %s ", timestamp, ctime(&ts));     
      afficherMessage(&message);
      #endif
      pgnCourant = (message.ID & 0x03FFFF00) >> 8;
      // ou :
      //pgnCourant = (message.ID >> 8) & 0x03FFFF;
      if(pgnCourant == pgn)
         fini = true;
   }
   while(!fini);   
   
   return 0; // OK
   #endif

   return -1;
}

void InterfacePeakNMEA2000::afficherMessage(TPCANMsg *m)
{
   int i;  
   int pgn = (m->ID & 0x03FFFF00) >> 8;
   
   #ifndef INTERFACE_SIMULATION
   printf("message %s %d 0x%08x %1d ", 
      (m->MSGTYPE & MSGTYPE_EXTENDED) ? "ext" : "std",
       pgn,
       m->ID, 
       m->LEN); 
   #else
   printf("message %d 0x%08x %1d ", 
       pgn,
       m->ID, 
       m->LEN); 
   #endif

   for (i = 0; i < m->LEN; i++)
    	printf("0x%02x ", m->DATA[i]);
    
   printf("\n");
}

void InterfacePeakNMEA2000::afficherInfos()
{
   #ifndef INTERFACE_SIMULATION
   TPDIAG diag;
   #ifdef DEBUG_INTERFACE
   int erreur = LINUX_CAN_Statistics(handle, &diag);
   if (erreur)
      printf("LINUX_CAN_Statistics : Erreur %d !\n", erreur);
   else      
   {
       printf("****************************************\n");
       if ((diag.wType == HW_USB) || (diag.wType == HW_USB_PRO))
       {
            printf("Numero de serie     = 0x%08x\n", diag.dwBase);
            printf("Numero de materiel  = %d\n",     diag.wIrqLevel);
       }
       printf("Nombre de lectures  = %d\n",     diag.dwReadCounter);
       printf("Nombre d'ecritures  = %d\n",     diag.dwWriteCounter);
       printf("Nombre d'erreurs    = %d\n",     diag.dwErrorCounter);
       printf("Etat CAN            = 0x%04x\n", diag.wErrorFlag);
       printf("Derniere erreur     = %d\n",     diag.nLastError);
       printf("Version du pilote   = %s\n",     diag.szVersionString);    
       printf("****************************************\n");
   }  
   #endif
   #endif
}

#ifdef INTERFACE_SIMULATION
void InterfacePeakNMEA2000::simuler(TPCANMsg &message)
{
   static int n = 1;

   // On simule la r�ception d'un message CAN
   message.LEN = 8;
   message.MSGTYPE = MSGTYPE_EXTENDED;
   message.DATA[0] = 0xFF; // SID
   if(n%6)
   {
      message.ID  = 130306 << 8; // PGN_VENT (10 trames /s)
      genererDonneesVent(message.DATA);
      message.DATA[5] = 0x02; // Wind Reference : 2 -> apparent
      message.DATA[6] = 0x1F; // Reserved
      message.DATA[7] = 0xFF; // Reserved
   }
   else
   {
      message.ID  = 130311 << 8; // PGN_ENVIRONNEMENT (2 trames /s)
      message.DATA[1] = 0x02; // Instance
      genererDonneesEnvironnement(message.DATA);
   }
   n++;
}

BYTE InterfacePeakNMEA2000::genererData()
{
  BYTE data;

  data = (rand() % 256);

  return data;
}

void InterfacePeakNMEA2000::genererDonneesVent(BYTE bData[8])
{
  float data;

  data = generer(0, 360);
  #ifdef DEBUG_INTERFACE
  printf("<simulation> direction vent : %.2f degres\n", data);
  #endif
  unsigned int datas = (unsigned int)(((data*M_PI)/180.)*10000.0);
  bData[4] = (datas & 0x0000FF00) >> 8;
  bData[3] = (datas & 0x000000FF);

  data = generer(0, 100);
  #ifdef DEBUG_INTERFACE
  printf("<simulation> vitesse vent : %.2f km/h\n", data);
  #endif
  datas = (unsigned int)((data*1000.*1000.)/(3600.*10.));
  bData[2] = (datas & 0x0000FF00) >> 8;
  bData[1] = (datas & 0x000000FF);
}

void InterfacePeakNMEA2000::genererDonneesEnvironnement(BYTE bData[8])
{
  float data = 0.;

  data = generer(20, 30);
  #ifdef DEBUG_INTERFACE
  printf("<simulation> temperature : %.2f Celcius\n", data);
  #endif
  unsigned int datas = (unsigned int)((data+273.15)/0.01);
  bData[3] = (datas & 0x0000FF00) >> 8;
  bData[2] = (datas & 0x000000FF);

  data = generer(0, 100);
  #ifdef DEBUG_INTERFACE
  printf("<simulation> humidite : %.2f %c\n", data, '%');
  #endif
  datas = (unsigned int)(data/0.004);
  bData[5] = (datas & 0x0000FF00) >> 8;
  bData[4] = (datas & 0x000000FF);

  data = generer(1000, 1200);
  #ifdef DEBUG_INTERFACE
  printf("<simulation> pression : %.2f Pa\n", data);
  #endif
  datas = (unsigned int)(data);
  bData[7] = (datas & 0x0000FF00) >> 8;
  bData[6] = (datas & 0x000000FF);
}

float InterfacePeakNMEA2000::generer(long min, long max)
{
    long   echantillon;
    float valeur;

    // simule des nombres apr�s la virgule
    min *= 100;
    max *= 100;
    echantillon = static_cast<long>(min + (static_cast<float>(qrand()) / RAND_MAX * (max - min + 1)));
    valeur = float(echantillon) / 100.;

    return valeur;
}
#endif
