#ifndef _ECHANGE_TCP
#define _ECHANGE_TCP

#include <stdio.h>
#include <string.h>
#include <sys/types.h>

ssize_t ecrireLigne(int sock, const void *buffer, size_t nb);
ssize_t ecrireDonnees(int sock, const void *buffer, size_t nb);

ssize_t lireLigne(int sock, void *buffer, size_t nbMax);
ssize_t lireDonnes(int sock, void *buffer, size_t nbMax);

#endif

