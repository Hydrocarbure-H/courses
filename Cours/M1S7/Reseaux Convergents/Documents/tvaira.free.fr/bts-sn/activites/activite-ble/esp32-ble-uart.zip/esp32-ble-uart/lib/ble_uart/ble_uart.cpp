#include "ble_uart.h"

ServeurBLEUART::ServeurBLEUART(
  String nomPeripherique /*=PERIPHERIQUE_BLUETOOTH_BLE*/) :
    BLEServerCallbacks(),
    nomPeripherique(nomPeripherique), serveurBLE(nullptr),
    pTxCharacteristic(nullptr), pRxCharacteristic(nullptr),
    pServiceUART(nullptr), connecte(false), tete(0), queue(0),
    delaiAdvertising(BLE_UART_DELAI_ADVERTISING)
{
}

void ServeurBLEUART::initialiser(
  String nomPeripherique /*=PERIPHERIQUE_BLUETOOTH_BLE*/)
{
    if(this->nomPeripherique != nomPeripherique)
        this->nomPeripherique = nomPeripherique;
#ifdef DEBUG_BLE_UART
    Serial.print("BLE UART : initialisation ");
    Serial.println(this->nomPeripherique);
#endif
    BLEDevice::init(this->nomPeripherique.c_str());
    // BLEDevice::getAddress();
    this->serveurBLE = BLEDevice::createServer();
    serveurBLE->setCallbacks(this);

    pServiceUART = serveurBLE->createService(SERVICE_UART_UUID);
    pTxCharacteristic =
      pServiceUART->createCharacteristic(CHARACTERISTIC_UUID_TX,
                                         BLECharacteristic::PROPERTY_NOTIFY);
    pTxCharacteristic->addDescriptor(new BLE2902());
    // cf. BLECharacteristic::PROPERTY_READ pour l'écho
    pRxCharacteristic =
      pServiceUART->createCharacteristic(CHARACTERISTIC_UUID_RX,
                                         BLECharacteristic::PROPERTY_WRITE);
    pRxCharacteristic->setCallbacks(new CharacteristicUART(this));
}

void ServeurBLEUART::demarrer()
{
#ifdef DEBUG_BLE_UART
    Serial.println("UART Over BLE : démarrage");
#endif

    pServiceUART->start();
}

void ServeurBLEUART::diffuser(uint32_t ms/*=BLE_UART_DELAI_ADVERTISING*/)
{
    if(!estConnecte())
    {
        delay(delaiAdvertising);
        serveurBLE->getAdvertising()->start();
// ou
/*BLEAdvertising* pAdvertising = BLEDevice::getAdvertising();
pAdvertising->addServiceUUID(pServiceUART->getUUID());
pAdvertising->setScanResponse(true);
pAdvertising->setMinPreferred(
0x06); // functions that help with iPhone connections issue
pAdvertising->setMaxPreferred(0x12);
BLEDevice::startAdvertising();*/
#ifdef DEBUG_BLE_UART
        Serial.println(
          "BLE UART : démarrage advertising et attente connexion ...");
#endif
    }
}

bool ServeurBLEUART::estConnecte() const
{
    return connecte;
}

void ServeurBLEUART::setDelaiAdvertising(uint32_t ms)
{
    delaiAdvertising = ms;
}

void ServeurBLEUART::onConnect(BLEServer* pServer)
{
#ifdef DEBUG_BLE_UART
    Serial.println("BLE UART : connexion");
#endif
    connecte = true;
}

void ServeurBLEUART::onDisconnect(BLEServer* pServer)
{
#ifdef DEBUG_BLE_UART
    Serial.println("BLE UART : déconnexion");
#endif
    connecte = false;
}

void ServeurBLEUART::envoyer(String trame)
{
    if(estConnecte() && !trame.isEmpty())
    {
#ifdef DEBUG_BLE_UART
        Serial.println("BLE UART : émission");
        Serial.println(trame);
#endif
        pTxCharacteristic->setValue(std::string(trame.c_str()));
        pTxCharacteristic->notify();
    }
}

bool ServeurBLEUART::recevoir(String& trame,
                              char    delimiteur /*=BLE_UART_DELIMITEUR_FIN*/)
{
    if(estConnecte() && estDisponible())
    {
        trame.clear();
        trame = readStringUntil('\n');
#ifdef DEBUG_BLE_UART
        Serial.print("< ");
        Serial.println(trame);
#endif
        trame.concat(BLE_UART_DELIMITEUR_FIN); // remet le DELIMITEUR_FIN
        return true;
    }

    return false;
}

size_t ServeurBLEUART::estDisponible() const
{
    return ((size_t)(BLE_UART_TAILLE_BUFFER_RECEPTION + tete - queue)) %
           BLE_UART_TAILLE_BUFFER_RECEPTION;
}

String ServeurBLEUART::readStringUntil(
  char delimiteur /*=BLE_UART_DELIMITEUR_FIN*/)
{
    String donnees;

    int c = lireBuffer();
    while(c >= 0 && c != (int)delimiteur)
    {
        donnees += (char)c;
        c = lireBuffer();
    }
    return donnees;
}

bool ServeurBLEUART::estEcheance(unsigned long intervalle)
{
    static unsigned long tempsPrecedent = millis();
    unsigned long        temps          = millis();
    if(temps - tempsPrecedent >= intervalle)
    {
        tempsPrecedent = temps;
        return true;
    }
    return false;
}

int ServeurBLEUART::lireBuffer()
{
    // buffer vide ?
    if(tete == queue)
    {
        return -1;
    }
    else
    {
        uint8_t c = buffer[queue];
        queue     = (uint8_t)(queue + 1) % BLE_UART_TAILLE_BUFFER_RECEPTION;
        return (int)c;
    }
}

void ServeurBLEUART::ecrireBuffer(char c)
{
    uint8_t i = (tete + 1) % BLE_UART_TAILLE_BUFFER_RECEPTION;
    // buffer plein ?
    if(i == queue)
        return;
    buffer[tete] = (uint8_t)c;
    tete         = i;
}

CharacteristicUART::CharacteristicUART(ServeurBLEUART* ServeurBLEUART) :
    BLECharacteristicCallbacks(), serveurBLEUART(ServeurBLEUART)
{
}

void CharacteristicUART::onWrite(BLECharacteristic* pCharacteristique)
{
    std::string donnees = pCharacteristique->getValue();

    if(donnees.length() > 0)
    {
#ifdef DEBUG_BLE_UART_Characteristic
        Serial.print("Reception : ");
        Serial.print(donnees.c_str());
        Serial.println();
#endif
        for(int i = 0; i < donnees.length(); i++)
        {
            serveurBLEUART->ecrireBuffer(donnees[i]);
        }
    }
}
