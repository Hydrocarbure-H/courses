#include <iostream>
#include <math.h>

using namespace std;

#include "Point.h"

