#ifndef MAFENETRE_H
#define MAFENETRE_H

#include <QtGui>
#include <QFileInfo>
#include <QSettings>
#include <QMessageBox>
#include <QDebug>

// Des données
typedef struct
{
    QString         adresseIP;
    int             port;
} CONNEXION;

class MaFenetre : public QWidget
{
    Q_OBJECT
public:
    explicit MaFenetre(QWidget *parent = 0);
    ~MaFenetre();
    
private:
    QLabel *labelAdresseIP;
    QLabel *labelPort;
    QLineEdit *editAdresseIP;
    QLineEdit *editPort;
    CONNEXION connexion;

    bool lireINI();
    void ecrireINI();
    bool estFichier(const QString &file);

signals:
    
public slots:
    
};

#endif // MAFENETRE_H
