#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>

#define DEBUG // pour voir les valeurs des sémaphores

typedef enum { NOIR, ROUGE, VERT, MARRON, BLEU, FUSHIA, CYAN, GRIS, NB_COULEURS } Couleur;
typedef enum { NORMAL, SOFTEN, NORMAL1, NORMAL2, SOULIGNE, BLINK, NORMAL3, INVERT } Mode;

#define RESET_TERM()                printf("\x1b[0m")
#define SET_BGCOLOR(color)          printf("\x1b[1;37;4%dm",color)
#define SET_COLOR(color) 	        printf("\x1b[0;3%dm",color)
#define SET_MODECOLOR(mode,color)	printf("\x1b[%d;3%dm",mode,color)
#define SETCOLOR_SUCCESS()          printf("\x1b[1;32m")
#define SETCOLOR_FAILURE()          printf("\x1b[5;31m")
#define SETCOLOR_ERROR()            printf("\x1b[1;31m")
#define SETCOLOR_WARNING()          printf("\x1b[1;34m")
#define SETCOLOR_INFO()             printf("\x1b[0;37m")
#define SETCOLOR_NORMAL()           printf("\x1b[0;39m")
#define MOVE_TO_COL(col)	        printf("\x1B[%dG",col)
#define MOVE_XY(x,y)			    printf("\x1B[%d;%dH",x,y)
#define CLEAR_LINE(x,y)			    printf("\x1B[%d;%dH\x1b[2K",x,y)
#define RESET()					    printf("\x1B[2J")

static int SECOND = 1000000; // pour usleep

// Taille de la salle d'attente
#define NB_PLACES 5

// Prix d'une coupe
#define PRIX 20

// Pour simuler un flot de clients
#define MIN_CLIENTS 4
#define MAX_CLIENTS 12
#define MIN_TEMPS   50  // en ms
#define MAX_TEMPS   150 // en ms

// Les ressources de synchronisation
pthread_mutex_t mutexEcran = PTHREAD_MUTEX_INITIALIZER;




// Caisse du coiffeur
int caisse = 0;
int manqueAGagner = 0;
char *nomClient;

// Gestion des sémaphores
void Init(sem_t *s, unsigned int value);
void P(sem_t *s);
void V(sem_t *s);
int  getValue(sem_t *s);

// Les threads
void *threadCoiffeur(void *ptr);
void *threadClient(void *ptr);

// Fonctions de services
void coiffer();
void payer(char *nom);
void partir(char *nom);
int nbChiffres(int nombre);

// Code source
void coiffer()
{
    pthread_mutex_lock(&mutexEcran);
    SET_COLOR(ROUGE);
    printf("# Coiffeur : je coiffe le client %s\n", nomClient);
    RESET_TERM();
    pthread_mutex_unlock(&mutexEcran);
    
    usleep(0.5*SECOND);	// je coiffe ...

    pthread_mutex_lock(&mutexEcran);
    SET_COLOR(ROUGE);
    printf("# Coiffeur : j'ai fini le client %s\n", nomClient);
    RESET_TERM();
    pthread_mutex_unlock(&mutexEcran);
}

void seFaireCoiffer(char *nom)
{
    
    SET_COLOR(VERT);
    printf("@ %s : Je m'assoie sur le fauteuil pour me faire coiffer.\n", nom);
    RESET_TERM();
    
}

void attendreClient()
{
    
    int porteMonnaie = caisse;
    
    int perte = manqueAGagner;
    

    pthread_mutex_lock(&mutexEcran);
    SET_COLOR(ROUGE);
    printf("# Coiffeur : je vais me reposer, %i euros pour l'instant.\n", porteMonnaie);
    printf("# Coiffeur : manque à gagner %d euros :(\n", perte);
    RESET_TERM();
    pthread_mutex_unlock(&mutexEcran);
}

void attendreCoiffeur(char *nom)
{
    
    pthread_mutex_lock(&mutexEcran);
    SET_COLOR(VERT);
    printf("@ %s : J'attends sur une chaise\n", nom);
    RESET_TERM();
    pthread_mutex_unlock(&mutexEcran);
    
}

void payer(char *nom)
{

    caisse += PRIX;


    pthread_mutex_lock(&mutexEcran);
    SET_COLOR(VERT);
    printf("@ %s : Je paie %d euros\n", nom, PRIX);
    RESET_TERM();
    pthread_mutex_unlock(&mutexEcran);
}

void partir(char *nom)
{

    manqueAGagner += PRIX;


    pthread_mutex_lock(&mutexEcran);
    SET_COLOR(VERT);
    printf("@ %s : Je n'ai pas de place pour attendre ! je pars\n", nom);
    RESET_TERM();
    pthread_mutex_unlock(&mutexEcran);
}

void *threadCoiffeur(void *ptr)
{
	

    return NULL;
}

void *threadClient(void *ptr)
{
	

    return NULL;
}

int main(void)
{
	pthread_t tidCoiffeur;
	pthread_t *tidClient;
	int nbClients = 0;
	char* client; // le nom du client

    /* Initialisation */
    setbuf(stdout, NULL);
	srand(time(NULL));
    RESET_TERM();    

    /* Initialisation des ressources */
	

    SET_COLOR(CYAN);
    printf("Ouverture du salon\n");
    RESET_TERM();
    
	/* On demarre le coiffeur */
	pthread_create(&tidCoiffeur, NULL, (void*)&threadCoiffeur, NULL);    
    
    SET_COLOR(CYAN);
    printf("Appuyez sur la touche Entrée pour lancer un flot de clients\n");
    RESET_TERM();
    
	while(1)
	{	
		getchar();
		
		int nbClientsAVenir =  MIN_CLIENTS + (int) ((double) rand() * (MAX_CLIENTS - MIN_CLIENTS + 1.0 ) / (RAND_MAX+1.0));

        #ifdef DEBUG
        pthread_mutex_lock(&mutexEcran);
		SET_COLOR(BLEU);
		printf("\tNombre de clients à venir = %d\n", nbClientsAVenir);
		RESET_TERM();
        pthread_mutex_unlock(&mutexEcran);
        #endif

        int arrivee; // simulation d'un temps d'arrivée
		for(int i=0;i<nbClientsAVenir;i++)
        {	
			arrivee = MIN_TEMPS + (int)((double) rand() * (MAX_TEMPS - MIN_TEMPS + 1.0 ) / (RAND_MAX+1.0));
			usleep(arrivee*1000);

            nbClients++;

            client = malloc((strlen("client-")+nbChiffres(nbClients))*sizeof(char)+1);
			sprintf(client, "client-%d", nbClients);

            pthread_mutex_lock(&mutexEcran);
            SET_COLOR(CYAN);
			printf("Nouveau Client : %s\n", client);
            RESET_TERM();
            pthread_mutex_unlock(&mutexEcran);
            
            tidClient = (pthread_t *)malloc(sizeof(pthread_t));
			pthread_create(tidClient, NULL, threadClient, client);
		}
	}
    
	pthread_join(tidCoiffeur, NULL);
    
	return 0;
}

void Init(sem_t *s, unsigned int value)
{
   sem_init(s, 0, value);
}

void P(sem_t *s)
{
   sem_wait(s);
}

void V(sem_t *s)
{
   sem_post(s);
}

int getValue(sem_t *s)
{
   int sval;
   
   sem_getvalue(s, &sval);

   return sval;
}

int nbChiffres(int nombre)
{
	if(nombre < 10)
		return 1;
	else
		return 1+nbChiffres(nombre/10);
}
