#include <stdio.h>
#include <stdlib.h> /* pour exit et atoi */
#include <unistd.h> /* pour close */
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h> /* pour memset */
#include <netinet/in.h> /* pour struct sockaddr_in */
#include <arpa/inet.h> /* pour htons et inet_aton */
#include <netdb.h> /* pour getaddrinfo */

#include "echange-tcp.h"

#define LG_MESSAGE   256

int main(int argc, char *argv[])
{
   int descripteurSocket;
   char messageEnvoi[LG_MESSAGE]; /* le message de la couche Application ! */  
   char messageRecu[LG_MESSAGE]; /* le message de la couche Application ! */  
   int ecrit, lu; /* nb d'octets ecrits et lus */
   int retour;
   struct addrinfo hints;
   struct addrinfo *result, *rp;

   // Il faut 2 arguments à ce programme : l'adresse ip et le numéro de port du serveur
   if (argc != 3)
   {
      fprintf(stderr, "Erreur : argument manquant !\n"); 
      fprintf(stderr, "Usage : %s adresse_ip numero_port\n", argv[0]); 
      exit(-1); // On sort en indiquant un code erreur
   }
   
   // Obtenir un point de communication distant correspondant au couple nom/port fourni en argument
   memset(&hints, 0, sizeof(struct addrinfo));
   hints.ai_family = PF_INET;    // sinon AF_UNSPEC pour IPv4 ou IPv6
   hints.ai_socktype = SOCK_STREAM; // mode connecté
   hints.ai_flags = 0; // options supplémentaires, ici aucune
   hints.ai_protocol = 0; // n'importe quel type

   retour = getaddrinfo(argv[1], argv[2], &hints, &result);
   if (retour != 0) 
   {
      fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(retour)); // Affiche le message d'erreur
      exit(-2); // On sort en indiquant un code erreur
   }
   
   // getaddrinfo() retourne une liste de structures d'adresses 
   // on cherche la première qui permettra un connect()
   for (rp = result; rp != NULL; rp = rp->ai_next) 
   {
      // Crée un socket de communication 
      descripteurSocket = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);

      // Échec ?
      if (descripteurSocket == -1)
         continue; // alors on essaye la suivante

      // Débute la connexion vers le processus serveur distant
      // Ok ?
      if((connect(descripteurSocket, rp->ai_addr, rp->ai_addrlen)) != -1)
         break; // on a trouvé une adresse valide !

      // On ferme cette ressource avant de passer à la suivante
      close(descripteurSocket);
   }

   if (rp == NULL) 
   {               
      // on a donc trouvé aucune adresse valide !
      fprintf(stderr, "Impossible de se connecter à cette adresse !\n");
      exit(-3); // On sort en indiquant un code erreur
   }

   freeaddrinfo(result); // on libère les résultats obtenus et on continue ...
   
   printf("Socket créée avec succès ! (%d)\n", descripteurSocket);
   printf("Connexion au serveur réussie avec succès !\n\n");
   
   // Initialise à 0 les messages
   memset(messageEnvoi, 0x00, LG_MESSAGE*sizeof(char));
   memset(messageRecu, 0x00, LG_MESSAGE*sizeof(char));
   
   // TODO : Envoie une requête HTTP message au serveur et lit la réponse reçue
   
   
   // On ferme la ressource avant de quitter
   close(descripteurSocket);

   return 0;
}
