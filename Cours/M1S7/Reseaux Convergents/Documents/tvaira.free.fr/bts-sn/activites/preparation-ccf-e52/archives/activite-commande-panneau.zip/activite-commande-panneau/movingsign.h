#ifndef MOVINGSIGN_H
#define MOVINGSIGN_H

// Correspondances des caracteres speciaux
#define CARACTERE_NUL               0x00
#define CARACTERE_E_ACCENT_AIGU     0xE9
#define CARACTERE_E_ACCENT_GRAVE    0xE8
#define OCTET_E_ACCENT_AIGU         0x83
#define OCTET_E_ACCENT_GRAVE        0x8B
#define CARACTERE_RETOUR_A_LA_LIGNE '#'
#define OCTET_RETOUR_A_LA_LIGNE     0x7F
#define CARACTERE_TEMPERATURE       0x2A //'*'
#define OCTET_TEMPERATURE           0x0B
#define CARACTERE_DEGRE             0xB0
#define OCTET_DEGRE                 0x80
#define CARACTERE_C_CEDILLE         0xE7
#define OCTET_C_CEDILLE             0xE7
#define CARACTERE_A_ACCENT          0xE0
#define OCTET_A_ACCENT              0x86

const char NUL = 0x00;
const char SOH = 0x01;
const char STX = 0x02;
const char ETX = 0x03;
const char EOT = 0x04;

const char WRITE_SPECIAL_FUNCTION_COMMAND = 'W';
const char WRITE_TEXT_COMMAND = 'A';
const char NUMBER_MESSAGES_SUB_COMMAND = 'N';

const QString SENDER_ADDRESS = "FF";
const QString RECEIVER_ADDRESS = "00";

const char VIRTUAL_FILE = '0';
const char ADDING_FONT = 0x0F;
const QString PREPARATION = "000";
const QString CHECKSUM = "0000";

const QString DISPLAY_DAYS = "7F";
const QString BEGINNING_DATE_DISPLAY = "00000000";
const QString END_DATE_DISPLAY = "00000000";
const QString BEGINNING_TIME_DISPLAY = "0000";
const QString END_TIME_DISPLAY = "0000";


class DISPLAY_MOD
{
    public:
    enum {
    AUTOMATIC = 'A',
    FLASH_1 = 'B',
    FIX = 'C',
    SWITCH_RIGHT_LEFT= 'D',
    ROLLUP = 'E',
    ROLLDOWN= 'F',
    ROLLOUT = 'G',
    ROLLIN = 'H',
    SRCOLLING = 'I',
    ROLLLEFT = 'J',
    ROLLRIGHT= 'K',
    SLIDE = 'L',
    SNOW = 'M',
    DISSOLUTION = 'N',
    SPRAY = 'O',
    SPARKLE = 'P',
    SWITCH_UP_DOWN = 'Q',
    FLASH_2 = 'R',
    WIPEUP = 'S',
    WIPEDOWN= 'T',
    WIPEOUT = 'U',
    WIPEIN = 'V',
    WIPERIGHT = 'W',
    WIPELEFT = 'X',
    TWINKLE = 'Y',
    PROGRESSIVE_WIPE = 'Z'
    };
};

class DISPLAY_SPEED
{
    public:
    enum {
    FASTER = '1',
    FAST = '2',
    NORMAL = '3',
    SLOW = '4',
    SLOWER = '5'
    };
};

class TIME_PAUSE
{
    public:
    enum {
    NEITHER = '0',
    SHORTEST = '1',
    VERY_SHORTER = '2',
    SHORTER = '3',
    SHORT = '4',
    NORMAL = '5',
    LONG = '6',
    LONGER = '7',
    VERY_LONGER = '8',
    LONGEST = '9'
    };
};

class ALIGNMENT
{
    public:
    enum {
    LEFT = '1',
    RIGHT = '2',
    CENTER = '3',
    };
};

class FONT
{
    public:
    enum {
    SMALL = 'A',
    SMALL_BOLD = 'B',
    SMALL_WIDE = 'C',
    SMALL_WIDE_BOLD = 'D',
    SMALL_SHORT = '@',

    NORMAL = 'E',
    NORMAL_BOLD = 'F',
    NORMAL_WIDE = 'G',
    NORMAL_WIDE_BOLD = 'H',

    NORMAL_DISCARDED = 'I',
    NORMAL_DISCARDED_BOLD = 'J',
    NORMAL_DISCARDED_BOLDER = 'K',
    NORMAL_DISCARDED_WIDE = 'L',
    NORMAL_DISCARDED_WIDE_BOLD = 'M',
    NORMAL_MORE_DISCARDED_BOLD = 'N',

    BIG = 'O',
    BIG_BOLD = 'P',
    BIG_WIDE = 'Q',
    BIG_WIDE_BOLD = 'R',

    BIGGER = 'S',
    BIGGER_BOLD= 'T',
    BIGGER_WIDE = 'U',
    BIGGER_WIDE_BOLD = 'V',
    };
};

#endif // MOVINGSIGN_H
