#ifndef ISBN_H
#define ISBN_H

#include <iostream>

/*
   L'International Standard Book Number (ISBN) ou Numéro international normalisé du livre (NINL) est un numéro international qui permet d'identifier, de manière unique, chaque édition de chaque livre publié, que son support soit numérique ou sur papier. Il est destiné à simplifier la gestion informatique pour tous les intervenants de la chaîne du livre (imprimeur, éditeur, libraire, bibliothèque, etc.).
*/

#define ISBN_10   10
#define ISBN_13   13

class ISBN
{
   private:
      std::string isbn;
      
      bool estValide10(const std::string &isbn) const;
      bool estValide13(const std::string &isbn) const;      
      
   public:
      ISBN();
      ISBN(const std::string &isbn);
      
      void setISBN(const std::string &isbn);
      std::string getISBN() const;
      int getTaille() const;
      int getTaille(const std::string &isbn) const;
      
      bool estValide() const;
      bool estValide(const std::string &isbn) const;
      std::string nettoie(const std::string &isbn) const;
};

#endif
