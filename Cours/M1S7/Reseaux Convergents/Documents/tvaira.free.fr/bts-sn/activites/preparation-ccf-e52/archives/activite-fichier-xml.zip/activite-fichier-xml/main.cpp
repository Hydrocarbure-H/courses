#include <QApplication>
#include <QTextCodec>
#include "mafenetre.h"

int main( int argc, char **argv )
{
    QApplication a( argc, argv );
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));

    a.setApplicationName("activite-fichier-xml");

    MaFenetre maFenetre;

    maFenetre.show();

    return a.exec();
}
