#include <iostream>
#include <vector>

using namespace std;

int main() 
{
  vector<int> v2(4, 100); // un vecteur de 4 entiers initialisés avec la valeur 100

  cout << "Le vecteur v2 contient " << v2.size() << " entiers : ";
  
  // utilisation d'un itérateur pour parcourir le vecteur v2
  for (vector<int>::iterator it = v2.begin(); it != v2.end(); ++it)
    cout << ' ' << *it;
  cout << '\n'; 
  
  return 0;
}

