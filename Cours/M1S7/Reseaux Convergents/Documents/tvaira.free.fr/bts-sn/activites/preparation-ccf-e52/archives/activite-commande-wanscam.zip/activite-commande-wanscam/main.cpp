#include <QApplication>
#include <QTextCodec>
#include "ihm.h"

int main( int argc, char **argv )
{
    QApplication a( argc, argv );
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));

    IHM ihm;
    ihm.show();

    return a.exec();
}
