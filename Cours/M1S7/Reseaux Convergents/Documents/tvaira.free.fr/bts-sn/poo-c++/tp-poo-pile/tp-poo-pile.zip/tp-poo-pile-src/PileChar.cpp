#include <iostream>
#include <cstring>

using namespace std;

#include "PileChar.h"

PileChar::PileChar(int taille) : max(taille), sommet(0), pile(0)
{   
   // TODO : allocation dynamique du tableau de caractère
    
   #ifdef DEBUG
   cout << "PileChar(" << taille << ") : " << this << "\n";
   #endif
}


PileChar::~PileChar()
{
   // TODO : libération de la mémoire allouée pour la pile
   
   #ifdef DEBUG
   cout << "~PileChar() : " << this << "\n";
   #endif
}
