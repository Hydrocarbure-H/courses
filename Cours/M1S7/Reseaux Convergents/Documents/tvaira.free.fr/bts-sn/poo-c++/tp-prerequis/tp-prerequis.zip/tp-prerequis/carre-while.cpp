// Calcule et affiche le carré d'un nombre (while)

#include <iostream>
#include <cmath>

using namespace std;

int main()
{
   int i = 0; // commencer à 0

   // tant que i est inférieur strict à 100 : on s'arrête quand i a atteint la valeur 100
   while (i < 100)
   {
      cout << i << '\t' << pow(i, 2) << '\n'; // affiche i et son carré séparés par une tabulation
      ++i; // on incrémente le nombre et on recommence
   }
      
   return 0;
}
