#ifndef PORT_XBEE_H
#define PORT_XBEE_H

/*
 * 
 * 
 */

#include <cstdio> 
#include <errno.h> 
#include <termios.h> 
#include <cstdlib>
#include <cstring> 
#include <unistd.h>
#include <sys/ioctl.h> 
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/signal.h>
#include <fcntl.h> 

#define DEBUG_PORTXBEE

#define PORT            "/dev/ttyUSB0"

#define LG_MAX_TRAME    96

// cf. man ascii
#define NUL             0x00 // caractère NUL (c'est aussi le code du fin de chaîne)

#define DELAI           1000000 // en micro secondes

/*
 * MODE AP=1 : ATAP=1
 */

class PortXbee
{
    public:
        PortXbee();
        ~PortXbee();
        bool ouvrir(const char *nomPort);
        void fermer();
        int  envoyer(char myid[2], char *donnees, int nb);
        int  recevoir(char *donnees, int nb);
        unsigned char calculerChecksum(char *trame);
        bool estOuvert();
        
    private:
        bool ouvert;
        int  xbeefd;
        struct termios  termios_p;
        char trame[LG_MAX_TRAME];
};

#endif //PORT_XBEE_H
