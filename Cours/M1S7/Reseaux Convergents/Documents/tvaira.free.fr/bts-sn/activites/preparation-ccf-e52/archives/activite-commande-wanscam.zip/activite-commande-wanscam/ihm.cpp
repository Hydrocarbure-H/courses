#include "ihm.h"

IHM::IHM( QWidget *parent ) : QWidget( parent )
{
    // les widgets       
    labelAdresseIP = new QLabel(this);
    labelAdresseIP->setText(QString::fromUtf8("Adresse IP : "));
    leAdresseIP = new QLineEdit(this);
    leAdresseIP->setFixedWidth(150);
    labelPort = new QLabel(this);
    labelPort->setText(QString::fromUtf8("Port : "));
    lePort = new QLineEdit(this);
    lePort->setFixedWidth(150);
    bInfos  = new QPushButton(QString::fromUtf8("Infos"), this);

    bRight  = new QPushButton(QString::fromUtf8("Right"), this);

    journal = new QTextEdit(this);
    journal->setReadOnly(true);

    // mise ne place des layout
    QHBoxLayout *hLayout0 = new QHBoxLayout;
    QHBoxLayout *hLayout1 = new QHBoxLayout;
    QHBoxLayout *hLayout2 = new QHBoxLayout;
    QVBoxLayout *mainLayout = new QVBoxLayout;

    hLayout0->addWidget(labelAdresseIP);
    hLayout0->addWidget(leAdresseIP);
    hLayout0->addWidget(labelPort);
    hLayout0->addWidget(lePort);
    hLayout0->addWidget(bInfos);

    hLayout0->addStretch();

    hLayout1->addWidget(bRight);

    hLayout1->addStretch();

    hLayout2->addWidget(journal);

    mainLayout->addLayout(hLayout0);
    mainLayout->addLayout(hLayout1);
    mainLayout->addLayout(hLayout2);
    mainLayout->addStretch(1);
    setLayout(mainLayout);

    // intialisation
    lireParametres();

    setWindowTitle(QString::fromUtf8("Commande Wanscam JW008"));
    setFixedHeight(sizeHint().height());
    setFixedWidth(sizeHint().width());

    // les signaux/slots

    connect(bInfos, SIGNAL(clicked()), this, SLOT(demanderInfos()));
    connect(bRight, SIGNAL(clicked()), this, SLOT(right()));

    manager = new QNetworkAccessManager(this);
    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(replyFinished(QNetworkReply*)));
}

IHM::~IHM()
{

}

void IHM::quitter()
{
    emit quit();
}

void IHM::lireParametres()
{
    QSettings parametres("wanscam.ini", QSettings::IniFormat);

    adresseIP = parametres.value("wanscam/adresse", "192.168.52.14").toString();
    port = parametres.value("wanscam/port", "99").toInt();
    user = parametres.value("wanscam/user", "admin").toString();
    pwd = parametres.value("wanscam/pwd", "").toString();

    #ifdef DEBUG_IHM
    qDebug() << QString::fromUtf8("<IHM::lireParametres()> adresse ip : %1").arg(adresseIP);
    qDebug() << QString::fromUtf8("<IHM::lireParametres()> port : %1").arg(port);
    qDebug() << QString::fromUtf8("<IHM::lireParametres()> user : %1").arg(user);
    qDebug() << QString::fromUtf8("<IHM::lireParametres()> password : %1").arg(pwd);
    #endif
}

void IHM::demanderInfos()
{
    QString URL = "http://" + adresseIP + ":" + QString::number(port) + "/get_status.cgi" + "?user=" + user + "&pwd=" + pwd;
    manager->get(QNetworkRequest(QUrl(URL)));
}

void IHM::right()
{
    QString URL = "http://" + adresseIP + ":" + QString::number(port) + "/decoder_control.cgi?command=4&onestep=1" + "&user=" + user + "&pwd=" + pwd;
    manager->get(QNetworkRequest(QUrl(URL)));
}

void IHM::replyFinished(QNetworkReply *reply)
{
    qDebug() << QString::fromUtf8("<IHM::replyFinished()> url : ") << reply->url().toString();
    qDebug() << QString::fromUtf8("<IHM::replyFinished()> octets : ") << reply->bytesAvailable();
}
