#ifndef _PUPITRE_CONDUCTEUR_H
#define _PUPITRE_CONDUCTEUR_H

#include "qtp.h"

#define SIMULATION_PUPITRE

#define LG_CODE	4

class PupitreConducteur 
{
    public:
        PupitreConducteur(QString port = "/dev/ttyUSB0");
        ~PupitreConducteur();
        
       void  gererMenuService();
       void  afficherMenuPrincipal();
       void  quitter();
       void  afficherMessage(char messages[][LG_LIGNE+1]);
       void  effacer();

    private:
        QTP  *qtp;

        char lireTouche(char *touche, int nbchar, int mode);
};

#endif // _PUPITRE_CONDUCTEUR_H
