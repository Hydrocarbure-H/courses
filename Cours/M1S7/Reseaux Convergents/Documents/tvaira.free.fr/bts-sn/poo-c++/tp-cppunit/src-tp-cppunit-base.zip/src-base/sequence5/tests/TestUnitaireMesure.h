#ifndef _TESTUNITAIREMESURE_H
#define _TESTUNITAIREMESURE_H

#include <cppunit/extensions/HelperMacros.h>

class Mesure; // La classe à tester

class TestUnitaireMesure : public CPPUNIT_NS::TestFixture
{
  // On crée une suite de tests unitaires pour la classe 
  CPPUNIT_TEST_SUITE( TestUnitaireMesure );
  CPPUNIT_TEST( testReinitialiser ) ;
  CPPUNIT_TEST( testAjouterEchantillons ) ;
  CPPUNIT_TEST( testTriTaillePaire ) ;
  CPPUNIT_TEST( testTriTailleImpaire ) ;
  CPPUNIT_TEST( testTriDejaTrie ) ;  
  //CPPUNIT_TEST( testMesureMax ) ; // cf. sequence 2
  //CPPUNIT_TEST( testMesure ) ; // cf. sequence 2 
  // TODO : etc ...
  CPPUNIT_TEST( testNbEchantillons ) ;  
  CPPUNIT_TEST_SUITE_END();

private:
   Mesure *mesure; // un pointeur sur une instance de la classe à tester
   
public:
   TestUnitaireMesure();
   virtual ~TestUnitaireMesure();

   // Call before tests
   void setUp();
   
   // Call after tests
   void tearDown();
        
   // Liste des tests
   void testReinitialiser();
   void testAjouterEchantillons();
   void testTriTaillePaire();
   void testTriTailleImpaire();
   void testTriDejaTrie();   
   void testMesureMax(); // cf. sequence 2  
   void testMesure(); // cf. sequence 2  
   // TODO : séquence 5
   void testNbEchantillons();
};

#endif
