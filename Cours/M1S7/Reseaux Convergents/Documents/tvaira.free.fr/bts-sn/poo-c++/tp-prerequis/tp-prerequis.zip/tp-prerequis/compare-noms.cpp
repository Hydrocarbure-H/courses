#include <iostream>

using namespace std;

int main()
{
    cout << "Donnez deux noms :\n";    
    string premier;
    string second;
    cin >> premier >> second; // Lit deux chaînes
    if (premier == second) cout << "Les deux noms sont identiques.\n";
    if (premier < second)
        cout << premier << " est avant " << second <<'\n';
    if (premier > second)
        cout << premier << " est après " << second <<'\n';
    
    return 0;
}
