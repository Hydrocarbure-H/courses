/**
*
* @file lib/monserveur/monserveur.cpp
*
* @brief Définition de la classe MonServeur
*
* @author Thierry Vaira
*
* @version 0.1
*
*/
#include <monserveur.h>

/**
* @brief Constructeur de la classe MonServeur
*
* @fn MonServeur::MonServeur
*
* @param port uint16_t numéro de port du serveur (5000 par défaut)
*/
MonServeur::MonServeur(uint16_t port) : WiFiServer(port), port(port), periode(PERIODE_ENVOI_DEFAUT), tempsPrecedent(0), dhcp(true), debug(true)
{
  this->requete.traite = true;
}

String MonServeur::getPort() const
{
  char strPort[16];
  sprintf(strPort, "%u", port);
  return String(strPort);
}

String MonServeur::getAdresseIP() const
{
  return adresseIP;
}

/**
* @brief Accesseur get du membre periode
*
* @fn MonServeur::getPeriode
*
* @return periode unsigned long la période d'envoi en millisecondes
*/
unsigned long MonServeur::getPeriode() const
{
  return periode;
}

/**
* @brief Mutateur set du membre periode
*
* @fn MonServeur::setPeriode
*
* @param periode unsigned long la nouvelle période d'envoi en millisecondes
*/
void MonServeur::setPeriode(unsigned long periode)
{
  this->periode = periode;
}

/**
* @brief Mutateur set du mode débogage
*
* @fn MonServeur::setDebug
*
* @param debug bool active ou non le mode débogage
*/
void MonServeur::setDebug(bool debug)
{
  this->debug = debug;
}

/**
* @brief Configure une adresse statique
*
* @fn MonServeur::configurer
*
* @param monAdresseIP IPAddress l'adresse IP statique
* @param maPasserelle IPAddress l'adresse IP du routeur par défaut
* @param monMasque IPAddress le masque de sous-réseau
* @param monDNSPrimaire IPAddress l'adresse IP du serveur DNS primaire à contacter
* @param monDNSSecondaire IPAddress l'adresse IP du serveur DNS secondaire à contacter (optionnel)
*/
void MonServeur::configurer(IPAddress monAdresseIP, IPAddress maPasserelle, IPAddress monMasque, IPAddress monDNSPrimaire, IPAddress monDNSSecondaire)
{
  this->monAdresseIP = monAdresseIP;
  this->maPasserelle = maPasserelle;
  this->monMasque = monMasque;
  this->monDNSPrimaire = monDNSPrimaire;
  this->monDNSSecondaire = monDNSSecondaire;
  dhcp = false;
}

/**
* @brief Démarre le serveur TCP via un réseau WiFi
*
* @fn MonServeur::demarrer
*
* @param ssid const char* le SSID du réseau WiFi à joindre
* @param password const char* le mot de passe associé au SSID
*/
void MonServeur::demarrer(const char *ssid, const char *password)
{
  int n = -1;
  do
  {
    n = detecterWLAN(ssid, password);
    if(n == 0)
    {
      activerWifi();
    }
    else if(n > 0)
    {
      if(selectionnerWLAN(n, ssid, password))
        activerWifi();
    }
    else
    {
      //Serial.print(".");
      delay(500);
    }
  }
  while(n == -1);

  begin();
}

/**
* @brief Connecte un client en attente
*
* @fn MonServeur::connecterClient
*
*/
void MonServeur::connecterClient()
{
  int i = 0;

  // client en attente ?
  if(hasClient())
  {
    for (i = 0; i < MAX_CLIENTS; i++)
    {
      if (!clients[i] || !clients[i].connected())
      {
        if (clients[i])
        {
          clients[i].stop();
        }
        clients[i] = available();
        if(debug)
        {
          Serial.print(i+1);
          Serial.print(" - Nouveau client : ");
          Serial.print(clients[i].remoteIP());
          Serial.print(":");
          Serial.print(clients[i].remotePort());
          Serial.println("");
        }
        break;
      }
    }
    // plus de place ?
    if (i == MAX_CLIENTS)
    {
      WiFiClient wifiClient = available();
      wifiClient.stop();
      if(debug)
        Serial.println("Connexion rejetée !");
    }
  }
}

/**
* @brief Envoie un message à tous les clients connectés
*
* @fn MonServeur::envoyer
*
* @param message String le message à envoyer
*/
void MonServeur::envoyer(String message)
{
  // seulement à l'expiration de la période ?
  if(!estEcheance(periode))
    return;
  // pour tous les clients connectés
  for (int i = 0; i < MAX_CLIENTS; i++)
  {
    if (clients[i] && clients[i].connected())
    {
      if(debug)
      {
        Serial.print("Envoi client ");
        Serial.print(clients[i].remoteIP());
        Serial.print(":");
        Serial.print(clients[i].remotePort());
        Serial.println("");
      }
      clients[i].print(message);
    }
  }
}

/**
* @brief Réceptionne une requête client
*
* @fn MonServeur::lireRequete
*
* @return bool true si une requête valide a été lue
*/
bool MonServeur::lireRequete()
{
  // parcourir tous les clients connectés
  for (int i = 0; i < MAX_CLIENTS; i++)
  {
    if (clients[i] && clients[i].connected())
    {
      // des données à lire ?
      if (clients[i].available())
      {
        // récupère la requête
        String requete = clients[i].readStringUntil('\n');
        if(debug)
        {
          Serial.print("Requête client ");
          Serial.print(clients[i].remoteIP());
          Serial.print(":");
          Serial.print(clients[i].remotePort());
          Serial.print(" -> ");
          Serial.println(requete);
        }
        clients[i].flush();
        requete.trim();
        bool etat = verifierRequete(requete);
        // requête connue et la pécédente a été traité ?
        if(etat && this->requete.traite)
        {
          // alors on la mémorise
          //this->requete.client = clients[i];
          this->requete.numeroClient = i;
          this->requete.requete = requete;
          this->requete.traite = false;
        }
        else
        {
          repondreRequete("ERREUR\n");
        }
        return etat;
      }
    }
  }
  return false;
}

/**
* @brief Récupère la dernière requête d'un client
*
* @fn MonServeur::recupererRequete
*
* @return String la dernière requête d'un client
*/
String MonServeur::recupererRequete() const
{
  return requete.requete;
}

/**
* @brief Répond à la dernière requête du client
*
* @fn MonServeur::repondreRequete
*
* @param message String le réponse envoyée au client
*/
void MonServeur::repondreRequete(String message)
{
  // client existant et connecté ?
  if (clients[this->requete.numeroClient] && clients[this->requete.numeroClient].connected())
  {
    if(debug)
    {
      Serial.print("Réponse client ");
      Serial.print(clients[this->requete.numeroClient].remoteIP());
      Serial.print(":");
      Serial.print(clients[this->requete.numeroClient].remotePort());
      Serial.println("");
    }
    clients[this->requete.numeroClient].print(message);
    // requête traitée
    this->requete.traite = true;
  }
}

/**
* @brief Vérifie si la requête respecte le protocole
*
* @fn MonServeur::verifierRequete
*
* @return bool true si la requête est valide sinon false
*/
bool MonServeur::verifierRequete(String requete)
{
  requete.toUpperCase();
  // requête valide ?
  if(requete.startsWith("SET"))
  {
    if(requete.indexOf("LED") != -1)
    {
      return true;
    }
  }
  return false;
}

// Méthodes privées

/**
* @brief Active le WiFi
*
* @fn MonServeur::activerWifi
*
*/
void MonServeur::activerWifi()
{
  delay(10);
  Serial.println();
  Serial.print("Connexion à ");
  Serial.println(SSIDWifi);

  if (WiFi.status() == WL_CONNECTED)
  {
    WiFi.disconnect();
  }

  if (WiFi.status() != WL_CONNECTED)
  {
    WiFi.persistent(false);
    WiFi.mode(WIFI_OFF);
    WiFi.mode(WIFI_STA);

    if(!dhcp)
    {
      if (!WiFi.config(monAdresseIP, maPasserelle, monMasque, monDNSPrimaire, monDNSSecondaire))
      {
        if(debug)
          Serial.println("Erreur adressage statique !");
      }
    }

    WiFi.begin((char *)SSIDWifi.c_str(), (char *)PasswordWifi.c_str());
  }

  nbTentatives = 0;
  while (WiFi.status() != WL_CONNECTED && nbTentatives < NB_TENTATIVES_WIFI)
  {
    delay(ATTENTE_RECONNEXION_WIFI);
    Serial.print(".");
    nbTentatives++;
  }

  if (nbTentatives >= NB_TENTATIVES_WIFI)
  {
    if(debug)
      Serial.println("Redémarrage ...");
    ESP.restart();
  }

  if(debug)
  {
    Serial.println("");
    Serial.print("Connecté à ");
    Serial.println(SSIDWifi);
    Serial.print("Adresse IP : ");
    Serial.println(WiFi.localIP());
    Serial.print("Port : ");
    Serial.println(port);
    Serial.print("Adresse MAC : ");
    Serial.println(WiFi.macAddress());
  }

  adresseIP = WiFi.localIP().toString();
}

/**
* @brief Recherche et sélectionne un réseau WiFi
*
* @fn MonServeur::detecterWLAN
*
* @param ssid const char* le SSID du réseau WiFi à joindre
* @param password const char* le mot de passe associé au SSID
*/
int MonServeur::detecterWLAN(const char *ssid, const char *password)
{
  int nb = WiFi.scanNetworks();
  Serial.print("Nb réseaux : ");
  Serial.println(nb);
  if (nb == 0)
  {
    Serial.println("Aucun réseau !");
    return -1;
  }
  else
  {
    for (int i = 0; i < nb; ++i)
    {
      if((String(WiFi.SSID(i)) == String(ssid)))
      {
        SSIDWifi = String(WiFi.SSID(i));
        if(strlen(password) > 0)
        {
          PasswordWifi = String(password);
        }
        else
        {
          Serial.print("Saisir le mot de passe pour le réseau ");
          Serial.print(SSIDWifi);
          Serial.print(" : ");
          PasswordWifi = saisirPassword();
        }
        return 0;
      }
    }
    for (int i = 0; i < nb; ++i)
    {
      Serial.print(i + 1);
      Serial.print(": ");
      Serial.print(WiFi.SSID(i));
      Serial.print(" (");
      Serial.print(WiFi.RSSI(i));
      Serial.print(")");
      //Serial.println((WiFi.encryptionType(i) == ENC_TYPE_NONE) ? " " : "*");
      Serial.println("");
      delay(10);
    }
  }
  Serial.println("");

  return nb;
}

/**
* @brief Saisie d'un numéro de réseau WiFi
*
* @fn MonServeur::saisirNumeroReseau
*
* @return int le numéro de réseau choisi
*/
int MonServeur::saisirNumeroReseau()
{
  int numero = 0;

  while (!Serial.available());
  do
  {
     byte c = Serial.read();
     if(isdigit(c))
     {
        numero *= 10;
        numero += c - '0';
     }
     delay(10);
  }
  while (Serial.available() && numero == 0);

  return numero;
}

/**
* @brief Saisie d'un mot de passe
*
* @fn MonServeur::saisirPassword
*
* @return String le mot de passe saisi
*/
String MonServeur::saisirPassword()
{
  int pos = 0;
  char saisie[MAX_LENGTH_PASSWORD+1];
  bool fini = false;

  while (!Serial.available());
  do
  {
    byte c = Serial.read();
    switch (c)
    {
    case '\n':
      saisie[pos] = 0; // fin de chaîne
      pos = 0;
      fini = true;
      break;
    case '\r':
      break;
    default:
      if (pos < MAX_LENGTH_PASSWORD)
        saisie[pos++] = c;
      break;
    }
    delay(10);
  }
  while (Serial.available() && !fini);

  if(!fini)
  {
    if (pos > 0 && pos < MAX_LENGTH_PASSWORD)
      saisie[pos] = 0;
    else
      saisie[MAX_LENGTH_PASSWORD] = 0;
  }

  return String(saisie);
}

/**
* @brief Sélectionne un réseau WiFi
*
* @fn MonServeur::selectionnerWLAN
*
* @param n int numéro de réseau
* @param ssid const char* le SSID du réseau WiFi à joindre
* @param password const char* le mot de passe associé au SSID
*
* @return bool true si le réseau a été correctement sélectionné
*/
bool MonServeur::selectionnerWLAN(int n, const char *ssid, const char *password)
{
  int numero = 0;
  bool valide = false;

  if (n == 0)
  {
    return false;
  }
  else
  {
    do
    {
      Serial.print("Choisir un réseau : ");
      numero = saisirNumeroReseau();
      if(numero > 0 && numero <= n)
      {
        Serial.print("Réseau sélectionné : ");
        Serial.print(WiFi.SSID(numero-1));
        Serial.println("");
        if((String(WiFi.SSID(numero-1)) == String(ssid)))
        {
          SSIDWifi = String(WiFi.SSID(numero-1));
          if(strlen(password) > 0)
          {
            PasswordWifi = String(password);
          }
          else
          {
            Serial.println("");
            Serial.print("Saisir le mot de passe : ");
            PasswordWifi = saisirPassword();
          }
        }
        else
        {
          SSIDWifi = String(WiFi.SSID(numero-1));
          Serial.println("");
          Serial.print("Saisir le mot de passe : ");
          PasswordWifi = saisirPassword();
        }
        valide = true;
      }
      else
        Serial.println("Numéro de réseau invalide !");
    }
    while(!valide);
  }

  return true;
}

/**
* @brief Retourne true si l'échéance de la période fixée a été atteinte
*
* @fn MonServeur::estEcheance
*
* @param intervalle unsigned long l'intervalle de temps en millisecondes entre deux échéances
*
* @return bool vrai si l'échéance de la période a été atteinte
*/
bool MonServeur::estEcheance(unsigned long intervalle)
{
    unsigned long temps = millis();
    if (temps - tempsPrecedent >= intervalle)
    {
        tempsPrecedent = temps;
        return true;
    }
    return false;
}
