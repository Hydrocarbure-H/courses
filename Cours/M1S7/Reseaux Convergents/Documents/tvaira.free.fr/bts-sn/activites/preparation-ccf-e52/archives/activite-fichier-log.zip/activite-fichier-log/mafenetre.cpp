#include "mafenetre.h"
#include "log.h"

MaFenetre::MaFenetre(QWidget *parent) :
    QWidget(parent)
{
    // La GUI
    labelListe = new QLabel("Interfaces :", this);
    listeInterfaces = new QComboBox(this);
    boutonAjouter = new QPushButton("Ajouter", this);
    boutonSupprimer = new QPushButton("Supprimer", this);

    QVBoxLayout *layoutPrincipal = new QVBoxLayout;
    QHBoxLayout *layoutListe = new QHBoxLayout;
    QHBoxLayout *layoutPeripherique = new QHBoxLayout;

    layoutListe->addWidget(labelListe);
    layoutListe->addWidget(listeInterfaces);
    layoutPeripherique->addWidget(boutonAjouter);
    layoutPeripherique->addWidget(boutonSupprimer);

    layoutPrincipal->addLayout(layoutListe);
    layoutPrincipal->addLayout(layoutPeripherique);
    layoutPrincipal->addStretch();

    setLayout(layoutPrincipal);

    log = Log::getInstance();
    #ifdef JOURNALISATION
    QString message = "MaFenetre::MaFenetre() démarrage";
    log->journaliser(message);
    #endif

    // Initialisation
    connect(listeInterfaces, SIGNAL(currentIndexChanged(QString)), this, SLOT(selectionner(QString)));
    connect(boutonAjouter, SIGNAL(clicked()), this, SLOT(ajouter()));
    connect(boutonSupprimer, SIGNAL(clicked()), this, SLOT(supprimer()));

    creerListe();
}

MaFenetre::~MaFenetre()
{
    #ifdef JOURNALISATION
    QString message = "MaFenetre::~MaFenetre() arrêt";
    log->journaliser(message);
    #endif
    Log::detruireInstance();
}

void MaFenetre::ajouter()
{
    listeInterfaces->insertItem(listeInterfaces->count(), "/dev/ttyUSB"+QString::number(listeInterfaces->count()));
}

void MaFenetre::supprimer()
{    
    if(listeInterfaces->currentIndex() >= 0)
    {
        listeInterfaces->removeItem(listeInterfaces->currentIndex());
    }
}

void MaFenetre::selectionner(QString interface)
{
    qDebug() << "MaFenetre::selectionner() " << interface;
    #ifdef JOURNALISATION
    QString message = "MaFenetre::selectionner() " + interface;
    log->journaliser(message);
    #endif
}

void MaFenetre::creerListe()
{
    listeInterfaces->clear();
    for(int i = 0; i < NB_INTERFACES; i++)
    {
        listeInterfaces->insertItem(i, "/dev/ttyUSB"+QString::number(i));
        qDebug() << "MaFenetre::creerListe() " << "/dev/ttyUSB"+QString::number(i);
        #ifdef JOURNALISATION
        QString message = "MaFenetre::creerListe() /dev/ttyUSB" + QString::number(i);
        log->journaliser(message);
        #endif
    }
}
