#ifndef XBEE_PI_H
#define XBEE_PI_H

#include <iostream>
#include <string.h>
#include <unistd.h>

#include <xbeep.h>

using namespace std;
using namespace libxbee;

class ConnexionXbee : public ConCallback 
{
	public:
		explicit ConnexionXbee(XBee &parent, string type, struct xbee_conAddress *address = NULL);
        ~ConnexionXbee();
        void xbee_conCallback(libxbee::Pkt **paquet);
		void recevoir(Pkt **paquet);
        std::string myData;
        
    private:
        string donnees;
};

#endif //XBEE_PI_H
