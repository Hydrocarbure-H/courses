#include "historique.h"
#include <cstdio>

Historique::Historique(int taille/*=LG_HISTORIQUE*/) : indice(0), taille(taille)
{
	historique = new TAlarme[taille];
}

Historique::~Historique()
{
	delete [] historique;
}

unsigned int Historique::getNbAlarmes() const
{
   return indice;
}

unsigned int Historique::getTaille() const
{
   return taille;
}

void Historique::ajouterAlarme(Altitude altitude)
{
   // quelle est la bonne solution ?
}

// Solution 1 :
void Historique::ajouterAlarmeSolution1(Altitude altitude)
{
   historique[indice].date = time(NULL);
   historique[indice].altitude = altitude;
   indice++;
}

// Solution 2 :
void Historique::ajouterAlarmeSolution2(Altitude altitude)
{
   if (indice >= taille ) indice = 0;
   historique[indice].date = time(NULL);
   historique[indice].altitude = altitude;
   indice++;
}

// Solution 3 :               
void Historique::ajouterAlarmeSolution3(Altitude altitude)
{
   historique[indice].date = time(NULL);
   historique[indice].altitude = altitude;
   if (indice++ > taille ) indice = 0;
}

// Solution 4 :
void Historique::ajouterAlarmeSolution4(Altitude altitude)
{
   historique[indice % LG_HISTORIQUE].date = time(NULL);
   historique[indice % LG_HISTORIQUE].altitude = altitude;
   indice++;
}

void Historique::afficher()  const
{    
    /* TODO */
}

void Historique::afficherDerniereAlarme()  const
{
    /* TODO */
}
