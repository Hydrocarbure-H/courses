#include "appareilble.h"

AppareilBLE::AppareilBLE(QString nom, QString adresseMAC, QObject *parent) : QObject(parent), nom(nom), adresseMAC(adresseMAC)
{
}

QString AppareilBLE::getNom() const
{
    return nom;
}

QString AppareilBLE::getAdresseMAC() const
{
    return adresseMAC;
}
