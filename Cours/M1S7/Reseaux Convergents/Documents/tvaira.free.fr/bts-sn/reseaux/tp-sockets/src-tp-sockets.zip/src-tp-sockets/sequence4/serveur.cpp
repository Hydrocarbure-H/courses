#include "serveur.h"
#include <QDebug>

Serveur::Serveur()
{
    
}

void Serveur::demarrer()
{   
    
}

void Serveur::nouvelleConnexion()
{
    
}

void Serveur::deconnexionClient()
{
    
}

void Serveur::recevoir()
{
        
}

void Serveur::envoyer(const QString adresseIP, int numeroPort, const QString &reponse)
{
   
}
