#ifndef ClientBLE_H
#define ClientBLE_H

#include <QLowEnergyController>

#define MON_WEMOS_LOLIN_ESP32_OLED  "30:AE:A4:23:D6:7E"
#define MON_AZDELIVERY_ESP32        "30:AE:A4:7B:80:46"

#define SERVICE_UUID                "{042bd80f-14f6-42be-a45c-a62836a4fa3f}"
#define CHARACTERISTIC_UUID         "{065de41b-79fb-479d-b592-47caf39bfccb}"

class ClientBLE : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool etatConnexion MEMBER m_etatConnexion NOTIFY connecte)
    Q_PROPERTY(float compteur MEMBER m_compteur NOTIFY compteurChange)

public:
    ClientBLE();
    ~ClientBLE();
    Q_INVOKABLE void start();
    Q_INVOKABLE void stop();
    Q_INVOKABLE void read();
    Q_INVOKABLE void gererNotification(bool notification);

protected slots:
    void connecterAppareil(const QString &adresseServeur);
    void connecterService(QLowEnergyService *service);
    void ajouterService(QBluetoothUuid serviceUuid);
    void serviceDetailsDiscovered(QLowEnergyService::ServiceState newState);
    void serviceCharacteristicChanged(const QLowEnergyCharacteristic &c, const QByteArray &value);
    void appareilConnecte();
    void appareilDeconnecte();

private:
    QList<QObject*>                  m_devices;
    QLowEnergyController            *m_controller;
    QLowEnergyService               *m_service;
    bool                             m_etatConnexion;
    int                              m_compteur;
    QLowEnergyCharacteristic         m_characteristic;

signals:
    void connecte();
    void compteurChange();
};

#endif // ClientBLE_H
