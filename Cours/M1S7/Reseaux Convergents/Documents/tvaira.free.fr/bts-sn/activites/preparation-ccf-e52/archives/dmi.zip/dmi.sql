DROP DATABASE IF EXISTS `dmi`;
CREATE DATABASE `dmi` DEFAULT CHARACTER SET utf8;
USE `dmi`;

--
-- Structure de la table `diffuseurs`
--

CREATE TABLE IF NOT EXISTS `diffuseurs` (
  `idDiffuseur` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `droit` int(11) unsigned DEFAULT NULL,
  `etat` int(11) DEFAULT NULL,  
  PRIMARY KEY (`idDiffuseur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `diffuseur`
--

INSERT INTO `diffuseurs` (`idDiffuseur`, `nom`, `password`, `droit`, `etat`) VALUES
(1, 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', 1, 1),
(2, 'dmi', '5f4dcc3b5aa765d61d8327deb882cf99', 2, 1);

--
-- Structure de la table `medias`
--

CREATE TABLE IF NOT EXISTS `medias` (
  `idMedia` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  --   `type` enum('video','bandeau',''),
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idMedia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `medias`
--

INSERT INTO `medias` (`idMedia`, `type`, `description`) VALUES
(1, 'ecran', 'Vidéo'),
(2, 'ecran', 'TV');


--
-- Structure de la table `ecrans`
--

CREATE TABLE IF NOT EXISTS `ecrans` (
  `idEcran` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `adresse` varchar(17) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `background` varchar(16) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `etat` int(11) DEFAULT NULL,
  `presence` int(11) DEFAULT NULL,
  `refresh` int(11) DEFAULT NULL,
  `largeur` int(11) DEFAULT NULL,
  `hauteur` int(11) DEFAULT NULL,
  `idMedia` int(11) unsigned NOT NULL,  
  PRIMARY KEY (`idEcran`),
  KEY `fk_medias_idMedia1` (`idMedia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `ecrans`
--
ALTER TABLE `ecrans` ADD CONSTRAINT `fk_medias_idMedia1` FOREIGN KEY (`idMedia`) REFERENCES `medias` (`idMedia`) ON DELETE CASCADE;

--
-- Structure de la table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `idMessage` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `heure` time NOT NULL,  
  `contenu` text DEFAULT NULL,
  `idDiffuseur` int(11) unsigned NOT NULL,
  PRIMARY KEY (`idMessage`),
  CONSTRAINT fk_ecrans_idDiffuseur
  FOREIGN KEY (idDiffuseur)
  REFERENCES diffuseurs(idDiffuseur)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Structure de la table `diffusion`
--

CREATE TABLE IF NOT EXISTS `diffusion` (
  `idDiffusion` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dateDebut` date NOT NULL,
  `heureDebut` time NOT NULL,  
  `dateFin` date DEFAULT NULL,
  `heureFin` time DEFAULT NULL,  
  `duree` int(11) unsigned NOT NULL,
  `periode` int(11) unsigned NOT NULL,
  `etat` int(11) NOT NULL,
  `type` int(11) unsigned NOT NULL,
  `idMessage` int(11) unsigned NOT NULL,
  `idEcran` int(11) unsigned NOT NULL,
  PRIMARY KEY (`idDiffusion`),
  CONSTRAINT fk_messages_idMessage
  FOREIGN KEY (idMessage)
  REFERENCES messages(idMessage),
  CONSTRAINT fk_ecrans_idEcran1
  FOREIGN KEY (idEcran)
  REFERENCES ecrans(idEcran)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Structure de la table `plugins`
--

CREATE TABLE IF NOT EXISTS `plugins` (
  `idPlugin` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idPlugin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `plugins`
--

INSERT INTO `plugins` (`idPlugin`, `nom`, `description`) VALUES
(1, 'horloge analogique', ''),
(2, 'horloge digitale', ''),
(3, 'date', ''),
(4, 'image', ''),
(5, 'panel', ''),
(6, 'label', ''),
(7, 'video', ''),
(8, 'horodatage', ''),
(9, 'bouton', ''),
(10, 'horloge analogique qwt', ''),
(11, 'animation', ''),
(12, 'webcam', ''),
(13, 'chronometre', ''),
(14, 'compte à rebours', '');

--
-- Structure de la table `widgets`
--

CREATE TABLE IF NOT EXISTS `widgets` (
  `uuid` varchar(255) NOT NULL,
  `ligne` int(11) unsigned DEFAULT NULL,
  `colonne` int(11) unsigned DEFAULT NULL,
  `largeur` int(11) unsigned DEFAULT NULL,
  `hauteur` int(11) unsigned DEFAULT NULL,
  `horizontal` int(11) unsigned DEFAULT NULL,
  `vertical` int(11) unsigned DEFAULT NULL,
  `etat` int(11) DEFAULT NULL,
  `periode` int(11) unsigned DEFAULT NULL,
  `idPlugin` int(11) unsigned NOT NULL,
  `idEcran` int(11) unsigned NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `fk_plugins_idPlugin` (`idPlugin`),
  KEY `fk_ecrans_idEcran2` (`idEcran`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- `horizontal` :
-- Qt::AlignLeft	0x0001	Aligns with the left edge.
-- Qt::AlignRight	0x0002	Aligns with the right edge.
-- Qt::AlignHCenter	0x0004	Centers horizontally in the available space.
-- Qt::AlignJustify	0x0008	Justifies the text in the available space.
-- `vertical` :
-- Qt::AlignTop	    0x0020	32 Aligns with the top.
-- Qt::AlignBottom	0x0040	64 Aligns with the bottom.
-- Qt::AlignVCenter	0x0080	128 Centers vertically in the available space.

--
-- Contraintes pour la table `widgets`
--
ALTER TABLE `widgets` ADD CONSTRAINT `fk_plugins_idPlugin` FOREIGN KEY (`idPlugin`) REFERENCES `plugins` (`idPlugin`);
ALTER TABLE `widgets` ADD CONSTRAINT `fk_ecrans_idEcran2` FOREIGN KEY (`idEcran`) REFERENCES `ecrans` (`idEcran`);

--
-- Structure de la table `panels`
--

CREATE TABLE IF NOT EXISTS `panels` (
  `idPanel` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `zoom` double DEFAULT NULL,
  `scrollbar` TINYINT(1) DEFAULT NULL,   
  `uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`idPanel`),
  KEY `fk_widgets_uuid1` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `panels`
--
ALTER TABLE `panels` ADD CONSTRAINT `fk_widgets_uuid1` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`) ON DELETE CASCADE;

--
-- Structure de la table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `idImage` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) DEFAULT NULL,
  `taille` varchar(25) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `uuid` varchar(255) NOT NULL,
  `image` longblob NOT NULL,
  PRIMARY KEY (`idImage`),
  KEY `fk_widgets_uuid2` (`uuid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `images`
--
ALTER TABLE `images` ADD CONSTRAINT `fk_widgets_uuid2` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`) ON DELETE CASCADE;

--
-- Structure de la table `dates`
--

CREATE TABLE IF NOT EXISTS `dates` (
  `idDate` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `police` varchar(255) DEFAULT NULL,
  `taille` int(11) unsigned DEFAULT NULL,
  `couleur` varchar(16) DEFAULT NULL,
  `format` varchar(16) DEFAULT NULL,
  `type` int(11) unsigned DEFAULT NULL,
  `style` varchar(255) DEFAULT NULL,
  `uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`idDate`),
  KEY `fk_widgets_uuid3` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `dates`
--
ALTER TABLE `dates` ADD CONSTRAINT `fk_widgets_uuid3` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`) ON DELETE CASCADE;

--
-- Structure de la table `digitalclocks`
--

CREATE TABLE IF NOT EXISTS `digitalclocks` (
  `idDigitalClock` int(11) unsigned NOT NULL AUTO_INCREMENT,  
  `format` varchar(16) DEFAULT NULL,
  `background` varchar(16) DEFAULT NULL,
  `couleur` varchar(16) DEFAULT NULL,
  `style` varchar(255) DEFAULT NULL,
  `segment` int(11) DEFAULT NULL,
  `shape` int(11) DEFAULT NULL,
  `shadow` int(11) DEFAULT NULL,
  `uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`idDigitalClock`),
  KEY `fk_widgets_uuid4` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `digitalclocks`
--
ALTER TABLE `digitalclocks` ADD CONSTRAINT `fk_widgets_uuid4` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`) ON DELETE CASCADE;

--
-- Structure de la table `analogclocks`
--

CREATE TABLE IF NOT EXISTS `analogclocks` (
  `idAnalogClock` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `style` varchar(255) DEFAULT NULL,
  `hourColor` varchar(16) DEFAULT NULL,
  `minuteColor` varchar(16) DEFAULT NULL,
  `secondeColor` varchar(16) DEFAULT NULL,
  `uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`idAnalogClock`),
  KEY `fk_widgets_uuid5` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `analogclocks`
--
ALTER TABLE `analogclocks` ADD CONSTRAINT `fk_widgets_uuid5` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`) ON DELETE CASCADE;

--
-- Structure de la table `analogclocksqwt`
--

CREATE TABLE IF NOT EXISTS `analogclocksqwt` (
  `idAnalogClockQwt` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hourColor` varchar(16) DEFAULT NULL,
  `minuteColor` varchar(16) DEFAULT NULL,
  `secondeColor` varchar(16) DEFAULT NULL,
  `background` varchar(16) DEFAULT NULL,
  `uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`idAnalogClockQwt`),
  KEY `fk_widgets_uuid9` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `analogclocksqwt`
--
ALTER TABLE `analogclocksqwt` ADD CONSTRAINT `fk_widgets_uuid9` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`) ON DELETE CASCADE;

--
-- Structure de la table `labels`
--

CREATE TABLE IF NOT EXISTS `labels` (
  `idLabel` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `police` varchar(255) DEFAULT NULL,
  `taille` int(11) unsigned DEFAULT NULL,
  `couleur` varchar(16) DEFAULT NULL,
  `format` int(11) unsigned DEFAULT NULL,
  `style` varchar(255) DEFAULT NULL,
  `texte` text DEFAULT NULL,
  `uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`idLabel`),
  KEY `fk_widgets_uuid6` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `labels`
--
ALTER TABLE `labels` ADD CONSTRAINT `fk_widgets_uuid6` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`) ON DELETE CASCADE;

--
-- Structure de la table `horodatages`
--

CREATE TABLE IF NOT EXISTS `horodatages` (
  `idHorodatage` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `police` varchar(255) DEFAULT NULL,
  `taille` int(11) unsigned DEFAULT NULL,
  `couleur` varchar(16) DEFAULT NULL,
  `format` varchar(64) DEFAULT NULL,
  `type` int(11) unsigned DEFAULT NULL,
  `style` varchar(255) DEFAULT NULL,
  `uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`idHorodatage`),
  KEY `fk_widgets_uuid7` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `horodatages`
--
ALTER TABLE `horodatages` ADD CONSTRAINT `fk_widgets_uuid7` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`) ON DELETE CASCADE;

--
-- Structure de la table `boutons`
--

CREATE TABLE IF NOT EXISTS `boutons` (
  `idBouton` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `police` varchar(255) DEFAULT NULL,
  `taille` int(11) unsigned DEFAULT NULL,
  `couleur` varchar(16) DEFAULT NULL,
  `format` int(11) unsigned DEFAULT NULL,
  `style` varchar(255) DEFAULT NULL,
  `texte` text DEFAULT NULL,
  `uuid` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `idPanel` int(11) unsigned NOT NULL,
  PRIMARY KEY (`idBouton`),
  KEY `fk_widgets_uuid8` (`uuid`),
  KEY `fk_panels_idPanel2` (`idPanel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `boutons`
--
ALTER TABLE `boutons` ADD CONSTRAINT `fk_widgets_uuid8` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`) ON DELETE CASCADE;
ALTER TABLE `boutons` ADD CONSTRAINT `fk_panels_idPanel2` FOREIGN KEY (`idPanel`) REFERENCES `panels` (`idPanel`);

--
-- Structure de la table `movies`
--

CREATE TABLE IF NOT EXISTS `movies` (
  `idMovie` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) DEFAULT NULL,
  `taille` varchar(25) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `uuid` varchar(255) NOT NULL,
  `animation` longblob NOT NULL,
  PRIMARY KEY (`idMovie`),
  KEY `fk_widgets_uuid10` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `movies`
--
ALTER TABLE `movies` ADD CONSTRAINT `fk_widgets_uuid10` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`);

--
-- Structure de la table `videos`
--

CREATE TABLE IF NOT EXISTS `videos` (
  `idVideo` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) DEFAULT NULL,
  `taille` varchar(25) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `uuid` varchar(255) NOT NULL,
  `video` longblob NOT NULL,
  PRIMARY KEY (`idVideo`),
  KEY `fk_widgets_uuid12` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `videos`
--
ALTER TABLE `videos` ADD CONSTRAINT `fk_widgets_uuid12` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`);

--
-- Structure de la table `webcams`
--

CREATE TABLE IF NOT EXISTS `webcams` (
  `idWebcam` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`idWebcam`),
  KEY `fk_widgets_uuid11` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `movies`
--
ALTER TABLE `webcams` ADD CONSTRAINT `fk_widgets_uuid11` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`);

--
-- Structure de la table `chronometres`
--

CREATE TABLE IF NOT EXISTS `chronometres` (
  `idChrono` int(11) unsigned NOT NULL AUTO_INCREMENT,  
  `valeur` int(11) DEFAULT NULL,
  `format` varchar(16) DEFAULT NULL,
  `background` varchar(16) DEFAULT NULL,
  `couleur` varchar(16) DEFAULT NULL,
  `style` varchar(255) DEFAULT NULL,
  `segment` int(11) DEFAULT NULL,
  `shape` int(11) DEFAULT NULL,
  `shadow` int(11) DEFAULT NULL,
  `uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`idChrono`),
  KEY `fk_widgets_uuid13` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `chronometres`
--
ALTER TABLE `chronometres` ADD CONSTRAINT `fk_widgets_uuid13` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`) ON DELETE CASCADE;

--
-- Structure de la table `rebours`
--

CREATE TABLE IF NOT EXISTS `rebours` (
  `idRebours` int(11) unsigned NOT NULL AUTO_INCREMENT,  
  `valeur` int(11) DEFAULT NULL,
  `format` varchar(16) DEFAULT NULL,
  `background` varchar(16) DEFAULT NULL,
  `couleur` varchar(16) DEFAULT NULL,
  `style` varchar(255) DEFAULT NULL,
  `segment` int(11) DEFAULT NULL,
  `shape` int(11) DEFAULT NULL,
  `shadow` int(11) DEFAULT NULL,
  `uuid` varchar(255) NOT NULL,
  PRIMARY KEY (`idRebours`),
  KEY `fk_widgets_uuid14` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contraintes pour la table `rebours`
--
ALTER TABLE `rebours` ADD CONSTRAINT `fk_widgets_uuid14` FOREIGN KEY (`uuid`) REFERENCES `widgets` (`uuid`) ON DELETE CASCADE;
