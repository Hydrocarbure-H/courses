#include "mafenetre.h"

MaFenetre::MaFenetre(QWidget *parent) :
    QWidget(parent)
{
    // La GUI
    labelAdresseIP = new QLabel("Adresse IP :", this);
    labelPort = new QLabel("Port :", this);
    editAdresseIP = new QLineEdit(this);
    editPort = new QLineEdit(this);

    QVBoxLayout *layoutPrincipal = new QVBoxLayout;
    QHBoxLayout *layoutAdresseIP = new QHBoxLayout;
    QHBoxLayout *layoutPort = new QHBoxLayout;

    layoutAdresseIP->addWidget(labelAdresseIP);
    layoutAdresseIP->addWidget(editAdresseIP);
    layoutPort->addWidget(labelPort);
    layoutPort->addWidget(editPort);

    layoutPrincipal->addLayout(layoutAdresseIP);
    layoutPrincipal->addLayout(layoutPort);

    setLayout(layoutPrincipal);

    // Initialisation des données
    if(lireINI())
    {
        editAdresseIP->setText(connexion.adresseIP);
        editPort->setText(QString::number(connexion.port));
    }
}

MaFenetre::~MaFenetre()
{
    // Enregistrement des données
    ecrireINI();
}

bool MaFenetre::lireINI()
{
    // Le nom du fichier INI : nom-executable.ini
    QString fichierINI = qApp->applicationName() + ".ini";

    if(estFichier(fichierINI))
    {
        QSettings parametres(fichierINI, QSettings::IniFormat);

        // Lecture des paramètres de configuration
        connexion.adresseIP = parametres.value("connexion/adresse", "127.0.0.1").toString();
        connexion.port = parametres.value("connexion/port", "0").toInt();

        // Affichage de débugage
        qDebug() << QString::fromUtf8("adresse ip : %1").arg(connexion.adresseIP);
        qDebug() << QString::fromUtf8("port : %1").arg(connexion.port);

        return true;
    }
    else
    {
        QMessageBox::critical(0, "Erreur !", ("Impossible d'ouvrir le fichier " + fichierINI));
        return false;
    }
}

void MaFenetre::ecrireINI()
{
    // TODO
}

bool MaFenetre::estFichier(const QString &file)
{
    QFileInfo checkFile(file);

    if (checkFile.exists() && checkFile.isFile())
    {
        return true;
    }
    else
    {
        return false;
    }
}
