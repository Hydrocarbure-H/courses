#ifndef CAMERA_H
#define CAMERA_H

#include <iostream>

// POCO
#include <Poco/Net/HTTPClientSession.h>
#include <Poco/Net/HTTPRequest.h>
#include <Poco/Net/HTTPResponse.h>
#include <Poco/StreamCopier.h>
#include <Poco/Path.h>
#include <Poco/URI.h>
#include <Poco/Exception.h>

// OpenCV
#include <cv.h> // contient les déclarations des classes de manipulation d'images
#include <highgui.h> // contient déclarations des fonctions d'affichage des images

// Valeurs par défaut
#define ADRESSE_DEFAUT      "127.0.0.1"
#define PORT_DEFAUT         99
#define UTILISATEUR_DEFAUT  "admin"
#define PASSWORD_DEFAUT     ""
#define CGI_VIDEO          "videostream.cgi"
#define CGI_PHOTO          "snapshot.cgi"
#define RESOLUTION_DEFAUT   32
#define TIMEOUT_CLAVIER     10 // en ms

// Codes touche
#define ESPACE  0x20
#define HAUT    0x52
#define BAS     0x54
#define GAUCHE  0x51
#define DROITE  0x53
#define QUIT    0x71

#define DEBUG

using namespace Poco::Net;
using namespace Poco;
using namespace cv;
using namespace std;

class Camera
{
    private:
        cv::VideoCapture  capture;
        cv::Mat           frame;
        cv::Mat           photo;
        int               numeroPhoto;
        std::string       adresseIP;
        int               port;
        std::string       utilisateur;
        std::string       motDePasse;
        std::string       scriptCGIVideo;
        std::string       scriptCGIPhoto;
        int               resolution;
        int               rate;
        std::string       url;
        bool              init;
        std::string       fenetre;        
    
        bool initialiser();
        bool acquerir();
        void capturer();
        void afficher();
        void orienter(URI &uri);
        bool gererActions();
    
    public:
        Camera(std::string adresseIP=ADRESSE_DEFAUT, int port=PORT_DEFAUT, std::string utilisateur=UTILISATEUR_DEFAUT, std::string motDePasse=PASSWORD_DEFAUT);
        Camera(const char *adresseIP, int port=PORT_DEFAUT, std::string utilisateur=UTILISATEUR_DEFAUT, std::string motDePasse=PASSWORD_DEFAUT);
        ~Camera();       
        
        void demarrer();        
        
        static string IntToString(int n);
        static string IntToString(int n, int base);
        static int StringToInt(string str);
        static string FloatToString(float n);
        static float StringToFloat(const string str);
        static string DoubleToString(double n);
        static double StringToDouble(const string str);
};

#endif // CAMERA_H
