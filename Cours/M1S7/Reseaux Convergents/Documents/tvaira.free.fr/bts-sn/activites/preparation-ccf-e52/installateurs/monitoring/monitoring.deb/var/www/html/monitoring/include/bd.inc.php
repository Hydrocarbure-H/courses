<?php

if (!defined('MONITORING')) 
{
    exit;
}

function ouvrirBase()
{
    UpdateLog("".__FUNCTION__."()", $GLOBALS['config']['logfile']);
    $base = new SQLite3($GLOBALS['config']['dbname']); 
    return $base;
}

function fermerBase($base)
{
    UpdateLog("".__FUNCTION__."()", $GLOBALS['config']['logfile']);
    if($base != NULL)
        $base->close();
}

function connecterBase()
{
    UpdateLog("".__FUNCTION__."()", $GLOBALS['config']['logfile']);
    $mysqli = @new mysqli($GLOBALS['config']['host'], $GLOBALS['config']['username'], $GLOBALS['config']['passwd'], $GLOBALS['config']['dbname']);

    if ($mysqli->connect_error) 
    {
        die('Echec de connexion au serveur de base de données : ' . $mysqli->connect_error . ' (' . $mysqli->connect_errno . ') ');
    }
    
    return $mysqli;
}

function deconnecterBase($mysqli)
{
    UpdateLog("".__FUNCTION__."()", $GLOBALS['config']['logfile']);
    if($mysqli != NULL)
        $mysqli->close();
}

function getNbEnregistrements($result)
{
    if (defined('DEBUG')) 
        printf("La requête a retourné %d enregistrement(s).<br />\n", $result->num_rows);
    return $result->num_rows;
}

function fetch_object($sqlite3result, $objectType = NULL) 
{
    $array = $sqlite3result->fetchArray();    
    if(!$array)
        return NULL;
    if(is_null($objectType)) 
    {
        $object = new stdClass();
    } 
    else 
    {
        $object = unserialize(sprintf('O:%d:"%s":0:{}', strlen($objectType), $objectType));
    }
   
    for($i = 0; $i < $sqlite3result->numColumns(); $i++) 
    {
        $name = $sqlite3result->columnName($i);
        $value = $array[$name];
        $object->$name = $value;
    }
   
    return $object;
}

?>
