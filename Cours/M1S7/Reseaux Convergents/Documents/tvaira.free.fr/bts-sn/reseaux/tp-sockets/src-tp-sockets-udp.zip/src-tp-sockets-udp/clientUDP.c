#include <stdio.h>
#include <stdlib.h> /* pour exit */
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h> /* pour memset */
#include <netinet/in.h> /* pour struct sockaddr_in */
#include <arpa/inet.h> /* pour htons, htonl et inet_aton */
#include <netdb.h> /* pour getaddrinfo */

#define LG_MESSAGE   256

int main(int argc, char *argv[])
{
   int descripteurSocket;
   struct sockaddr_in pointDeRencontreLocal;
   struct sockaddr_in pointDeRencontreDistant;
   socklen_t longueurAdresse = sizeof(pointDeRencontreDistant);
   char messageEnvoi[LG_MESSAGE]; /* le message de la couche Application ! */  
   int ecrits; /* nb d'octets ecrits */
   int retour;
   struct addrinfo hints;
   struct addrinfo *result, *rp;

   // Il faut 2 arguments à ce programme
   if (argc < 2)
   {
      fprintf(stderr, "Erreur : argument manquant !\n"); 
      fprintf(stderr, "Usage : %s adresse_ip numero_port\n", argv[0]); 
      exit(-5); // On sort en indiquant un code erreur
   }
   
   // Obtenir un point de communication distant correspondant au couple nom/port fourni en argument
   memset(&hints, 0, sizeof(struct addrinfo));
   hints.ai_family = PF_INET;    // sinon AF_UNSPEC pour IPv4 ou IPv6
   hints.ai_socktype = SOCK_DGRAM; // mode non connecté
   hints.ai_flags = 0; // options supplémentaires, ici aucune
   hints.ai_protocol = 0; // n'importe quel type

   retour = getaddrinfo(argv[1], argv[2], &hints, &result);
   if (retour != 0) 
   {
      fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(retour)); // Affiche le message d'erreur
      exit(-6); // On sort en indiquant un code erreur
   }
   
   // getaddrinfo() retourne une liste de structures d'adresses 
   // on cherche la première qui permettra un connect()
   for (rp = result; rp != NULL; rp = rp->ai_next) 
   {
      // Crée un socket de communication 
      descripteurSocket = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);

      // Échec ?
      if (descripteurSocket == -1)
            continue; // alors on essaye la suivante
      else  
      {
          memcpy(&pointDeRencontreDistant, rp->ai_addr, rp->ai_addrlen);
          printf("Adresse distante : %s\n", inet_ntoa(pointDeRencontreDistant.sin_addr)); 
          printf("Port distant : %d\n", ntohs(pointDeRencontreDistant.sin_port)); 
          break; // pas d'erreur : on sort
      }
   }

   if (rp == NULL) 
   {               
      // on a donc trouvé aucune adresse valide !
      fprintf(stderr, "Impossible d'utiliser cette adresse !\n");
      exit(-6); // On sort en indiquant un code erreur
   }

   freeaddrinfo(result); // on libère les résultats obtenus et on continue ...
   
   printf("Socket créée avec succès ! (%d)\n", descripteurSocket);

   // On prépare l'adresse d'attachement locale
   longueurAdresse = sizeof(struct sockaddr_in);
   memset(&pointDeRencontreLocal, 0x00, longueurAdresse);
   pointDeRencontreLocal.sin_family        = PF_INET;
   pointDeRencontreLocal.sin_addr.s_addr   = htonl(INADDR_ANY); // n'importe quelle interface locale disponible
   pointDeRencontreLocal.sin_port          = htons(0); // l'os choisira un numéro de port libre

   // On demande l'attachement local de la socket
   if((bind(descripteurSocket, (struct sockaddr *)&pointDeRencontreLocal, longueurAdresse)) < 0)
   {
      perror("bind");
      exit(-2);
   }

   printf("Socket attachée avec succès !\n");
  
   // Initialise à 0 le message
   memset(messageEnvoi, 0x00, LG_MESSAGE*sizeof(char));
   
   // Envoie un message au serveur
   sprintf(messageEnvoi, "Hello world !\n");    
   ecrits = sendto(descripteurSocket, messageEnvoi, strlen(messageEnvoi), 0, (struct sockaddr *)&pointDeRencontreDistant, longueurAdresse);
   switch(ecrits)
   {
      case -1 : /* une erreur ! */
         perror("sendto");
         close(descripteurSocket);
         exit(-3);
      case 0 : 
         fprintf(stderr, "Aucune donnée n'a été envoyée !\n\n"); 
         close(descripteurSocket);
         return 0;
      default: /* envoi de n octets */
         if(ecrits != strlen(messageEnvoi))
            fprintf(stderr, "Erreur dans l'envoie des données !\n\n"); 
         else 
            printf("Message %s envoyé avec succès (%d octets)\n\n", messageEnvoi, ecrits); 
   }
   
   // On ferme la ressource avant de quitter   
   close(descripteurSocket);

   return 0;
}
