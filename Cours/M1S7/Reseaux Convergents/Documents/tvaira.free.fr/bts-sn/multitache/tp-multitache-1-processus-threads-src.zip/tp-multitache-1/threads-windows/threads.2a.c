#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

DWORD WINAPI ThreadEtoile(LPVOID lpParam)
{
   int n;
   int *pData;
   
   pData = (int*)lpParam;
   n = *pData;
   printf("la tache%d affiche des * ...\n", n);
   int i;
   for(i=1;i<=200;i++)
   {
      printf("*");
   }
   return 0;
}

DWORD WINAPI ThreadDiese(LPVOID lpParam)
{
   int n;
   int *pData;
   
   pData = (int*)lpParam;
   n = *pData;
   printf("la tache%d affiche des # ...\n", n);
   int i;
   for(i=1;i<=200;i++)
   {
      printf("#");
   }
   return 0;
}

int main(void)
{
   DWORD dwThreadId1, dwThreadId2;
   HANDLE hThread1, hThread2;
   int n1 = 1, n2 = 2;
   
   // Création du thread (autre que le primaire)
   hThread1 = CreateThread(NULL, // default security attributes
                           0, // use default stack size
                           ThreadEtoile, // thread function
                           &n1, // argument to thread function
                           0, // use default creation flags
                           &dwThreadId1); // returns the thread identifier
   
   if (hThread1 == NULL)
   {
      printf( "CreateThread failed (%d).\n", GetLastError());
      ExitProcess(1);
   }
   
   // Création du thread (autre que le primaire)
   hThread2 = CreateThread(NULL, // default security attributes
                           0, // use default stack size
                           ThreadDiese, // thread function
                           &n2, // argument to thread function
                           0, // use default creation flags
                           &dwThreadId2); // returns the thread identifier
   
   if (hThread2 == NULL)
   {
      printf( "CreateThread failed (%d).\n", GetLastError());
      ExitProcess(1);
   }
   
   // Attente fin des threads
   WaitForSingleObject(hThread1, INFINITE);
   WaitForSingleObject(hThread2, INFINITE);

   // Ferme et libère les ressources
   CloseHandle(hThread1);
   CloseHandle(hThread2);
   
   printf("Fin ...\n");
   //getchar();
   
   return 0;
}
