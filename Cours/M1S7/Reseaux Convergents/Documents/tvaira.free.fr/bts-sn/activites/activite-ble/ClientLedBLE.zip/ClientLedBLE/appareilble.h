#ifndef APPAREILBLE_H
#define APPAREILBLE_H

#include <QObject>

class AppareilBLE : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString nom READ getNom NOTIFY appareilChanged)
    Q_PROPERTY(QString adresseMAC READ getAdresseMAC NOTIFY appareilChanged)

public:
    explicit AppareilBLE(QString nom, QString adresseMAC, QObject *parent = nullptr);
    QString getNom() const;
    QString getAdresseMAC() const;

private:
    QString nom;
    QString adresseMAC;

signals:
    void appareilChanged();

public slots:
};

#endif // APPAREILBLE_H
