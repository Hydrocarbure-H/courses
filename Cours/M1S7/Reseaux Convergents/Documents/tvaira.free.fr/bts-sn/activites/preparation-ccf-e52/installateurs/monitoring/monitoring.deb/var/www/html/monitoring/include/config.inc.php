<?php

define("HOME_PATH", "/var/www/html/monitoring/");

$config['nom'] = 'MONITORING';
$config['description'] = 'Surpervision de salles';
$config['signature'] = '©&nbsp;2019&nbsp;v0.1&nbsp;La Salle Avignon';
$config['charset'] = 'utf-8';
$config['refresh'] = 10000; // en ms
$config['logfile'] = HOME_PATH."monitoring.log";
$config['bd'] = "array"; // Choix possible : "sqlite" ou "mysql" ou "array"
$config['dbname'] = "monitoring"; // pour "sqlite" ou "mysql"
$config['host'] = "localhost"; // seulement pour "mysql"
$config['username'] = "root"; // seulement pour "mysql"
$config['passwd'] = "password"; // seulement pour "mysql"

// Si $config['bd'] == "array"
$config['salles'] = array (
        0 => array('idSalle' => 1,'nom' => "B20",'description' => "salle BTS SN",'ip' => "192.168.52.21",'port' => 5000, 'etat' => 1),
        1 => array('idSalle' => 2,'nom' => "B22",'description' => "salle BTS SN",'ip' => "192.168.52.191",'port' => 5000,'etat' => 1),
        2 => array('idSalle' => 3,'nom' => "C12",'description' => "salle",'ip' => "192.168.52.25",'port' => 5000,'etat' => 1)
);

?>
