#ifndef CLIENT_H
#define CLIENT_H

#include <QObject>
#include <QtNetwork>

//#define ADRESSE_SERVEUR              "www.google.fr"
//#define ADRESSE_SERVEUR              "192.168.52.2"
#define ADRESSE_SERVEUR              "127.0.0.1"

#define PORT_SERVEUR                    80

class Client : public QObject
{
   Q_OBJECT

   public:
      Client(QObject *parent = 0);
      bool demarrer(QString adresse = ADRESSE_SERVEUR, int port = PORT_SERVEUR);

   private:
      QTcpSocket *socket;

   private slots:
      void estConnecte();
      void estDeconnecte();
      void envoyer(const QString &Requete);
      void recevoir();

   signals:

};

#endif
