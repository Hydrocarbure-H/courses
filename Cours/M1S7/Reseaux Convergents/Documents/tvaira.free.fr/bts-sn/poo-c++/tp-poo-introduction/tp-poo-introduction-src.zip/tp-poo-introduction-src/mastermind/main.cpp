//==============================================================
// Programme : mastermind
//
// Role :     Jeu du Mastermind
//
// Principe : Saisie d'un code secret
//            Saisie d'un essai et le compare au code secret
//            Affichage du nombre de chiffres bien et mal places
//
// Version : 
// Date de creation : 
// Auteur :           
// Etablissement :
//
//==============================================================

// Programme principal
int main() 
{
    // TODO :
    
    // 1. Instancier un objet de type Mastermind en utilisant le constructeur par défaut
    
    // Avant de jouer, il est conseillé d'afficher les règles du jeu
    
    // 2. Implémenter le diagramme de séquence "jouer une manche"
    
    return 0;
}

