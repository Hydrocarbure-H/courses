// Groupe

//#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <string.h>

//#define GUI

#ifdef GUI
typedef enum { NOIR, ROUGE, VERT, MARRON, BLEU, FUSHIA, CYAN, GRIS } Couleur;
typedef enum { NORMAL, SOFTEN, NORMAL1, NORMAL2, SOULIGNE, BLINK, NORMAL3, INVERT } Mode;

#define RESET_TERM()                printf("\x1b[0m")
#define SET_BGCOLOR(color)          printf("\x1b[1;37;4%dm",color)
#define SET_COLOR(color) 	        printf("\x1b[0;3%dm",color)
#define SET_MODECOLOR(mode,color)	printf("\x1b[%d;3%dm",mode,color)
#define SETCOLOR_SUCCESS()          printf("\x1b[1;32m")
#define SETCOLOR_FAILURE()          printf("\x1b[5;31m")
#define SETCOLOR_ERROR()            printf("\x1b[1;31m")
#define SETCOLOR_WARNING()          printf("\x1b[1;34m")
#define SETCOLOR_INFO()             printf("\x1b[0;37m")
#define SETCOLOR_NORMAL()           printf("\x1b[0;39m")
#define MOVE_TO_COL(col)	        printf("\x1B[%dG", col)
#define MOVE_XY(x,y)			    printf("\x1B[%d;%dH",x,y)
#define CLEAR_LINE(x,y)			    printf("\x1B[%d;%dH\x1b[2K",x,y)
#define RESET()					    printf("\x1B[2J")

#define LIGNE_SIMULATEUR            3
#define LIGNE_TRAVAILLEUR           7
#define COLONNE_MOTIF               36
#endif

// taille de la file pour les requêtes
#define TAILLE_MAX 10

// nombre de requêtes à effectuer par le simulateur
#define NB_REQUETES 50

// nombre de threads max
#define NB_THREADS_TRAVAILLEURS 5

// Requête
typedef struct
{
    char motif;
    int nb;
    int numeroTravailleur;
} Requete;

// Thread simulateur de requêtes
void *simulateur(void *);

// Thread travailleur
void *travailleur(void *);

int nbRequetes = NB_REQUETES;
Requete requetes[TAILLE_MAX]; // la file où seront déposées les requêtes
int in = 0; // indique le premier emplacement de libre pour déposer une requête
int out = 0; // indique l'emplacement de la prochaine requête à retirer
pthread_t tidTravailleurs[NB_THREADS_TRAVAILLEURS];

// Les ressources de synchronisation

int main(void) 
{
    pthread_t tidSimulateur;
    int *numeroTravailleur;

    setbuf(stdout, NULL);

    #ifdef GUI
    RESET();
    RESET_TERM();
    MOVE_XY(0,0);
    #endif
    printf("Répartiteur/Travailleurs : %d requêtes à traiter avec %d thread(s) travailleur(s)\n", nbRequetes, NB_THREADS_TRAVAILLEURS);

    pthread_create(&tidSimulateur, NULL, simulateur, (void *)&nbRequetes);
    for(int j=0;j<NB_THREADS_TRAVAILLEURS;j++)
    {
        numeroTravailleur = malloc(sizeof(int));
        *numeroTravailleur = j;
        pthread_create(&tidTravailleurs[j], NULL, travailleur, (void *)numeroTravailleur);
    }
    
    pthread_join(tidSimulateur, NULL);
    for(int j=0;j<NB_THREADS_TRAVAILLEURS;j++)
    {
        pthread_join(tidTravailleurs[j], NULL);
        #ifdef GUI
        CLEAR_LINE(LIGNE_TRAVAILLEUR+j, 2);
        #endif
    }

    #ifdef GUI
    CLEAR_LINE(LIGNE_SIMULATEUR+2, 2);
    CLEAR_LINE(LIGNE_SIMULATEUR, 2);
    RESET_TERM();
    MOVE_XY(1,0);
    #endif
    printf("\nTerminé\n");

    return 0;
}

void *simulateur(void *nbRequetes)
{
    Requete requete;
    int nb = *((int *)nbRequetes);

    srand(time(NULL));
    for(int i=0;i<nb;)
    {   
        // pas plein ?
        if ((in + 1) % TAILLE_MAX != out)
        {
            // fabrique une nouvelle requete
            requete.motif = '!' + rand() % 15; // entre '!' et '/'
            requete.nb = 10 + rand() % 51; // entre 10 et 60


        
            // place la requête dans la file
            requetes[in] = requete;

            // signale la requête
     

            #ifdef GUI
            printf("\x1B[%d;%dH>>> Nouvelle requête  : %d x '%c' (%02d/%02d)  [%02d/%02d]", LIGNE_SIMULATEUR, 2, requete.nb, requete.motif, i+1, nb, in, out);
            #else
            printf(">>> Nouvelle requête  : %d x '%c' (%02d/%02d)  [%02d/%02d]\n", requete.nb, requete.motif, i+1, nb, in, out);
            #endif
            in = (in + 1) % TAILLE_MAX;
            i++;
        }

        // simule une attente avant l'arrivée d'une nouvelle requête
        if((i % 8) == 0)
            usleep(100000);
    }

    #ifdef GUI
    CLEAR_LINE(LIGNE_SIMULATEUR, 2);
    printf("\x1B[%d;%dH>>> Fin simulateur", LIGNE_SIMULATEUR, 2);
    #else
    printf("Fin simulateur\n");
    #endif

    return NULL;
}

void afficherNbRequetesRestantes()
{
    int restantes = 0;
    if(out > in)
        restantes = (TAILLE_MAX - out) + in;
    else
        restantes = in - out;
    #ifdef GUI
    printf("\x1B[%d;%dH=== Nb de requêtes à traiter : %d/%d/%d", LIGNE_SIMULATEUR+2, 2, restantes, nbRequetes, NB_REQUETES);
    MOVE_XY(LIGNE_TRAVAILLEUR+NB_THREADS_TRAVAILLEURS+1,0);
    #endif
}

void *travailleur(void *numeroTravailleur)
{
    int numero = *((int *)numeroTravailleur);

  

    free(numeroTravailleur);
    return NULL;
}
