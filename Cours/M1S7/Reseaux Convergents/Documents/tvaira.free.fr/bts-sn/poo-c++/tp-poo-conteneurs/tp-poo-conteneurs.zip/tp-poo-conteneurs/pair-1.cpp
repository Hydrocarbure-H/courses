#include <iostream> 
#include <utility> 
#include <vector> 
#include <list> 
#include <map> 
#include <set> 

using namespace std;

int main() 
{ 
  pair<char,int> c1 = make_pair('B', 2); // coordonnées type "bataille navale"
  pair<char,int> c2 = make_pair('J', 1);
  
  cout << "Un coup en " << c1.first << '.' << c1.second << endl; 
  
  pair<int,int> p; // position de type "morpion"

  p.first  = 1;
  p.second = 2;
    
  cout << "Un coup en " << p.first << ',' << p.second << endl; 
  cout << endl;

  vector<pair<char,int> > tableauCoups(2); // ou par exemple : list<pair<char,int> > listeCoups;  

  tableauCoups[0] = c1;
  tableauCoups[1] = c2;
  cout << "Le vector contient " << tableauCoups.size() << " coups : \n";
  for (vector<pair<char,int> >::iterator it=tableauCoups.begin(); it!=tableauCoups.end(); ++it)
  {
    cout << (*it).first << "." << (*it).second << endl; 
  }
  cout << endl;
   
  map<pair<char,int>,bool> mapCoups;  
  
  mapCoups[c1] = true; // ce coup a fait mouche  
  mapCoups[c2] = false; // ce coup a fait plouf

  cout << "La map contient " << mapCoups.size() << " coups : \n";
  for (map<pair<char,int>,bool>::iterator it=mapCoups.begin(); it!=mapCoups.end(); ++it)
  {
    cout << it->first.first << "." << it->first.second << " -> \t" << it->second << endl; 
  }
  cout << endl;

  set<pair<char,int> > ensembleCoups;
  
  ensembleCoups.insert(c1);
  ensembleCoups.insert(c2);
  
  cout << "L'ensemble set contient " << ensembleCoups.size() << " coups : \n";
  for (set<pair<char,int> >::iterator it=ensembleCoups.begin(); it!=ensembleCoups.end(); ++it)
  {
    cout << (*it).first << "." << (*it).second << endl; 
  }
  cout << endl;

  return 0; 
}

