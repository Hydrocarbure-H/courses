#include "isbn.h" 

/* Lire : http://fr.wikipedia.org/wiki/International_Standard_Book_Number */

/*
   Le numéro ISBN-10 se composait de quatre segments, trois segments de longueur variable et un segment de longueur fixe, la longueur totale de l'ISBN comprenait dix chiffres. Les quatre segments d'un ancien code ISBN à 10 chiffres sont : A - B - C - D

   A identifie un groupe de codes par pays, zone géographique ou zone linguistique
   B identifie l'éditeur de la publication
   C correspond au numéro d'ordre de l'ouvrage chez l'éditeur qui l'attribue normalement séquentiellement
   D est un code clé de vérification sur un caractère calculé à partir des chiffres précédents. Outre les chiffres de 0 à 9, la clé de contrôle peut prendre la valeur X, qui représente le nombre 10. Ce code est calculé de la façon suivante :

   on attribue une pondération à chaque position (de 1 à 9 en allant en sens croissant) et on fait la somme des produits ainsi obtenus ;
   on conserve le reste de la division euclidienne de ce nombre par 11 ;
   si le reste de la division euclidienne est 10, la clé de contrôle n'est pas 10 mais la lettre X. Ceci permet donc d'avoir les codes 0, 1, 2, ..., 8, 9, X.

Remarques :
    11 étant un nombre premier, une erreur portant sur un chiffre entraînera automatiquement une incohérence du code de contrôle.
    La vérification du code de contrôle peut se faire en effectuant le même calcul sur le code ISBN complet, en appliquant la pondération 10 au dixième chiffre de la clé de contrôle (si ce chiffre clé est X, on lui attribue la valeur 10) : la somme pondérée doit alors être un multiple de 11. 
     
    L'ISBN au complet est : 2-266-11156-6. Il s'agit ici de l'ISBN de l'édition de poche de La Chute d'Hypérion de Dan Simmons.
*/

/**
   Vérifie un code ISBN-10
*/
bool ISBN::estValide10(const std::string &isbn) const
{
   int ponderation = 10;
   int somme = 0;
   int codeDeControle = 0;

   std::string _isbn = nettoie(isbn);

   /* seulement ISBN 10 */
   if(_isbn.size() != ISBN_10)
   {
      std::cerr << "Le code ISBN n'a pas la bonne taille (ISBN 10 accepté)" << std::endl;
      return false;
   }

   for(int i = 0; i < (ISBN_10 - 1); i++)
   {
      if(!isdigit(_isbn[i]))
         return false;
      int code =  _isbn[i] - '0';
      somme = somme + (code * ponderation);
      ponderation--;
   }

   codeDeControle = (11 - (somme % 11)) % 11;      

   if(codeDeControle == 10 && _isbn[(ISBN_10 - 1)] == 'X')
      return true;

   if(codeDeControle == _isbn[(ISBN_10 - 1)])
      return true;

   return false;
}

/*
   Pour faciliter leur gestion informatique, chaque livre porte un code à barres à la norme EAN 13 et un code ISBN-13 dont il est dérivé.

   Ce code comporte 13 chiffres et est aujourd'hui obligatoire (depuis janvier 2007)4, et doit être utilisé pour tous les nouveaux codes ISBN à la place du code à 10 chiffres. En effet, l'ancienne numérotation est arrivée à saturation et ne permettrait plus d'attribuer simplement des groupes de codes spécifiques aux différents éditeurs.
    
   La conversion d'un ancien code ISBN-10 en code ISBN-13 compatible avec la norme EAN est automatique (et obligatoire pour toutes les transactions électroniques à compter de janvier 2007). Ce code comporte 13 chiffres, et est calculé à partir du numéro ISBN-10 de la façon suivante :

    les trois premiers chiffres valent « 978 » (978 est le premier des identifiants attribués aux livres dans la codification EAN) ;
    les neuf chiffres suivants sont les neuf premiers chiffres de l'ISBN (code de la zone géographique, code de l'éditeur, numérotation interne à l'éditeur) ;
    le dernier chiffre (c13) est une clé de contrôle calculée en fonction des 12 premiers chiffres en calculant le reste de la division par 10 (le modulo 10) de la différence entre 10 et le modulo 10 de la somme de chaque chiffre, chaque chiffre étant pondéré selon un indice de position égal à 1 pour les positions impaires et 3 pour les positions paires, soit suivant la formule5 :

        c13 = modulo(10 - modulo(c1 + 3 × c2 + c3 + 3 × c4 + … + c11 + 3 × c12, 10), 10),

        qui peut également s'écrire ainsi : c13 = modulo(10 - modulo((c1+c3+c5+c7+c9+c11) + (c2+c4+c6+c8+c10+c12) × 3, 10), 10),
        le chiffre clé obtenu ne peut varier que de 0 à 9 (il n'y a plus de chiffre X),
        la vérification de la clé de contrôle peut se faire en vérifiant que la somme pondérée (calculée sur les 13 chiffres) est bien un multiple de 10.

Attention

La conversion inverse n'est plus autorisée, en effet :

    il existe maintenant des codes ISBN à 13 chiffres dont le premier groupe de trois chiffres vaut 979 et non 978 ;
    les groupes de trois premiers chiffres 978 et 979 ont été attribués dans la norme EAN pour l'ISBN ;    
    etc ...
*/

/** 
   Vérifie un code ISBN-13
*/

bool ISBN::estValide13(const std::string &isbn) const
{
   // TODO

   return false;
}

/**
   Nettoie un code ISBN en enlevant les tirets
*/
std::string ISBN::nettoie(const std::string &isbn) const
{
   std::string _isbn = "";
 
   for (unsigned int i = 0; i < isbn.size(); i++)
   {
      if((isbn[i] != '-') && (isbn[i] != ' '))
      {
         _isbn += isbn[i];
      }
   }
   
   return _isbn;
}

bool ISBN::estValide() const
{
   if(getTaille() == ISBN_10)
      return estValide10(this->isbn);
   if(getTaille() == ISBN_13)
      return estValide13(this->isbn);  
   return false;
}

bool ISBN::estValide(const std::string &isbn) const
{
   if(getTaille(isbn) == ISBN_10)
      return estValide10(isbn);
   if(getTaille(isbn) == ISBN_13)
      return estValide13(isbn);   
   return false;   
}

ISBN::ISBN()
{
   this->isbn = "";   
}

ISBN::ISBN(const std::string &isbn)
{
   if(nettoie(isbn).size() == ISBN_10 && estValide10(nettoie(isbn)))
   {
      this->isbn = isbn;
      return;
   }
   if(nettoie(isbn).size() == ISBN_13 && estValide13(nettoie(isbn)))
   {
      this->isbn = isbn;
      return;
   }
   this->isbn = "";   
}

void ISBN::setISBN(const std::string &isbn)
{
   if(nettoie(isbn).size() == ISBN_10 && estValide10(nettoie(isbn)))
   {
      this->isbn = isbn;
      return;
   }
   if(nettoie(isbn).size() == ISBN_13 && estValide13(nettoie(isbn)))
   {
      this->isbn = isbn;
      return;
   }
   this->isbn = "";   
}

std::string ISBN::getISBN() const
{
   return isbn;
}

int ISBN::getTaille() const
{
   return nettoie(isbn).size();
}

int ISBN::getTaille(const std::string &isbn) const
{
   return nettoie(isbn).size();
}
